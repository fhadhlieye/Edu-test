import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  Bell,
  BookOpen,
  ClipboardList,
  FileUp,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings,
  ShieldAlert,
  X,
} from 'lucide-react';
import { apiFetch } from './utils/api';
import { SchoolCrest } from './components/SchoolCrest';
import { LoginView } from './components/LoginView';
import { TeacherDashboard } from './components/TeacherDashboard';
import { SmartImportView } from './components/SmartImportView';
import { BankSoalView } from './components/BankSoalView';
import { ExamManagerView } from './components/ExamManagerView';
import { ProctorMonitorView } from './components/ProctorMonitorView';
import { GradingAndAnalysisView } from './components/GradingAndAnalysisView';
import { AdminConsoleView } from './components/AdminConsoleView';
import { StudentPortalView } from './components/StudentPortalView';
import { StudentExamRunner } from './components/StudentExamRunner';
import type { SchoolProfile, UserAccount } from './types/exam';

export default function App() {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [school, setSchool] = useState<SchoolProfile | null>(null);
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [booting, setBooting] = useState(true);

  const [activeNav, setActiveNav] = useState('dashboard');
  const [activeExamIdForSubView, setActiveExamIdForSubView] = useState<number | null>(null);
  const [runningExamId, setRunningExamId] = useState<number | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Notifications & Password modals
  const [showNotifs, setShowNotifs] = useState(false);
  const [notifsList, setNotifsList] = useState<any[]>([]);
  const [showPassModal, setShowPassModal] = useState(false);
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [passMsg, setPassMsg] = useState('');

  const loadSession = async () => {
    try {
      const res = await apiFetch<{
        authenticated: boolean;
        user: UserAccount | null;
        school: SchoolProfile | null;
        unreadNotifications: number;
      }>('/api/auth/session');
      if (!res.authenticated || !res.user) {
        setUser(null);
        setSchool(null);
        setUnreadNotifs(0);
        return;
      }
      setUser(res.user);
      setSchool(res.school);
      setUnreadNotifs(res.unreadNotifications || 0);
      if (res.user.role === 'SISWA') setActiveNav('student-portal');
      else {
        setActiveNav('dashboard');
      }
    } catch {
      setUser(null);
    } finally {
      setBooting(false);
    }
  };

  useEffect(() => {
    loadSession();
  }, []);

  const handleLogout = async () => {
    await apiFetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    setRunningExamId(null);
  };

  const openNotifications = async () => {
    const res = await apiFetch<{ notifications: any[] }>('/api/auth/notifications');
    setNotifsList(res.notifications || []);
    setShowNotifs(true);
    await apiFetch('/api/auth/notifications/read-all', { method: 'POST' });
    setUnreadNotifs(0);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg('');
    try {
      const res = await apiFetch<{ message: string }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ oldPassword: oldPass, newPassword: newPass }),
      });
      setPassMsg(res.message);
      setOldPass('');
      setNewPass('');
    } catch (err: any) {
      setPassMsg(err.message);
    }
  };

  if (booting) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-sm text-slate-600">
        Memuat EDU-TEST SMP Negeri 61 Palembang...
      </div>
    );
  }

  if (!user) {
    return (
      <LoginView
        onLoggedIn={(u) => {
          setUser(u);
          loadSession();
        }}
      />
    );
  }

  // Dedicated full-screen CBT Exam Runner for students
  if (user.role === 'SISWA' && runningExamId !== null) {
    return (
      <StudentExamRunner
        examId={runningExamId}
        user={user}
        onFinished={() => {
          setRunningExamId(null);
          setActiveNav('student-portal');
        }}
      />
    );
  }

  const navItems =
    user.role === 'SISWA'
      ? [
          { id: 'student-portal', label: 'Portal Ujian Siswa', icon: LayoutDashboard },
        ]
      : [
          { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { id: 'smart-import', label: 'Smart Import Soal', icon: FileUp },
          { id: 'bank-soal', label: 'Bank Soal AKM', icon: BookOpen },
          { id: 'exams', label: 'Manajemen Ujian', icon: ClipboardList },
          { id: 'monitor', label: 'Pengawasan Live', icon: ShieldAlert },
          { id: 'grading', label: 'Koreksi & Analisis', icon: BarChart3 },
          ...(user.role === 'ADMIN_SEKOLAH' || user.role === 'SUPER_ADMIN'
            ? [{ id: 'admin', label: 'Administrasi Sekolah', icon: Settings }]
            : []),
        ];

  const currentNavLabel =
    navItems.find((n) => n.id === activeNav)?.label || 'Beranda';

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar Navigation */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform lg:static lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 border-b border-slate-200 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <SchoolCrest className="w-9 h-9 shrink-0" />
            <div className="min-w-0">
              <div className="font-display text-sm font-bold text-slate-900 truncate">
                EDU-TEST 61
              </div>
              <div className="text-[11px] text-slate-500 truncate">
                {school?.name || 'SMP Negeri 61 Palembang'}
              </div>
            </div>
          </div>
          <button
            type="button"
            aria-label="Tutup menu"
            onClick={() => setMobileMenuOpen(false)}
            className="lg:hidden p-1 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeNav === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveNav(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-blue-50 text-blue-800 font-semibold'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    active ? 'text-blue-700' : 'text-slate-500'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 space-y-2">
          <div className="text-xs">
            <div className="font-semibold text-slate-900 truncate">
              {user.fullName}
            </div>
            <div className="text-slate-500 truncate">
              {user.role.replace('_', ' ')} · {user.nipNisn || user.username}
            </div>
          </div>
          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setPassMsg('');
                setShowPassModal(true);
              }}
              className="flex-1 inline-flex items-center justify-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              Sandi
            </button>
            <button
              type="button"
              onClick={handleLogout}
              className="flex-1 inline-flex items-center justify-center gap-1 rounded-lg border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Keluar
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between gap-4 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <button
              type="button"
              aria-label="Buka menu navigasi"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-1.5 rounded-lg border border-slate-200 text-slate-700"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="text-sm text-slate-500 flex items-center gap-2">
              <span className="hidden sm:inline">{school?.name || 'SMP Negeri 61 Palembang'}</span>
              <span className="hidden sm:inline">/</span>
              <span className="font-semibold text-slate-900">{currentNavLabel}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <span className="hidden md:inline text-xs text-slate-500">
              TP {school?.academicYear || '2025/2026'} · Semester {school?.activeSemester || 'Ganjil'}
            </span>
            <button
              type="button"
              aria-label="Notifikasi"
              onClick={openNotifications}
              className="relative p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center tabular-nums">
                  {unreadNotifs}
                </span>
              )}
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {user.role === 'SISWA' ? (
            <StudentPortalView
              user={user}
              school={school}
              onStartExam={(id) => setRunningExamId(id)}
            />
          ) : (
            <>
              {activeNav === 'dashboard' && (
                <TeacherDashboard onNavigate={(tab) => setActiveNav(tab)} />
              )}
              {activeNav === 'smart-import' && (
                <SmartImportView onSavedToBank={() => setActiveNav('bank-soal')} />
              )}
              {activeNav === 'bank-soal' && <BankSoalView />}
              {activeNav === 'exams' && (
                <ExamManagerView
                  school={school}
                  onOpenMonitor={(examId) => {
                    setActiveExamIdForSubView(examId);
                    setActiveNav('monitor');
                  }}
                  onOpenGrading={(examId) => {
                    setActiveExamIdForSubView(examId);
                    setActiveNav('grading');
                  }}
                />
              )}
              {activeNav === 'monitor' && (
                <ProctorMonitorView initialExamId={activeExamIdForSubView} />
              )}
              {activeNav === 'grading' && (
                <GradingAndAnalysisView
                  school={school}
                  initialExamId={activeExamIdForSubView}
                />
              )}
              {activeNav === 'admin' && (
                <AdminConsoleView onSchoolUpdated={loadSession} />
              )}
            </>
          )}
        </main>
      </div>

      {/* Notifications Modal */}
      {showNotifs && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-md p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <h2 className="font-display text-base font-bold text-slate-900">
                Notifikasi
              </h2>
              <button
                type="button"
                aria-label="Tutup notifikasi"
                onClick={() => setShowNotifs(false)}
                className="p-1 text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs">
              {notifsList.length === 0 ? (
                <p className="py-6 text-center text-slate-500">
                  Belum ada notifikasi.
                </p>
              ) : (
                notifsList.map((n) => (
                  <div key={n.id} className="py-2.5 space-y-0.5">
                    <div className="font-semibold text-slate-900">{n.title}</div>
                    <p className="text-slate-600">{n.message}</p>
                    <div className="text-[11px] text-slate-400">{n.created_at}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {showPassModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4"
        >
          <form
            onSubmit={handleChangePassword}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-5 space-y-3"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <h2 className="font-display text-base font-bold text-slate-900">
                Ubah Kata Sandi
              </h2>
              <button
                type="button"
                aria-label="Tutup modal kata sandi"
                onClick={() => setShowPassModal(false)}
                className="p-1 text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {passMsg && (
              <div className="rounded bg-blue-50 border border-blue-200 p-2.5 text-xs text-blue-900">
                {passMsg}
              </div>
            )}
            <input
              type="password"
              required
              placeholder="Kata sandi saat ini"
              value={oldPass}
              onChange={(e) => setOldPass(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
            <input
              type="password"
              required
              minLength={6}
              placeholder="Kata sandi baru (minimal 6 karakter)"
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
            <button
              type="submit"
              className="w-full rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 cursor-pointer"
            >
              Simpan Kata Sandi Baru
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
