import type { Difficulty, QuestionItem, QuestionType } from '../types/exam';

export interface ParsedQuestionDraft {
  tempId: string;
  orderNumber: number;
  questionType: QuestionType;
  stimulusTitle?: string;
  stimulusText?: string;
  stem: string;
  mathLatex?: string;
  options: Array<{ key: string; text: string }>;
  correctAnswer: string | string[];
  matchingPairs: Array<{ id: string; leftText: string; rightText: string }>;
  shortAnswerConfig: {
    acceptedAnswers: string[];
    caseSensitive: boolean;
    ignoreWhitespace: boolean;
    numericTolerance: number;
  };
  rubric: Array<{ id: string; aspect: string; maxPoints: number; description: string }>;
  difficulty: Difficulty;
  topic: string;
  weight: number;
  partialScoring: boolean;
  pgkMode: 'ALL_OR_NOTHING' | 'PARTIAL';
  warnings: string[];
}

const QUESTION_START_RE = /^(?:(?:Soal\s+|No\.?\s*)?(\d{1,3})[\.\):]\s+)(.+)$/i;
const OPTION_RE = /^[\(\[]?([A-Ea-e])[\.\)\]]\s+(.+)$/;
const KEY_RE = /^(?:Kunci(?:\s+Jawaban)?|Jawaban)\s*[:=]\s*(.+)$/i;
const STIMULUS_RE = /^(?:Bacalah\s+(?:teks|wacana|kutipan|berita|artikel|tabel|grafik)|Stimulus|Wacana(?:\s+\d+)?|Teks\s+untuk\s+soal)/i;

function detectTypeFromContent(
  stem: string,
  options: Array<{ key: string; text: string }>,
  pairs: Array<{ id: string; leftText: string; rightText: string }>,
  explicitKeyRaw: string
): QuestionType {
  const lower = stem.toLowerCase();
  if (pairs.length >= 2 || /menjodohkan|pasangkan|jodohkan/i.test(lower)) {
    return 'MENJODOHKAN';
  }
  if (
    /pilih\s+lebih\s+dari\s+satu|pilihan\s+ganda\s+kompleks|\[pgk\]|centanglah|jawaban\s+benar\s+lebih\s+dari\s+satu/i.test(
      lower
    ) ||
    (options.length >= 2 && explicitKeyRaw.includes(','))
  ) {
    return 'PG_KOMPLEKS';
  }
  if (options.length >= 2) {
    return 'PG';
  }
  if (
    /_{3,}|\.{4,}|isian\s+singkat|tuliskan\s+angka|berapa\s+hasil|sebutkan\s+satu/i.test(
      lower
    )
  ) {
    return 'ISIAN_SINGKAT';
  }
  if (
    /jelaskan|uraikan|mengapa|bagaimana|analisislah|essay|esai|uraian/i.test(lower)
  ) {
    return 'ESAI';
  }
  return options.length >= 2 ? 'PG' : 'ESAI';
}

export function parseQuestionsHeuristic(
  rawText: string,
  defaultTopic = 'Umum'
): ParsedQuestionDraft[] {
  const lines = rawText
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((l) => l.trim());

  const drafts: ParsedQuestionDraft[] = [];
  let activeStimulusTitle = '';
  let activeStimulusBuffer: string[] = [];
  let inStimulusMode = false;

  let current: {
    orderNumber: number;
    stemLines: string[];
    options: Array<{ key: string; text: string }>;
    pairs: Array<{ id: string; leftText: string; rightText: string }>;
    keyRaw: string;
    stimulusTitle?: string;
    stimulusText?: string;
  } | null = null;

  const flushCurrent = () => {
    if (!current) return;
    const stem = current.stemLines.join('\n').trim();
    const qType = detectTypeFromContent(
      stem,
      current.options,
      current.pairs,
      current.keyRaw
    );
    const warnings: string[] = [];

    let correctAnswer: string | string[] = '';
    const acceptedAnswers: string[] = [];
    if (current.keyRaw) {
      if (qType === 'PG_KOMPLEKS') {
        correctAnswer = current.keyRaw
          .split(/[,;&]+/)
          .map((s) => s.trim().toUpperCase())
          .filter(Boolean);
      } else if (qType === 'PG') {
        correctAnswer = current.keyRaw.trim().charAt(0).toUpperCase();
      } else if (qType === 'ISIAN_SINGKAT') {
        const alts = current.keyRaw
          .split(/[;|/]+/)
          .map((s) => s.trim())
          .filter(Boolean);
        acceptedAnswers.push(...alts);
        correctAnswer = alts[0] || '';
      } else {
        correctAnswer = current.keyRaw.trim();
      }
    } else if (qType !== 'MENJODOHKAN') {
      warnings.push('Kunci jawaban belum terdeteksi di dokumen; silakan lengkapi manual.');
    }

    if ((qType === 'PG' || qType === 'PG_KOMPLEKS') && current.options.length < 3) {
      warnings.push('Jumlah pilihan jawaban kurang dari 3; periksa kembali opsi A–E.');
    }
    if (qType === 'MENJODOHKAN' && current.pairs.length < 2) {
      warnings.push('Pasangan menjodohkan belum lengkap (minimal 2 pasang).');
    }
    if (!stem) {
      warnings.push('Teks pertanyaan kosong atau terpotong.');
    }

    const latexMatch = stem.match(/\$([^$]+)\$/);

    drafts.push({
      tempId: `draft-${drafts.length + 1}-${current.orderNumber}`,
      orderNumber: current.orderNumber,
      questionType: qType,
      stimulusTitle: current.stimulusTitle || undefined,
      stimulusText: current.stimulusText || undefined,
      stem,
      mathLatex: latexMatch ? latexMatch[1] : undefined,
      options: current.options,
      correctAnswer,
      matchingPairs: current.pairs,
      shortAnswerConfig: {
        acceptedAnswers,
        caseSensitive: false,
        ignoreWhitespace: false,
        numericTolerance: 0,
      },
      rubric:
        qType === 'ESAI'
          ? [
              {
                id: 'r1',
                aspect: 'Ketepatan Konsep & Isi',
                maxPoints: 3,
                description: 'Menjawab inti pertanyaan sesuai konsep materi.',
              },
              {
                id: 'r2',
                aspect: 'Kelengkapan Argumen / Bukti',
                maxPoints: 2,
                description: 'Menyertakan alasan, langkah, atau bukti pendukung.',
              },
            ]
          : [],
      difficulty: 'SEDANG',
      topic: defaultTopic,
      weight: qType === 'ESAI' ? 5 : qType === 'PG_KOMPLEKS' || qType === 'MENJODOHKAN' ? 3 : 2,
      partialScoring: qType === 'PG_KOMPLEKS' || qType === 'MENJODOHKAN',
      pgkMode: qType === 'PG_KOMPLEKS' ? 'PARTIAL' : 'ALL_OR_NOTHING',
      warnings,
    });
    current = null;
  };

  for (const line of lines) {
    if (!line) {
      if (inStimulusMode && activeStimulusBuffer.length > 0) {
        activeStimulusBuffer.push('');
      }
      continue;
    }

    if (STIMULUS_RE.test(line)) {
      flushCurrent();
      inStimulusMode = true;
      activeStimulusTitle = line.slice(0, 80);
      activeStimulusBuffer = [line];
      continue;
    }

    const qMatch = line.match(QUESTION_START_RE);
    if (qMatch) {
      inStimulusMode = false;
      flushCurrent();
      const stimText = activeStimulusBuffer.join('\n').trim();
      current = {
        orderNumber: Number(qMatch[1]),
        stemLines: [qMatch[2]],
        options: [],
        pairs: [],
        keyRaw: '',
        stimulusTitle: stimText ? activeStimulusTitle : undefined,
        stimulusText: stimText || undefined,
      };
      continue;
    }

    if (inStimulusMode) {
      activeStimulusBuffer.push(line);
      continue;
    }

    if (current) {
      const keyMatch = line.match(KEY_RE);
      if (keyMatch) {
        current.keyRaw = keyMatch[1].trim();
        continue;
      }

      const optMatch = line.match(OPTION_RE);
      if (optMatch) {
        current.options.push({
          key: optMatch[1].toUpperCase(),
          text: optMatch[2].trim(),
        });
        continue;
      }

      // Check matching pair syntax: "Left -> Right" or "Left = Right"
      const pairMatch = line.match(/^[-*]?\s*(.+?)\s*(?:->|=>|↔|=)\s*(.+)$/);
      if (pairMatch && !line.includes('$')) {
        current.pairs.push({
          id: `pair-${current.pairs.length + 1}`,
          leftText: pairMatch[1].trim(),
          rightText: pairMatch[2].trim(),
        });
        continue;
      }

      if (current.options.length > 0) {
        const lastOpt = current.options[current.options.length - 1];
        lastOpt.text = `${lastOpt.text} ${line}`.trim();
      } else {
        current.stemLines.push(line);
      }
    }
  }

  flushCurrent();
  return drafts;
}

export function normalizeDraftToQuestion(
  draft: ParsedQuestionDraft,
  subjectId: number
): Omit<QuestionItem, 'id'> {
  return {
    subjectId,
    gradeLevel: 'IX',
    topic: draft.topic || 'Umum',
    difficulty: draft.difficulty || 'SEDANG',
    questionType: draft.questionType,
    stimulusTitle: draft.stimulusTitle,
    stimulusText: draft.stimulusText,
    stimulusMedia: [],
    stem: draft.stem,
    mathLatex: draft.mathLatex,
    options: draft.options,
    correctAnswer: draft.correctAnswer,
    matchingPairs: draft.matchingPairs,
    shortAnswerConfig: draft.shortAnswerConfig,
    rubric: draft.rubric,
    weight: draft.weight || 2,
    partialScoring: draft.partialScoring,
    pgkMode: draft.pgkMode,
    warnings: draft.warnings,
    year: new Date().getFullYear(),
  };
}
