import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { SchoolProfile } from '../types/exam';

function addSchoolKop(doc: jsPDF, school: SchoolProfile | null, title: string) {
  const name = school?.name || 'SMP Negeri 61 Palembang';
  const addr = school?.address || 'Kota Palembang, Sumatera Selatan';
  const npsn = school?.npsn || '10603861';

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('PEMERINTAH KOTA PALEMBANG · DINAS PENDIDIKAN', 105, 14, {
    align: 'center',
  });
  doc.setFontSize(14);
  doc.text(name.toUpperCase(), 105, 21, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`${addr} | NPSN: ${npsn}`, 105, 26, { align: 'center' });
  doc.setLineWidth(0.7);
  doc.line(14, 30, 196, 30);
  doc.setLineWidth(0.2);
  doc.line(14, 31.2, 196, 31.2);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text(title, 105, 40, { align: 'center' });
}

export function downloadStudentCardPdf(params: {
  school: SchoolProfile | null;
  student: {
    fullName: string;
    nipNisn: string;
    username: string;
    className?: string;
    email: string;
  };
  exams: Array<{
    title: string;
    subjectName?: string;
    scheduledDate: string;
    startTime: string;
    endTime: string;
  }>;
}) {
  const doc = new jsPDF();
  addSchoolKop(doc, params.school, 'KARTU PESERTA UJIAN DIGITAL');

  doc.setDrawColor(29, 78, 216);
  doc.setLineWidth(0.5);
  doc.rect(14, 46, 182, 46);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Nama Peserta   : ${params.student.fullName}`, 20, 56);
  doc.text(`NIS / NISN     : ${params.student.nipNisn || '-'}`, 20, 64);
  doc.text(`Kelas / Rombel : ${params.student.className || '-'}`, 20, 72);
  doc.text(`Username Login : ${params.student.username}`, 20, 80);
  doc.text(
    `Tahun Ajaran   : ${params.school?.academicYear || '2025/2026'} (${params.school?.activeSemester || 'Ganjil'})`,
    115,
    56
  );

  autoTable(doc, {
    startY: 100,
    head: [['No', 'Nama Ujian', 'Mata Pelajaran', 'Tanggal', 'Waktu']],
    body: params.exams.map((ex, i) => [
      i + 1,
      ex.title,
      ex.subjectName || '-',
      ex.scheduledDate,
      `${ex.startTime} - ${ex.endTime}`,
    ]),
    styles: { fontSize: 9 },
    headStyles: { fillColor: [29, 78, 216] },
  });

  const finalY = (doc as any).lastAutoTable?.finalY || 140;
  doc.setFontSize(9);
  doc.text(
    `Palembang, ${new Date().toLocaleDateString('id-ID')}`,
    140,
    finalY + 14
  );
  doc.text('Kepala Sekolah,', 140, finalY + 20);
  doc.setFont('helvetica', 'bold');
  doc.text(
    params.school?.headmaster || 'Drs. H. Hendra Wijaya, M.Pd.',
    140,
    finalY + 38
  );

  doc.save(`kartu-peserta-${params.student.username}.pdf`);
}

export function downloadExamReportPdf(params: {
  school: SchoolProfile | null;
  examTitle: string;
  subjectName: string;
  scheduledDate: string;
  summary: {
    totalParticipants: number;
    mean: number;
    min: number;
    max: number;
    passRate: number;
    passCount: number;
    remedialCount: number;
  };
  participants: Array<{
    nip_nisn: string;
    student_name: string;
    class_name: string;
    final_score: number;
    passed: number | boolean;
    violation_count: number;
  }>;
}) {
  const doc = new jsPDF();
  addSchoolKop(doc, params.school, 'LAPORAN REKAPITULASI HASIL UJIAN');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Ujian          : ${params.examTitle}`, 14, 50);
  doc.text(`Mata Pelajaran : ${params.subjectName}`, 14, 56);
  doc.text(`Tanggal        : ${params.scheduledDate}`, 14, 62);
  doc.text(
    `Statistik      : Rata-rata ${params.summary.mean} | Tertinggi ${params.summary.max} | Terendah ${params.summary.min} | Tuntas ${params.summary.passRate}% (${params.summary.passCount}/${params.summary.totalParticipants})`,
    14,
    68
  );

  autoTable(doc, {
    startY: 75,
    head: [['No', 'NISN', 'Nama Siswa', 'Kelas', 'Nilai Akhir', 'Status', 'Pelanggaran']],
    body: params.participants.map((p, i) => [
      i + 1,
      p.nip_nisn || '-',
      p.student_name,
      p.class_name,
      p.final_score,
      p.passed ? 'Tuntas' : 'Remedial',
      p.violation_count,
    ]),
    styles: { fontSize: 9 },
    headStyles: { fillColor: [29, 78, 216] },
  });

  const finalY = (doc as any).lastAutoTable?.finalY || 140;
  doc.text(
    `Palembang, ${new Date().toLocaleDateString('id-ID')}`,
    135,
    finalY + 14
  );
  doc.text('Kepala SMP Negeri 61 Palembang,', 135, finalY + 20);
  doc.setFont('helvetica', 'bold');
  doc.text(
    params.school?.headmaster || 'Drs. H. Hendra Wijaya, M.Pd.',
    135,
    finalY + 38
  );

  doc.save(`laporan-hasil-${params.examTitle.toLowerCase().replace(/\s+/g, '-')}.pdf`);
}

export function downloadBeritaAcaraPdf(params: {
  school: SchoolProfile | null;
  examTitle: string;
  subjectName: string;
  scheduledDate: string;
  startTime: string;
  endTime: string;
  totalParticipants: number;
  notStartedCount: number;
  teacherName: string;
}) {
  const doc = new jsPDF();
  addSchoolKop(doc, params.school, 'BERITA ACARA PELAKSANAAN UJIAN DIGITAL');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10.5);
  const body = [
    `Pada hari ini tanggal ${params.scheduledDate}, telah dilaksanakan Ujian Digital berbasis sistem EDU-TEST di ${params.school?.name || 'SMP Negeri 61 Palembang'} untuk:`,
    '',
    `1. Nama Ujian          : ${params.examTitle}`,
    `2. Mata Pelajaran      : ${params.subjectName}`,
    `3. Waktu Pelaksanaan   : ${params.startTime} s.d. ${params.endTime} WIB`,
    `4. Jumlah Peserta Hadir: ${params.totalParticipants} siswa`,
    `5. Peserta Belum Hadir : ${params.notStartedCount} siswa`,
    `6. Guru / Pengawas     : ${params.teacherName}`,
    '',
    'Catatan Pelaksanaan:',
    'Pelaksanaan ujian digital berlangsung dengan tertib, lancar, dan diawasi melalui sistem pencatatan aktivitas pengawasan otomatis.',
    '',
    'Demikian berita acara ini dibuat dengan sebenar-benarnya untuk dipergunakan sebagaimana mestinya.',
  ];
  doc.text(doc.splitTextToSize(body.join('\n'), 180), 14, 52);

  doc.text('Pengawas / Guru Mata Pelajaran,', 20, 155);
  doc.text('Mengetahui, Kepala Sekolah,', 130, 155);
  doc.setFont('helvetica', 'bold');
  doc.text(params.teacherName, 20, 180);
  doc.text(params.school?.headmaster || 'Drs. H. Hendra Wijaya, M.Pd.', 130, 180);

  doc.save(`berita-acara-${params.examTitle.toLowerCase().replace(/\s+/g, '-')}.pdf`);
}

export function downloadDaftarPesertaPdf(params: {
  school: SchoolProfile | null;
  examTitle: string;
  subjectName: string;
  scheduledDate: string;
  students: Array<{
    nip_nisn: string;
    full_name: string;
    class_name: string;
    status: string;
  }>;
}) {
  const doc = new jsPDF();
  addSchoolKop(doc, params.school, 'DAFTAR PESERTA UJIAN');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Ujian: ${params.examTitle} (${params.subjectName}) · Tanggal: ${params.scheduledDate}`, 14, 50);

  autoTable(doc, {
    startY: 56,
    head: [['No', 'NISN', 'Nama Peserta', 'Kelas', 'Status Ujian', 'Paraf']],
    body: params.students.map((s, i) => [
      i + 1,
      s.nip_nisn || '-',
      s.full_name,
      s.class_name || '-',
      s.status,
      '',
    ]),
    styles: { fontSize: 9 },
    headStyles: { fillColor: [29, 78, 216] },
  });

  doc.save(`daftar-peserta-${params.examTitle.toLowerCase().replace(/\s+/g, '-')}.pdf`);
}
