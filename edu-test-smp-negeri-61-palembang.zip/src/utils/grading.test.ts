import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyRounding,
  calculateExamSummary,
  gradeObjectiveQuestion,
} from './grading';

test('Pilihan Ganda auto-grades exact match regardless of case', () => {
  const res1 = gradeObjectiveQuestion(
    {
      questionType: 'PG',
      correctAnswer: 'B',
      matchingPairs: [],
      shortAnswerConfig: { acceptedAnswers: [], caseSensitive: false, ignoreWhitespace: false, numericTolerance: 0 },
      weight: 2,
      partialScoring: false,
      pgkMode: 'ALL_OR_NOTHING',
    },
    'b'
  );
  assert.equal(res1.score, 2);
  assert.equal(res1.isCorrect, true);

  const res2 = gradeObjectiveQuestion(
    {
      questionType: 'PG',
      correctAnswer: 'B',
      matchingPairs: [],
      shortAnswerConfig: { acceptedAnswers: [], caseSensitive: false, ignoreWhitespace: false, numericTolerance: 0 },
      weight: 2,
      partialScoring: false,
      pgkMode: 'ALL_OR_NOTHING',
    },
    'C'
  );
  assert.equal(res2.score, 0);
  assert.equal(res2.isCorrect, false);
});

test('Pilihan Ganda Kompleks supports ALL_OR_NOTHING and PARTIAL scoring', () => {
  const allOrNothing = gradeObjectiveQuestion(
    {
      questionType: 'PG_KOMPLEKS',
      correctAnswer: ['A', 'C'],
      matchingPairs: [],
      shortAnswerConfig: { acceptedAnswers: [], caseSensitive: false, ignoreWhitespace: false, numericTolerance: 0 },
      weight: 4,
      partialScoring: false,
      pgkMode: 'ALL_OR_NOTHING',
    },
    ['A']
  );
  assert.equal(allOrNothing.score, 0);

  const partial = gradeObjectiveQuestion(
    {
      questionType: 'PG_KOMPLEKS',
      correctAnswer: ['A', 'C'],
      matchingPairs: [],
      shortAnswerConfig: { acceptedAnswers: [], caseSensitive: false, ignoreWhitespace: false, numericTolerance: 0 },
      weight: 4,
      partialScoring: true,
      pgkMode: 'PARTIAL',
    },
    ['A']
  );
  assert.equal(partial.score, 2);

  const partialWithWrong = gradeObjectiveQuestion(
    {
      questionType: 'PG_KOMPLEKS',
      correctAnswer: ['A', 'C'],
      matchingPairs: [],
      shortAnswerConfig: { acceptedAnswers: [], caseSensitive: false, ignoreWhitespace: false, numericTolerance: 0 },
      weight: 4,
      partialScoring: true,
      pgkMode: 'PARTIAL',
    },
    ['A', 'D']
  );
  // (1 - 0.5) / 2 * 4 = 1
  assert.equal(partialWithWrong.score, 1);
});

test('Menjodohkan supports partial matching score', () => {
  const res = gradeObjectiveQuestion(
    {
      questionType: 'MENJODOHKAN',
      correctAnswer: '',
      matchingPairs: [
        { id: 'p1', leftText: 'Sila 1', rightText: 'Ketuhanan' },
        { id: 'p2', leftText: 'Sila 2', rightText: 'Kemanusiaan' },
      ],
      shortAnswerConfig: { acceptedAnswers: [], caseSensitive: false, ignoreWhitespace: false, numericTolerance: 0 },
      weight: 4,
      partialScoring: true,
      pgkMode: 'PARTIAL',
    },
    { p1: 'Ketuhanan', p2: 'Persatuan' }
  );
  assert.equal(res.score, 2);
  assert.equal(res.isCorrect, false);
});

test('Isian Singkat handles multiple alternatives, whitespace, and numeric tolerance', () => {
  const textRes = gradeObjectiveQuestion(
    {
      questionType: 'ISIAN_SINGKAT',
      correctAnswer: 'Palembang',
      matchingPairs: [],
      shortAnswerConfig: {
        acceptedAnswers: ['Palembang', 'Kota Palembang'],
        caseSensitive: false,
        ignoreWhitespace: true,
        numericTolerance: 0,
      },
      weight: 2,
      partialScoring: false,
      pgkMode: 'ALL_OR_NOTHING',
    },
    'kota   palembang'
  );
  assert.equal(textRes.score, 2);

  const numRes = gradeObjectiveQuestion(
    {
      questionType: 'ISIAN_SINGKAT',
      correctAnswer: '3.14',
      matchingPairs: [],
      shortAnswerConfig: {
        acceptedAnswers: ['3.14'],
        caseSensitive: false,
        ignoreWhitespace: true,
        numericTolerance: 0.02,
      },
      weight: 2,
      partialScoring: false,
      pgkMode: 'ALL_OR_NOTHING',
    },
    '3,15'
  );
  assert.equal(numRes.score, 2);
});

test('calculateExamSummary computes normalized score, rounding, and remedial status', () => {
  assert.equal(applyRounding(74.4, 'CEIL'), 75);
  assert.equal(applyRounding(74.6, 'FLOOR'), 74);
  assert.equal(applyRounding(74.6, 'NEAREST'), 75);

  const summary = calculateExamSummary(
    [
      { earnedObjective: 6, earnedManual: null, maxPoints: 10, isEssay: false, isGraded: true },
      { earnedObjective: 0, earnedManual: 8, maxPoints: 10, isEssay: true, isGraded: true },
    ],
    { maxScore: 100, passingScore: 75, roundingMode: 'NEAREST' }
  );
  assert.equal(summary.normalizedScore, 70);
  assert.equal(summary.passed, false);
  assert.equal(summary.needsRemedial, true);
});
