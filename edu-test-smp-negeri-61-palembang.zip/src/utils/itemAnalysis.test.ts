import test from 'node:test';
import assert from 'node:assert/strict';
import { computeClassSummary, computeItemAnalysis } from './itemAnalysis';

test('computeClassSummary computes mean, median, passRate, and buckets', () => {
  const stats = computeClassSummary([
    { studentId: 1, studentName: 'A', className: 'IX-A', finalScore: 90, passed: true },
    { studentId: 2, studentName: 'B', className: 'IX-A', finalScore: 80, passed: true },
    { studentId: 3, studentName: 'C', className: 'IX-B', finalScore: 60, passed: false },
    { studentId: 4, studentName: 'D', className: 'IX-B', finalScore: 70, passed: false },
  ]);
  assert.equal(stats.totalParticipants, 4);
  assert.equal(stats.mean, 75);
  assert.equal(stats.median, 75);
  assert.equal(stats.min, 60);
  assert.equal(stats.max, 90);
  assert.equal(stats.passCount, 2);
  assert.equal(stats.remedialCount, 2);
  assert.equal(stats.passRate, 50);
  assert.equal(stats.classBreakdown.length, 2);
});

test('computeItemAnalysis computes difficulty P, discrimination D, and distractor stats', () => {
  const analysis = computeItemAnalysis([
    {
      studentId: 1,
      totalStudentScore: 95,
      questionId: 10,
      questionNumber: 1,
      questionType: 'PG',
      stem: 'Soal 1',
      earnedScore: 2,
      maxWeight: 2,
      selectedOption: 'B',
      correctOption: 'B',
      options: ['A', 'B', 'C', 'D'],
    },
    {
      studentId: 2,
      totalStudentScore: 85,
      questionId: 10,
      questionNumber: 1,
      questionType: 'PG',
      stem: 'Soal 1',
      earnedScore: 2,
      maxWeight: 2,
      selectedOption: 'B',
      correctOption: 'B',
      options: ['A', 'B', 'C', 'D'],
    },
    {
      studentId: 3,
      totalStudentScore: 45,
      questionId: 10,
      questionNumber: 1,
      questionType: 'PG',
      stem: 'Soal 1',
      earnedScore: 0,
      maxWeight: 2,
      selectedOption: 'A',
      correctOption: 'B',
      options: ['A', 'B', 'C', 'D'],
    },
    {
      studentId: 4,
      totalStudentScore: 40,
      questionId: 10,
      questionNumber: 1,
      questionType: 'PG',
      stem: 'Soal 1',
      earnedScore: 0,
      maxWeight: 2,
      selectedOption: 'C',
      correctOption: 'B',
      options: ['A', 'B', 'C', 'D'],
    },
  ]);

  assert.equal(analysis.length, 1);
  assert.equal(analysis[0].pValue, 0.5);
  assert.equal(analysis[0].difficultyLabel, 'SEDANG');
  assert.equal(analysis[0].discriminationIndex, 1);
  assert.equal(analysis[0].discriminationLabel, 'BAIK_SEKALI');
  assert.equal(analysis[0].distractorStats.find((d) => d.optionKey === 'B')?.count, 2);
});
