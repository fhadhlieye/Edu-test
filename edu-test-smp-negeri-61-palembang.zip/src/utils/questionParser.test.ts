import test from 'node:test';
import assert from 'node:assert/strict';
import { parseQuestionsHeuristic } from './questionParser';

test('parseQuestionsHeuristic extracts reading stimulus and all 5 AKM question types', () => {
  const sampleDoc = `
Bacalah teks berikut untuk menjawab soal nomor 1 dan 2!
Sungai Musi membelah Kota Palembang menjadi kawasan Ilir dan Ulu.

1. Apa nama sungai yang membelah Kota Palembang berdasarkan bacaan?
A. Sungai Kapuas
B. Sungai Musi
C. Sungai Mahakam
D. Sungai Bengawan Solo
Kunci: B

2. Pilih lebih dari satu pernyataan yang benar tentang Sungai Musi!
A. Membelah Kota Palembang
B. Menghubungkan kawasan Ilir dan Ulu
C. Berada di Pulau Jawa
D. Merupakan gunung berapi
Kunci: A, B

3. Jodohkan istilah berikut dengan pasangannya!
Ibu Kota Sumsel -> Palembang
Jembatan Ikonik -> Ampera

4. Luas persegi dengan sisi 5 cm adalah ____ cm2.
Kunci: 25 | 25 cm2

5. Jelaskan manfaat jembatan bagi perekonomian warga Palembang!
  `;

  const parsed = parseQuestionsHeuristic(sampleDoc, 'Geografi & Literasi');
  assert.equal(parsed.length, 5);

  assert.equal(parsed[0].questionType, 'PG');
  assert.equal(parsed[0].correctAnswer, 'B');
  assert.ok(parsed[0].stimulusText?.includes('Sungai Musi'));

  assert.equal(parsed[1].questionType, 'PG_KOMPLEKS');
  assert.deepEqual(parsed[1].correctAnswer, ['A', 'B']);
  assert.ok(parsed[1].stimulusText?.includes('Sungai Musi'));

  assert.equal(parsed[2].questionType, 'MENJODOHKAN');
  assert.equal(parsed[2].matchingPairs.length, 2);

  assert.equal(parsed[3].questionType, 'ISIAN_SINGKAT');
  assert.deepEqual(parsed[3].shortAnswerConfig.acceptedAnswers, ['25', '25 cm2']);

  assert.equal(parsed[4].questionType, 'ESAI');
  assert.ok(parsed[4].rubric.length >= 2);
});

test('parseQuestionsHeuristic emits warnings for missing keys without crashing', () => {
  const doc = `
1. Berapakah hasil dari 2 + 2?
A. 3
B. 4
  `;
  const parsed = parseQuestionsHeuristic(doc);
  assert.equal(parsed.length, 1);
  assert.ok(parsed[0].warnings.length >= 1);
});
