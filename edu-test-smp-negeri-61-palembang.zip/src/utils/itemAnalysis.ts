export interface AttemptScoreRecord {
  studentId: number;
  studentName: string;
  className: string;
  finalScore: number;
  passed: boolean;
}

export interface ItemResponseRecord {
  studentId: number;
  totalStudentScore: number;
  questionId: number;
  questionNumber: number;
  questionType: string;
  stem: string;
  earnedScore: number;
  maxWeight: number;
  selectedOption?: string;
  correctOption?: string;
  options?: string[];
}

export interface ClassSummaryStats {
  totalParticipants: number;
  mean: number;
  median: number;
  min: number;
  max: number;
  stdDev: number;
  passCount: number;
  remedialCount: number;
  passRate: number;
  distribution: Array<{ label: string; count: number }>;
  classBreakdown: Array<{ className: string; mean: number; count: number; passRate: number }>;
}

export interface QuestionItemAnalysis {
  questionId: number;
  questionNumber: number;
  questionType: string;
  stem: string;
  attemptCount: number;
  pValue: number; // Tingkat Kesukaran (0..1)
  difficultyLabel: 'SUKAR' | 'SEDANG' | 'MUDAH';
  discriminationIndex: number; // Daya Pembeda (-1..1)
  discriminationLabel: 'BAIK_SEKALI' | 'BAIK' | 'CUKUP' | 'PERLU_REVISI';
  correctPercent: number;
  distractorStats: Array<{
    optionKey: string;
    count: number;
    percent: number;
    isCorrect: boolean;
    effective: boolean;
  }>;
}

export function computeClassSummary(
  attempts: AttemptScoreRecord[]
): ClassSummaryStats {
  const n = attempts.length;
  const buckets = [
    { label: '0–59', count: 0 },
    { label: '60–69', count: 0 },
    { label: '70–79', count: 0 },
    { label: '80–89', count: 0 },
    { label: '90–100', count: 0 },
  ];

  if (n === 0) {
    return {
      totalParticipants: 0,
      mean: 0,
      median: 0,
      min: 0,
      max: 0,
      stdDev: 0,
      passCount: 0,
      remedialCount: 0,
      passRate: 0,
      distribution: buckets,
      classBreakdown: [],
    };
  }

  const sorted = [...attempts].map((a) => a.finalScore).sort((a, b) => a - b);
  const sum = sorted.reduce((acc, v) => acc + v, 0);
  const mean = Number((sum / n).toFixed(2));
  const median =
    n % 2 === 1
      ? sorted[Math.floor(n / 2)]
      : Number(((sorted[n / 2 - 1] + sorted[n / 2]) / 2).toFixed(2));
  const min = sorted[0];
  const max = sorted[n - 1];
  const variance = sorted.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / n;
  const stdDev = Number(Math.sqrt(variance).toFixed(2));

  let passCount = 0;
  const byClass = new Map<string, { sum: number; count: number; passed: number }>();

  for (const a of attempts) {
    if (a.passed) passCount++;
    if (a.finalScore < 60) buckets[0].count++;
    else if (a.finalScore < 70) buckets[1].count++;
    else if (a.finalScore < 80) buckets[2].count++;
    else if (a.finalScore < 90) buckets[3].count++;
    else buckets[4].count++;

    const cKey = a.className || 'Umum';
    const cur = byClass.get(cKey) || { sum: 0, count: 0, passed: 0 };
    cur.sum += a.finalScore;
    cur.count += 1;
    if (a.passed) cur.passed += 1;
    byClass.set(cKey, cur);
  }

  const classBreakdown = Array.from(byClass.entries()).map(([className, data]) => ({
    className,
    mean: Number((data.sum / data.count).toFixed(2)),
    count: data.count,
    passRate: Number(((data.passed / data.count) * 100).toFixed(1)),
  }));

  return {
    totalParticipants: n,
    mean,
    median,
    min,
    max,
    stdDev,
    passCount,
    remedialCount: n - passCount,
    passRate: Number(((passCount / n) * 100).toFixed(1)),
    distribution: buckets,
    classBreakdown,
  };
}

export function computeItemAnalysis(
  responses: ItemResponseRecord[]
): QuestionItemAnalysis[] {
  const byQuestion = new Map<number, ItemResponseRecord[]>();
  for (const r of responses) {
    const arr = byQuestion.get(r.questionId) || [];
    arr.push(r);
    byQuestion.set(r.questionId, arr);
  }

  const analyses: QuestionItemAnalysis[] = [];

  for (const [questionId, items] of byQuestion.entries()) {
    const sample = items[0];
    const n = items.length;
    const totalRatio = items.reduce(
      (acc, it) => acc + (it.maxWeight > 0 ? it.earnedScore / it.maxWeight : 0),
      0
    );
    const pValue = n > 0 ? Number((totalRatio / n).toFixed(2)) : 0;

    const difficultyLabel: 'SUKAR' | 'SEDANG' | 'MUDAH' =
      pValue < 0.3 ? 'SUKAR' : pValue <= 0.7 ? 'SEDANG' : 'MUDAH';

    // Upper 27% vs Lower 27% by totalStudentScore
    const sortedByTotal = [...items].sort(
      (a, b) => b.totalStudentScore - a.totalStudentScore
    );
    const groupSize = Math.max(1, Math.round(n * 0.27));
    let discriminationIndex = 0;
    if (n >= 2) {
      const upper = sortedByTotal.slice(0, groupSize);
      const lower = sortedByTotal.slice(-groupSize);
      const pUpper =
        upper.reduce(
          (acc, it) => acc + (it.maxWeight > 0 ? it.earnedScore / it.maxWeight : 0),
          0
        ) / upper.length;
      const pLower =
        lower.reduce(
          (acc, it) => acc + (it.maxWeight > 0 ? it.earnedScore / it.maxWeight : 0),
          0
        ) / lower.length;
      discriminationIndex = Number((pUpper - pLower).toFixed(2));
    }

    const discriminationLabel:
      | 'BAIK_SEKALI'
      | 'BAIK'
      | 'CUKUP'
      | 'PERLU_REVISI' =
      discriminationIndex >= 0.4
        ? 'BAIK_SEKALI'
        : discriminationIndex >= 0.3
          ? 'BAIK'
          : discriminationIndex >= 0.2
            ? 'CUKUP'
            : 'PERLU_REVISI';

    const optionKeys = sample.options || [];
    const distractorStats = optionKeys.map((optKey) => {
      const count = items.filter(
        (it) => (it.selectedOption || '').toUpperCase() === optKey.toUpperCase()
      ).length;
      const percent = n > 0 ? Number(((count / n) * 100).toFixed(1)) : 0;
      const isCorrect =
        (sample.correctOption || '').toUpperCase() === optKey.toUpperCase();
      return {
        optionKey: optKey,
        count,
        percent,
        isCorrect,
        effective: isCorrect ? percent >= 25 : percent >= 5,
      };
    });

    analyses.push({
      questionId,
      questionNumber: sample.questionNumber,
      questionType: sample.questionType,
      stem: sample.stem,
      attemptCount: n,
      pValue,
      difficultyLabel,
      discriminationIndex,
      discriminationLabel,
      correctPercent: Number((pValue * 100).toFixed(1)),
      distractorStats,
    });
  }

  return analyses.sort((a, b) => a.questionNumber - b.questionNumber);
}
