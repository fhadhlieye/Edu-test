import type {
  QuestionItem,
  RoundingMode,
  StudentAnswerPayload,
} from '../types/exam';

export interface GradeQuestionResult {
  score: number;
  maxScore: number;
  isCorrect: boolean;
  isObjective: boolean;
  needsManualReview: boolean;
}

function normalizeShortText(
  raw: string,
  caseSensitive: boolean,
  ignoreWhitespace: boolean
): string {
  let out = raw.trim();
  if (ignoreWhitespace) {
    out = out.replace(/\s+/g, '');
  } else {
    out = out.replace(/\s+/g, ' ');
  }
  if (!caseSensitive) {
    out = out.toLowerCase();
  }
  return out;
}

function parseNumericMaybe(val: string): number | null {
  const cleaned = val.trim().replace(',', '.');
  if (!/^[-+]?\d+(\.\d+)?$/.test(cleaned)) return null;
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : null;
}

export function gradeObjectiveQuestion(
  question: Pick<
    QuestionItem,
    | 'questionType'
    | 'correctAnswer'
    | 'matchingPairs'
    | 'shortAnswerConfig'
    | 'weight'
    | 'partialScoring'
    | 'pgkMode'
  >,
  rawAnswer: StudentAnswerPayload | null | undefined
): GradeQuestionResult {
  const maxScore = Math.max(0, Number(question.weight) || 1);

  if (question.questionType === 'ESAI') {
    return {
      score: 0,
      maxScore,
      isCorrect: false,
      isObjective: false,
      needsManualReview: true,
    };
  }

  if (rawAnswer === null || rawAnswer === undefined || rawAnswer === '') {
    return {
      score: 0,
      maxScore,
      isCorrect: false,
      isObjective: true,
      needsManualReview: false,
    };
  }

  if (question.questionType === 'PG') {
    const expected = String(question.correctAnswer || '').trim().toUpperCase();
    const actual = String(rawAnswer).trim().toUpperCase();
    const isCorrect = expected.length > 0 && actual === expected;
    return {
      score: isCorrect ? maxScore : 0,
      maxScore,
      isCorrect,
      isObjective: true,
      needsManualReview: false,
    };
  }

  if (question.questionType === 'PG_KOMPLEKS') {
    const expectedList = Array.isArray(question.correctAnswer)
      ? question.correctAnswer.map((v) => v.trim().toUpperCase()).filter(Boolean)
      : String(question.correctAnswer || '')
          .split(',')
          .map((v) => v.trim().toUpperCase())
          .filter(Boolean);
    const actualList = Array.isArray(rawAnswer)
      ? Array.from(new Set(rawAnswer.map((v) => String(v).trim().toUpperCase()).filter(Boolean)))
      : [];

    if (expectedList.length === 0) {
      return { score: 0, maxScore, isCorrect: false, isObjective: true, needsManualReview: false };
    }

    const expectedSet = new Set(expectedList);
    const actualSet = new Set(actualList);

    const exactMatch =
      expectedSet.size === actualSet.size &&
      [...expectedSet].every((k) => actualSet.has(k));

    if (question.pgkMode === 'ALL_OR_NOTHING' && !question.partialScoring) {
      return {
        score: exactMatch ? maxScore : 0,
        maxScore,
        isCorrect: exactMatch,
        isObjective: true,
        needsManualReview: false,
      };
    }

    // Partial scoring: +1 per correct choice, -0.5 penalty per wrong choice, normalized to maxScore
    let correctPicked = 0;
    let wrongPicked = 0;
    for (const ans of actualSet) {
      if (expectedSet.has(ans)) correctPicked++;
      else wrongPicked++;
    }
    const rawRatio = Math.max(
      0,
      (correctPicked - wrongPicked * 0.5) / expectedSet.size
    );
    const score = Number((Math.min(1, rawRatio) * maxScore).toFixed(2));
    return {
      score,
      maxScore,
      isCorrect: exactMatch,
      isObjective: true,
      needsManualReview: false,
    };
  }

  if (question.questionType === 'MENJODOHKAN') {
    const pairs = question.matchingPairs || [];
    if (pairs.length === 0 || typeof rawAnswer !== 'object' || Array.isArray(rawAnswer)) {
      return { score: 0, maxScore, isCorrect: false, isObjective: true, needsManualReview: false };
    }
    let matchedCount = 0;
    for (const pair of pairs) {
      const selected = (rawAnswer[pair.id] || '').trim();
      if (selected && selected.toLowerCase() === pair.rightText.trim().toLowerCase()) {
        matchedCount++;
      }
    }
    const allMatched = matchedCount === pairs.length;
    if (!question.partialScoring) {
      return {
        score: allMatched ? maxScore : 0,
        maxScore,
        isCorrect: allMatched,
        isObjective: true,
        needsManualReview: false,
      };
    }
    const score = Number(((matchedCount / pairs.length) * maxScore).toFixed(2));
    return {
      score,
      maxScore,
      isCorrect: allMatched,
      isObjective: true,
      needsManualReview: false,
    };
  }

  if (question.questionType === 'ISIAN_SINGKAT') {
    const cfg = question.shortAnswerConfig || {
      acceptedAnswers: [],
      caseSensitive: false,
      ignoreWhitespace: false,
      numericTolerance: 0,
    };
    const accepted =
      cfg.acceptedAnswers && cfg.acceptedAnswers.length > 0
        ? cfg.acceptedAnswers
        : [String(question.correctAnswer || '')].filter(Boolean);

    const actualStr = String(rawAnswer);
    const actualNum = parseNumericMaybe(actualStr);

    const isMatch = accepted.some((candidate) => {
      if (actualNum !== null) {
        const candNum = parseNumericMaybe(candidate);
        if (candNum !== null) {
          return Math.abs(actualNum - candNum) <= (cfg.numericTolerance || 0);
        }
      }
      return (
        normalizeShortText(actualStr, cfg.caseSensitive, cfg.ignoreWhitespace) ===
        normalizeShortText(candidate, cfg.caseSensitive, cfg.ignoreWhitespace)
      );
    });

    return {
      score: isMatch ? maxScore : 0,
      maxScore,
      isCorrect: isMatch,
      isObjective: true,
      needsManualReview: false,
    };
  }

  return { score: 0, maxScore, isCorrect: false, isObjective: true, needsManualReview: false };
}

export function applyRounding(value: number, mode: RoundingMode): number {
  switch (mode) {
    case 'NEAREST':
      return Math.round(value);
    case 'CEIL':
      return Math.ceil(value);
    case 'FLOOR':
      return Math.floor(value);
    case 'NONE':
    default:
      return Number(value.toFixed(2));
  }
}

export interface ExamScoreSummary {
  objectivePoints: number;
  essayPoints: number;
  totalEarnedPoints: number;
  totalMaxPoints: number;
  normalizedScore: number;
  passed: boolean;
  needsRemedial: boolean;
  hasPendingEssay: boolean;
}

export function calculateExamSummary(
  items: Array<{
    earnedObjective: number;
    earnedManual: number | null;
    maxPoints: number;
    isEssay: boolean;
    isGraded: boolean;
  }>,
  config: {
    maxScore: number;
    passingScore: number;
    roundingMode: RoundingMode;
  }
): ExamScoreSummary {
  let objectivePoints = 0;
  let essayPoints = 0;
  let totalMaxPoints = 0;
  let hasPendingEssay = false;

  for (const item of items) {
    totalMaxPoints += item.maxPoints;
    if (item.isEssay) {
      if (item.isGraded && item.earnedManual !== null) {
        essayPoints += Math.min(item.maxPoints, Math.max(0, item.earnedManual));
      } else {
        hasPendingEssay = true;
      }
    } else {
      objectivePoints += item.earnedObjective;
    }
  }

  const totalEarnedPoints = objectivePoints + essayPoints;
  const rawNormalized =
    totalMaxPoints > 0 ? (totalEarnedPoints / totalMaxPoints) * config.maxScore : 0;
  const normalizedScore = applyRounding(rawNormalized, config.roundingMode);
  const passed = normalizedScore >= config.passingScore;

  return {
    objectivePoints: Number(objectivePoints.toFixed(2)),
    essayPoints: Number(essayPoints.toFixed(2)),
    totalEarnedPoints: Number(totalEarnedPoints.toFixed(2)),
    totalMaxPoints: Number(totalMaxPoints.toFixed(2)),
    normalizedScore,
    passed,
    needsRemedial: !passed && !hasPendingEssay,
    hasPendingEssay,
  };
}
