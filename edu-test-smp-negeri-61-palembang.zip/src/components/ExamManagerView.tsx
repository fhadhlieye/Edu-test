import React, { useEffect, useState } from 'react';
import {
  Copy,
  Edit3,
  FileText,
  Play,
  Plus,
  Printer,
  Shield,
  StopCircle,
  X,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import { MathText } from './SchoolCrest';
import {
  downloadBeritaAcaraPdf,
  downloadDaftarPesertaPdf,
} from '../utils/pdfReport';
import type { ExamConfig, QuestionItem, SchoolProfile } from '../types/exam';

export function ExamManagerView({
  school,
  onOpenMonitor,
  onOpenGrading,
}: {
  school: SchoolProfile | null;
  onOpenMonitor: (examId: number) => void;
  onOpenGrading: (examId: number) => void;
}) {
  const [exams, setExams] = useState<ExamConfig[]>([]);
  const [subjects, setSubjects] = useState<Array<{ id: number; name: string }>>([]);
  const [classes, setClasses] = useState<Array<{ id: number; name: string; grade_level: string }>>([]);
  const [bankQuestions, setBankQuestions] = useState<QuestionItem[]>([]);
  const [loading, setLoading] = useState(true);

  const [editing, setEditing] = useState<any | null>(null);
  const [selectedQIds, setSelectedQIds] = useState<number[]>([]);
  const [saving, setSaving] = useState(false);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [exRes, refRes, qRes] = await Promise.all([
        apiFetch<{ exams: ExamConfig[] }>('/api/exams'),
        apiFetch<{ subjects: any[]; classes: any[] }>('/api/admin/reference-data'),
        apiFetch<{ questions: QuestionItem[] }>('/api/questions'),
      ]);
      setExams(exRes.exams || []);
      setSubjects(refRes.subjects || []);
      setClasses(refRes.classes || []);
      setBankQuestions(qRes.questions || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const openNewExam = () => {
    setEditing({
      title: '',
      subjectId: subjects[0]?.id || 1,
      semester: school?.activeSemester || 'Ganjil',
      academicYear: school?.academicYear || '2025/2026',
      targetClassIds: classes.map((c) => c.id),
      scheduledDate: new Date().toISOString().slice(0, 10),
      startTime: '07:30',
      endTime: '12:00',
      durationMinutes: 60,
      maxScore: 100,
      passingScore: 75,
      roundingMode: 'NEAREST',
      maxAttempts: 1,
      allowRemedial: true,
      showScoreImmediately: true,
      randomizeQuestions: false,
      randomizeOptions: false,
      allowBackNavigation: true,
      antiCheatEnabled: true,
      requireFullscreen: true,
      maxViolations: 3,
      lockOnMaxViolations: true,
      lowBandwidthMode: false,
      instructions:
        'Bacalah setiap soal dan stimulus dengan teliti. Dilarang membuka tab lain selama ujian berlangsung.',
      status: 'ACTIVE',
    });
    setSelectedQIds([]);
  };

  const openEditExam = async (examId: number) => {
    const res = await apiFetch<{ exam: ExamConfig; questions: Array<{ id: number }> }>(
      `/api/exams/${examId}/detail`
    );
    setEditing(res.exam);
    setSelectedQIds(res.questions.map((q) => q.id));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing || !editing.title.trim()) return;
    setSaving(true);
    try {
      const payload = { ...editing, questionIds: selectedQIds };
      if (editing.id) {
        await apiFetch(`/api/exams/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
      } else {
        await apiFetch('/api/exams', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      }
      setEditing(null);
      loadAll();
    } finally {
      setSaving(false);
    }
  };

  const handleStatusChange = async (examId: number, status: string) => {
    await apiFetch(`/api/exams/${examId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    loadAll();
  };

  const handleDuplicate = async (examId: number) => {
    await apiFetch(`/api/exams/${examId}/duplicate`, { method: 'POST' });
    loadAll();
  };

  const handlePrintBeritaAcara = async (exam: ExamConfig) => {
    const mon = await apiFetch<{ attempts: any[]; notStarted: any[] }>(
      `/api/exams/${exam.id}/monitor`
    );
    downloadBeritaAcaraPdf({
      school,
      examTitle: exam.title,
      subjectName: exam.subjectName || '-',
      scheduledDate: exam.scheduledDate,
      startTime: exam.startTime,
      endTime: exam.endTime,
      totalParticipants: mon.attempts.length,
      notStartedCount: mon.notStarted.length,
      teacherName: exam.creatorName || 'Guru Mata Pelajaran',
    });
  };

  const handlePrintDaftarPeserta = async (exam: ExamConfig) => {
    const mon = await apiFetch<{ attempts: any[]; notStarted: any[] }>(
      `/api/exams/${exam.id}/monitor`
    );
    const rows = [
      ...mon.attempts.map((a) => ({
        nip_nisn: a.nip_nisn,
        full_name: a.student_name,
        class_name: a.class_name,
        status: a.status,
      })),
      ...mon.notStarted.map((s) => ({
        nip_nisn: s.nip_nisn,
        full_name: s.full_name,
        class_name: s.class_name,
        status: 'BELUM_MULAI',
      })),
    ];
    downloadDaftarPesertaPdf({
      school,
      examTitle: exam.title,
      subjectName: exam.subjectName || '-',
      scheduledDate: exam.scheduledDate,
      students: rows,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Manajemen &amp; Jadwal Ujian
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Atur jadwal, kelas peserta, pengacakan soal, mode anti-curang, serta cetak dokumen ujian.
          </p>
        </div>
        <button
          type="button"
          onClick={openNewExam}
          className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          Buat Ujian Baru
        </button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="h-32 bg-white border border-slate-200 rounded-lg animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {exams.map((ex) => (
            <div
              key={ex.id}
              className="bg-white border border-slate-200 rounded-lg p-5 space-y-4"
            >
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span
                      className={`font-semibold ${
                        ex.status === 'ACTIVE'
                          ? 'text-emerald-700'
                          : ex.status === 'CLOSED'
                            ? 'text-slate-600'
                            : 'text-blue-700'
                      }`}
                    >
                      {ex.status === 'ACTIVE'
                        ? 'Sedang Dibuka'
                        : ex.status === 'PUBLISHED'
                          ? 'Terjadwal'
                          : ex.status === 'CLOSED'
                            ? 'Selesai'
                            : 'Draf'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{ex.subjectName}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{ex.questionCount} soal</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{ex.durationMinutes} menit</span>
                    <span aria-hidden="true">·</span>
                    <span>KKM {ex.passingScore}</span>
                  </div>
                  <h2 className="font-display text-lg font-bold text-slate-900">
                    {ex.title}
                  </h2>
                  <p className="text-xs text-slate-600">
                    Jadwal: {ex.scheduledDate} ({ex.startTime}–{ex.endTime}) · Kelas:{' '}
                    {ex.targetClassNames?.join(', ') || 'Semua'} · Anti-Curang:{' '}
                    {ex.antiCheatEnabled ? `Aktif (Maks ${ex.maxViolations}x)` : 'Nonaktif'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  {ex.status !== 'ACTIVE' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(ex.id, 'ACTIVE')}
                      className="inline-flex items-center gap-1 rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5" />
                      Buka Ujian
                    </button>
                  )}
                  {ex.status === 'ACTIVE' && (
                    <button
                      type="button"
                      onClick={() => handleStatusChange(ex.id, 'CLOSED')}
                      className="inline-flex items-center gap-1 rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100 cursor-pointer"
                    >
                      <StopCircle className="w-3.5 h-3.5" />
                      Tutup Ujian
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onOpenMonitor(ex.id)}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    <Shield className="w-3.5 h-3.5 text-blue-700" />
                    Pantau
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenGrading(ex.id)}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-amber-600" />
                    Hasil &amp; Analisis
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-3 text-xs">
                <button
                  type="button"
                  onClick={() => openEditExam(ex.id)}
                  className="inline-flex items-center gap-1 text-slate-700 hover:text-blue-700 font-medium cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  Edit Pengaturan &amp; Soal
                </button>
                <button
                  type="button"
                  onClick={() => handleDuplicate(ex.id)}
                  className="inline-flex items-center gap-1 text-slate-700 hover:text-blue-700 font-medium cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Duplikasi Ujian
                </button>
                <button
                  type="button"
                  onClick={() => handlePrintDaftarPeserta(ex)}
                  className="inline-flex items-center gap-1 text-slate-700 hover:text-blue-700 font-medium cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Cetak Daftar Peserta
                </button>
                <button
                  type="button"
                  onClick={() => handlePrintBeritaAcara(ex)}
                  className="inline-flex items-center gap-1 text-slate-700 hover:text-blue-700 font-medium cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Cetak Berita Acara
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Exam Builder Modal */}
      {editing && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4"
        >
          <form
            onSubmit={handleSave}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-4xl max-h-[92vh] overflow-y-auto p-6 space-y-5"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="font-display text-lg font-bold text-slate-900">
                {editing.id ? 'Edit Konfigurasi Ujian' : 'Buat Ujian Digital Baru'}
              </h2>
              <button
                type="button"
                aria-label="Tutup form ujian"
                onClick={() => setEditing(null)}
                className="p-1 text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Ujian
                </label>
                <input
                  type="text"
                  required
                  value={editing.title}
                  onChange={(e) =>
                    setEditing({ ...editing, title: e.target.value })
                  }
                  placeholder="Contoh: Sumatif Akhir Semester Matematika Kelas IX"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mata Pelajaran
                </label>
                <select
                  value={editing.subjectId}
                  onChange={(e) =>
                    setEditing({ ...editing, subjectId: Number(e.target.value) })
                  }
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Status Publikasi
                </label>
                <select
                  value={editing.status}
                  onChange={(e) =>
                    setEditing({ ...editing, status: e.target.value })
                  }
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="DRAFT">Draf (Belum Tampil)</option>
                  <option value="PUBLISHED">Terjadwal</option>
                  <option value="ACTIVE">Aktif / Dibuka Sekarang</option>
                  <option value="CLOSED">Selesai / Ditutup</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    value={editing.scheduledDate}
                    onChange={(e) =>
                      setEditing({ ...editing, scheduledDate: e.target.value })
                    }
                    className="w-full rounded-lg border border-slate-300 px-2 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mulai
                  </label>
                  <input
                    type="time"
                    value={editing.startTime}
                    onChange={(e) =>
                      setEditing({ ...editing, startTime: e.target.value })
                    }
                    className="w-full rounded-lg border border-slate-300 px-2 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Selesai
                  </label>
                  <input
                    type="time"
                    value={editing.endTime}
                    onChange={(e) =>
                      setEditing({ ...editing, endTime: e.target.value })
                    }
                    className="w-full rounded-lg border border-slate-300 px-2 py-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Durasi (mnt)
                  </label>
                  <input
                    type="number"
                    min={5}
                    value={editing.durationMinutes}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        durationMinutes: Number(e.target.value) || 60,
                      })
                    }
                    className="w-full rounded-lg border border-slate-300 px-2 py-2 text-xs tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nilai Maks
                  </label>
                  <input
                    type="number"
                    min={10}
                    value={editing.maxScore}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        maxScore: Number(e.target.value) || 100,
                      })
                    }
                    className="w-full rounded-lg border border-slate-300 px-2 py-2 text-xs tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    KKM
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={editing.passingScore}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        passingScore: Number(e.target.value) || 75,
                      })
                    }
                    className="w-full rounded-lg border border-slate-300 px-2 py-2 text-xs tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Batas Coba
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={editing.maxAttempts}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        maxAttempts: Number(e.target.value) || 1,
                      })
                    }
                    className="w-full rounded-lg border border-slate-300 px-2 py-2 text-xs tabular-nums"
                  />
                </div>
              </div>
            </div>

            {/* Target Classes */}
            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-1.5">
                Rombongan Belajar Peserta Ujian
              </span>
              <div className="flex flex-wrap gap-2">
                {classes.map((c) => {
                  const checked = editing.targetClassIds.includes(c.id);
                  return (
                    <label
                      key={c.id}
                      className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium cursor-pointer ${
                        checked
                          ? 'border-blue-600 bg-blue-50 text-blue-800'
                          : 'border-slate-200 bg-white text-slate-700'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => {
                          const next = checked
                            ? editing.targetClassIds.filter((id: number) => id !== c.id)
                            : [...editing.targetClassIds, c.id];
                          setEditing({ ...editing, targetClassIds: next });
                        }}
                      />
                      {c.name}
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Settings Checkboxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded-lg p-3.5">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editing.randomizeQuestions}
                  onChange={(e) =>
                    setEditing({ ...editing, randomizeQuestions: e.target.checked })
                  }
                />
                Acak urutan soal per siswa
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editing.randomizeOptions}
                  onChange={(e) =>
                    setEditing({ ...editing, randomizeOptions: e.target.checked })
                  }
                />
                Acak pilihan jawaban (A–E)
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editing.showScoreImmediately}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      showScoreImmediately: e.target.checked,
                    })
                  }
                />
                Tampilkan nilai langsung ke siswa
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editing.antiCheatEnabled}
                  onChange={(e) =>
                    setEditing({ ...editing, antiCheatEnabled: e.target.checked })
                  }
                />
                Aktifkan Pengawasan Anti-Curang
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editing.requireFullscreen}
                  onChange={(e) =>
                    setEditing({ ...editing, requireFullscreen: e.target.checked })
                  }
                />
                Wajib Mode Layar Penuh (Fullscreen)
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editing.lockOnMaxViolations}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      lockOnMaxViolations: e.target.checked,
                    })
                  }
                />
                Kunci sementara jika melebihi batas ({editing.maxViolations}x)
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={editing.lowBandwidthMode}
                  onChange={(e) =>
                    setEditing({ ...editing, lowBandwidthMode: e.target.checked })
                  }
                />
                Mode Hemat Bandwidth
              </label>
              <label className="flex items-center gap-2">
                <span>Pembulatan:</span>
                <select
                  value={editing.roundingMode}
                  onChange={(e) =>
                    setEditing({ ...editing, roundingMode: e.target.value })
                  }
                  className="rounded border border-slate-300 bg-white px-2 py-0.5"
                >
                  <option value="NEAREST">Terdekat</option>
                  <option value="CEIL">Ke Atas</option>
                  <option value="FLOOR">Ke Bawah</option>
                  <option value="NONE">Desimal</option>
                </select>
              </label>
              <label className="flex items-center gap-2">
                <span>Maks Pelanggaran:</span>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={editing.maxViolations}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      maxViolations: Number(e.target.value) || 3,
                    })
                  }
                  className="w-14 rounded border border-slate-300 bg-white px-2 py-0.5 tabular-nums"
                />
              </label>
            </div>

            {/* Pick Questions from Bank Soal */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-700">
                  Pilih Soal dari Bank Soal ({selectedQIds.length} terpilih)
                </span>
                <button
                  type="button"
                  onClick={() =>
                    setSelectedQIds(
                      selectedQIds.length === bankQuestions.length
                        ? []
                        : bankQuestions.map((q) => Number(q.id))
                    )
                  }
                  className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
                >
                  {selectedQIds.length === bankQuestions.length
                    ? 'Hapus Semua Pilihan'
                    : 'Pilih Semua Soal'}
                </button>
              </div>
              <div className="max-h-52 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100">
                {bankQuestions.map((q) => {
                  const qid = Number(q.id);
                  const checked = selectedQIds.includes(qid);
                  return (
                    <label
                      key={qid}
                      className="flex items-start gap-2.5 p-2.5 text-xs hover:bg-slate-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() =>
                          setSelectedQIds((prev) =>
                            checked
                              ? prev.filter((x) => x !== qid)
                              : [...prev, qid]
                          )
                        }
                        className="mt-0.5"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-semibold text-slate-800">
                          [{q.questionType}] {q.subjectName} · {q.topic} (Bobot {q.weight})
                        </div>
                        <div className="text-slate-600 line-clamp-2">
                          <MathText text={q.stem} />
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={saving}
                className="rounded-lg bg-blue-700 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60 cursor-pointer"
              >
                {saving ? 'Menyimpan...' : 'Simpan Pengaturan Ujian'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
