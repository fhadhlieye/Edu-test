import React, { useState } from 'react';

export function BarDistributionChart({
  data,
  height = 190,
  barColor = '#2563EB',
  unitLabel = 'siswa',
}: {
  data: Array<{ label: string; value: number; subtitle?: string }>;
  height?: number;
  barColor?: string;
  unitLabel?: string;
}) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const maxVal = Math.max(1, ...data.map((d) => d.value));

  return (
    <div className="w-full">
      <div
        className="flex items-end gap-3 pt-6 pb-2 px-2 border-b border-slate-200"
        style={{ height }}
      >
        {data.map((d, idx) => {
          const pct = Math.max(4, Math.round((d.value / maxVal) * 100));
          const isHovered = hoverIdx === idx;
          return (
            <div
              key={d.label}
              className="flex-1 flex flex-col items-center justify-end h-full relative"
              onMouseEnter={() => setHoverIdx(idx)}
              onMouseLeave={() => setHoverIdx(null)}
            >
              {isHovered && (
                <div className="absolute -top-2 bg-slate-900 text-white text-xs px-2 py-1 rounded shadow-sm whitespace-nowrap z-10 tabular-nums">
                  {d.label}: {d.value} {unitLabel}
                </div>
              )}
              <span className="text-xs font-medium text-slate-600 mb-1 tabular-nums">
                {d.value}
              </span>
              <div
                className="w-full max-w-[46px] rounded-t-md transition-opacity"
                style={{
                  height: d.value === 0 ? '2px' : `${pct}%`,
                  backgroundColor: d.value === 0 ? '#CBD5E1' : barColor,
                  opacity: hoverIdx === null || isHovered ? 1 : 0.65,
                }}
              />
            </div>
          );
        })}
      </div>
      <div className="flex items-center gap-3 px-2 pt-2">
        {data.map((d) => (
          <div
            key={d.label}
            className="flex-1 text-center text-xs text-slate-600 truncate"
            title={d.label}
          >
            {d.label}
          </div>
        ))}
      </div>
    </div>
  );
}

export function PassRateDonut({
  passCount,
  remedialCount,
}: {
  passCount: number;
  remedialCount: number;
}) {
  const total = passCount + remedialCount;
  const passPct = total > 0 ? Math.round((passCount / total) * 100) : 0;
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (passPct / 100) * circumference;

  return (
    <div className="flex items-center gap-6">
      <div className="relative w-32 h-32 shrink-0">
        <svg viewBox="0 0 128 128" className="w-full h-full -rotate-90">
          <circle
            cx="64"
            cy="64"
            r={radius}
            fill="none"
            stroke="#E2E8F0"
            strokeWidth="14"
          />
          <circle
            cx="64"
            cy="64"
            r={radius}
            fill="none"
            stroke="#1D4ED8"
            strokeWidth="14"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-slate-900 tabular-nums">
            {passPct}%
          </span>
          <span className="text-[11px] text-slate-500">Tuntas</span>
        </div>
      </div>
      <div className="space-y-2.5 text-sm">
        <div className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-2 text-slate-700">
            <span className="w-2.5 h-2.5 rounded-sm bg-blue-700 inline-block" />
            Mencapai KKM
          </span>
          <span className="font-semibold text-slate-900 tabular-nums">
            {passCount} siswa
          </span>
        </div>
        <div className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-2 text-slate-700">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 inline-block" />
            Perlu Remedial
          </span>
          <span className="font-semibold text-slate-900 tabular-nums">
            {remedialCount} siswa
          </span>
        </div>
      </div>
    </div>
  );
}

export function TrendLineChart({
  points,
}: {
  points: Array<{ label: string; value: number }>;
}) {
  if (points.length === 0) {
    return (
      <div className="h-44 flex items-center justify-center text-sm text-slate-500">
        Belum ada data tren ujian selesai.
      </div>
    );
  }
  const w = 440;
  const h = 150;
  const padX = 34;
  const padY = 20;
  const innerW = w - padX * 2;
  const innerH = h - padY * 2;

  const coords = points.map((p, idx) => {
    const x =
      points.length === 1
        ? padX + innerW / 2
        : padX + (idx / (points.length - 1)) * innerW;
    const y = padY + innerH - (Math.min(100, Math.max(0, p.value)) / 100) * innerH;
    return { ...p, x, y };
  });

  const poly = coords.map((c) => `${c.x},${c.y}`).join(' ');

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${w} ${h + 24}`} className="w-full min-w-[320px] h-44">
        {[0, 50, 75, 100].map((tick) => {
          const ty = padY + innerH - (tick / 100) * innerH;
          return (
            <g key={tick}>
              <line
                x1={padX}
                y1={ty}
                x2={w - padX}
                y2={ty}
                stroke={tick === 75 ? '#F59E0B' : '#E2E8F0'}
                strokeDasharray={tick === 75 ? '4 4' : undefined}
                strokeWidth="1"
              />
              <text
                x={6}
                y={ty + 4}
                fontSize="10"
                fill="#64748B"
                className="tabular-nums"
              >
                {tick}
              </text>
            </g>
          );
        })}
        {coords.length > 1 && (
          <polyline
            fill="none"
            stroke="#1D4ED8"
            strokeWidth="2.5"
            points={poly}
          />
        )}
        {coords.map((c, idx) => (
          <g key={idx}>
            <circle cx={c.x} cy={c.y} r="4.5" fill="#1D4ED8" stroke="#FFFFFF" strokeWidth="2" />
            <text
              x={c.x}
              y={c.y - 9}
              textAnchor="middle"
              fontSize="10.5"
              fontWeight="600"
              fill="#0F172A"
            >
              {c.value}
            </text>
            <text
              x={c.x}
              y={h + 14}
              textAnchor="middle"
              fontSize="10"
              fill="#64748B"
            >
              {c.label.length > 14 ? `${c.label.slice(0, 14)}…` : c.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}
