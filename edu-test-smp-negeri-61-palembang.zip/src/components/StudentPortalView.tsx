import React, { useEffect, useState } from 'react';
import {
  Bell,
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  FileCheck,
  IdCard,
  PlayCircle,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import { downloadStudentCardPdf } from '../utils/pdfReport';
import { SchoolCrest } from './SchoolCrest';
import type { SchoolProfile, UserAccount } from '../types/exam';

export function StudentPortalView({
  user,
  school,
  onStartExam,
}: {
  user: UserAccount;
  school: SchoolProfile | null;
  onStartExam: (examId: number) => void;
}) {
  const [exams, setExams] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<
    'exams' | 'schedule' | 'history' | 'card'
  >('exams');
  const [previewExam, setPreviewExam] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      apiFetch<{ exams: any[] }>('/api/exams'),
      apiFetch<{ history: any[] }>('/api/analytics/student/history'),
      apiFetch<{ announcements: any[] }>('/api/auth/announcements'),
    ])
      .then(([exRes, hRes, aRes]) => {
        setExams(exRes.exams || []);
        setHistory(hRes.history || []);
        setAnnouncements(aRes.announcements || []);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-28 bg-white border border-slate-200 rounded-lg animate-pulse" />
        <div className="h-48 bg-white border border-slate-200 rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Portal Ujian Siswa
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            {user.fullName} · NISN {user.nipNisn} · Kelas {user.className || '-'}
          </p>
        </div>

        <div className="flex flex-wrap gap-1 bg-slate-200/70 p-1 rounded-lg">
          {(
            [
              ['exams', 'Ujian Tersedia'],
              ['schedule', 'Jadwal Ujian'],
              ['history', 'Riwayat & Nilai'],
              ['card', 'Kartu Peserta'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setActiveTab(id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer whitespace-nowrap ${
                activeTab === id
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Announcements Banner */}
      {announcements.length > 0 && activeTab === 'exams' && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-900">
            <Bell className="w-4 h-4 text-blue-700" />
            <span>Pengumuman Sekolah</span>
          </div>
          {announcements.slice(0, 2).map((a) => (
            <div key={a.id} className="text-xs text-blue-950">
              <span className="font-semibold">{a.title}:</span> {a.content}
            </div>
          ))}
        </div>
      )}

      {activeTab === 'exams' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {exams.length === 0 ? (
            <div className="md:col-span-2 bg-white border border-slate-200 rounded-lg p-10 text-center text-sm text-slate-500">
              Belum ada ujian yang dijadwalkan untuk kelas Anda saat ini.
            </div>
          ) : (
            exams.map((ex) => {
              const latest = ex.myLatestAttempt;
              const attemptsUsed = ex.myAttempts?.length || 0;
              const inProgress =
                latest &&
                (latest.status === 'IN_PROGRESS' || latest.status === 'LOCKED');
              const canStart =
                ex.status === 'ACTIVE' &&
                (inProgress || attemptsUsed < ex.maxAttempts);

              return (
                <div
                  key={ex.id}
                  className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="font-semibold text-blue-700">
                        {ex.subjectName}
                      </span>
                      <span
                        className={`font-semibold ${
                          ex.status === 'ACTIVE'
                            ? 'text-emerald-700'
                            : 'text-slate-600'
                        }`}
                      >
                        {ex.status === 'ACTIVE'
                          ? 'Sedang Dibuka'
                          : ex.status === 'PUBLISHED'
                            ? 'Terjadwal'
                            : 'Selesai'}
                      </span>
                    </div>
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      {ex.title}
                    </h2>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 pt-1">
                      <span className="inline-flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {ex.scheduledDate}
                      </span>
                      <span className="inline-flex items-center gap-1 tabular-nums">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        {ex.durationMinutes} menit
                      </span>
                      <span className="tabular-nums">{ex.questionCount} soal</span>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                    {latest && (latest.status === 'SUBMITTED' || latest.status === 'GRADED') ? (
                      <div className="text-xs">
                        <span className="text-slate-500">Nilai Terakhir: </span>
                        <span className="font-mono-tabular font-bold text-slate-900">
                          {latest.finalScore !== null
                            ? latest.finalScore
                            : 'Menunggu pengumuman'}
                        </span>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-500 tabular-nums">
                        Percobaan: {attemptsUsed}/{ex.maxAttempts}
                      </span>
                    )}

                    {canStart ? (
                      <button
                        type="button"
                        onClick={() => setPreviewExam(ex)}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 cursor-pointer whitespace-nowrap"
                      >
                        <PlayCircle className="w-4 h-4" />
                        {inProgress ? 'Lanjutkan Ujian' : 'Mulai Ujian'}
                      </button>
                    ) : (
                      <span className="text-xs font-medium text-slate-400">
                        {ex.status === 'PUBLISHED'
                          ? 'Belum Dibuka'
                          : 'Selesai Dikerjakan'}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {activeTab === 'schedule' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-display text-base font-bold text-slate-900 mb-3">
            Jadwal Ujian Terintegrasi
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-200 text-slate-500">
                <tr>
                  <th className="py-2 pr-3 font-semibold">Tanggal</th>
                  <th className="py-2 pr-3 font-semibold">Waktu</th>
                  <th className="py-2 pr-3 font-semibold">Mata Pelajaran</th>
                  <th className="py-2 pr-3 font-semibold">Nama Ujian</th>
                  <th className="py-2 pr-3 font-semibold text-right">Durasi</th>
                  <th className="py-2 font-semibold text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {exams.map((ex) => (
                  <tr key={ex.id}>
                    <td className="py-2.5 pr-3 font-mono-tabular">{ex.scheduledDate}</td>
                    <td className="py-2.5 pr-3 font-mono-tabular">
                      {ex.startTime}–{ex.endTime}
                    </td>
                    <td className="py-2.5 pr-3">{ex.subjectName}</td>
                    <td className="py-2.5 pr-3 font-semibold text-slate-900">
                      {ex.title}
                    </td>
                    <td className="py-2.5 pr-3 text-right tabular-nums">
                      {ex.durationMinutes} mnt
                    </td>
                    <td className="py-2.5 text-right font-semibold">{ex.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-display text-base font-bold text-slate-900 mb-3">
            Riwayat &amp; Hasil Ujian Saya
          </h2>
          {history.length === 0 ? (
            <p className="text-sm text-slate-500 py-6 text-center">
              Anda belum memiliki riwayat pengerjaan ujian.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 text-slate-500">
                  <tr>
                    <th className="py-2 pr-3 font-semibold">Ujian</th>
                    <th className="py-2 pr-3 font-semibold">Mapel</th>
                    <th className="py-2 pr-3 font-semibold">Tanggal</th>
                    <th className="py-2 pr-3 font-semibold">Status</th>
                    <th className="py-2 pr-3 font-semibold text-right">Nilai</th>
                    <th className="py-2 font-semibold text-right">Ketuntasan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {history.map((h) => (
                    <tr key={h.id}>
                      <td className="py-2.5 pr-3 font-semibold text-slate-900">
                        {h.examTitle}
                      </td>
                      <td className="py-2.5 pr-3 text-slate-600">{h.subjectName}</td>
                      <td className="py-2.5 pr-3 font-mono-tabular text-slate-500">
                        {h.scheduledDate}
                      </td>
                      <td className="py-2.5 pr-3">{h.status}</td>
                      <td className="py-2.5 pr-3 text-right font-mono-tabular font-bold text-slate-900">
                        {h.scoreHidden ? 'Ditahan Guru' : h.finalScore}
                      </td>
                      <td className="py-2.5 text-right">
                        {h.scoreHidden ? (
                          <span className="text-slate-400">—</span>
                        ) : h.passed ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Tuntas (KKM {h.passingScore})
                          </span>
                        ) : (
                          <span className="font-semibold text-amber-700">
                            Perlu Remedial
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'card' && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 max-w-2xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <div className="flex items-center gap-3">
              <SchoolCrest className="w-12 h-12" />
              <div>
                <div className="text-xs font-semibold text-blue-700">
                  KARTU PESERTA UJIAN DIGITAL
                </div>
                <div className="font-display text-lg font-bold text-slate-900">
                  {school?.name || 'SMP Negeri 61 Palembang'}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() =>
                downloadStudentCardPdf({
                  school,
                  student: user,
                  exams,
                })
              }
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Unduh Kartu PDF
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-xs text-slate-500 block">Nama Peserta</span>
              <span className="font-semibold text-slate-900">{user.fullName}</span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">NIS / NISN</span>
              <span className="font-mono-tabular font-semibold text-slate-900">
                {user.nipNisn || '-'}
              </span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Kelas / Rombel</span>
              <span className="font-semibold text-slate-900">
                {user.className || '-'}
              </span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Username Akun</span>
              <span className="font-mono-tabular font-semibold text-slate-900">
                {user.username}
              </span>
            </div>
          </div>

          <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-600 flex items-center gap-2">
            <IdCard className="w-4 h-4 text-blue-700 shrink-0" />
            <span>
              Kartu ini berlaku sah sebagai identitas peserta Asesmen Berbasis Komputer SMP Negeri 61 Palembang Tahun Ajaran {school?.academicYear || '2025/2026'}.
            </span>
          </div>
        </div>
      )}

      {/* Pre-Exam Instructions Confirmation Modal */}
      {previewExam && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-lg p-6 space-y-4">
            <div className="flex items-center gap-2 text-blue-700 font-semibold text-xs">
              <FileCheck className="w-4 h-4" />
              <span>PETUNJUK PENGERJAAN UJIAN</span>
            </div>
            <h2 className="font-display text-xl font-bold text-slate-900">
              {previewExam.title}
            </h2>
            <div className="text-xs text-slate-600 space-y-1 bg-slate-50 border border-slate-200 rounded-lg p-3.5">
              <div>Mata Pelajaran: {previewExam.subjectName}</div>
              <div>Durasi: {previewExam.durationMinutes} Menit · Jumlah Soal: {previewExam.questionCount}</div>
              <div>
                Pengawasan:{' '}
                {previewExam.antiCheatEnabled
                  ? `Aktif (Mode Layar Penuh, batas maksimal ${previewExam.maxViolations}x keluar halaman)`
                  : 'Standar'}
              </div>
            </div>
            <p className="text-sm text-slate-700 leading-relaxed">
              {previewExam.instructions ||
                'Kerjakan seluruh soal dengan jujur. Jawaban tersimpan otomatis secara berkala.'}
            </p>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setPreviewExam(null)}
                className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  const id = previewExam.id;
                  setPreviewExam(null);
                  onStartExam(id);
                }}
                className="rounded-lg bg-blue-700 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-800 cursor-pointer"
              >
                Mulai Kerjakan Sekarang
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
