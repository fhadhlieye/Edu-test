import React from 'react';
import katex from 'katex';

export function SchoolCrest({ className = 'w-10 h-10' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M32 4L56 12V31C56 46.2 45.4 56.6 32 60C18.6 56.6 8 46.2 8 31V12L32 4Z"
        fill="#1D4ED8"
        stroke="#F59E0B"
        strokeWidth="3"
      />
      <path
        d="M32 10L50 16V30.5C50 42.3 42.1 50.6 32 53.6C21.9 50.6 14 42.3 14 30.5V16L32 10Z"
        fill="#FFFFFF"
      />
      <path
        d="M32 15C34.2 18.2 35.4 20.4 34.4 23C33.8 24.4 32.8 25.1 32 25.5C31.2 25.1 30.2 24.4 29.6 23C28.6 20.4 29.8 18.2 32 15Z"
        fill="#F59E0B"
      />
      <path
        d="M20 29C24 29 28.5 30.5 32 33C35.5 30.5 40 29 44 29V43C40 43 35.5 44.3 32 46.5C28.5 44.3 24 43 20 43V29Z"
        fill="#1D4ED8"
      />
      <path d="M32 33V46.5" stroke="#F59E0B" strokeWidth="2" />
      <text
        x="32"
        y="27"
        textAnchor="middle"
        fontSize="6.5"
        fontWeight="700"
        fill="#1E3A8A"
      >
        61
      </text>
    </svg>
  );
}

/**
 * Renders plain text with inline $...$ LaTeX math blocks using KaTeX safely.
 */
export function MathText({
  text,
  className = '',
}: {
  text: string;
  className?: string;
}) {
  if (!text) return null;
  const parts = text.split(/(\$[^$]+\$)/g);
  return (
    <span className={className}>
      {parts.map((part, idx) => {
        if (part.startsWith('$') && part.endsWith('$') && part.length > 2) {
          const tex = part.slice(1, -1);
          try {
            const html = katex.renderToString(tex, {
              throwOnError: false,
              displayMode: false,
            });
            return (
              <span
                key={idx}
                className="inline-block align-middle mx-0.5"
                dangerouslySetInnerHTML={{ __html: html }}
              />
            );
          } catch {
            return <code key={idx}>{tex}</code>;
          }
        }
        return (
          <React.Fragment key={idx}>
            {part.split('\n').map((line, lIdx, arr) => (
              <React.Fragment key={lIdx}>
                {line}
                {lIdx < arr.length - 1 && <br />}
              </React.Fragment>
            ))}
          </React.Fragment>
        );
      })}
    </span>
  );
}
