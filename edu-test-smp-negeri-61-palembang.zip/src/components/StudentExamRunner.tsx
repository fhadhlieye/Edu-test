import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Flag,
  Lock,
  Maximize2,
  Send,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import { MathText } from './SchoolCrest';
import type { StudentAnswerPayload, UserAccount } from '../types/exam';

interface RunnerQuestion {
  id: number;
  number: number;
  questionType: 'PG' | 'PG_KOMPLEKS' | 'MENJODOHKAN' | 'ISIAN_SINGKAT' | 'ESAI';
  stimulusTitle: string;
  stimulusText: string;
  stimulusMedia: Array<{ type: string; htmlOrSvg?: string; caption?: string; url?: string }>;
  stem: string;
  mathLatex: string;
  options: Array<{ key: string; text: string }>;
  matchingLeft: Array<{ id: string; leftText: string }>;
  matchingRightChoices: string[];
  weight: number;
  savedAnswer: StudentAnswerPayload | null;
  isFlaggedReview: boolean;
}

export function StudentExamRunner({
  examId,
  user,
  onFinished,
}: {
  examId: number;
  user: UserAccount;
  onFinished: () => void;
}) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [attemptId, setAttemptId] = useState<number | null>(null);
  const [examInfo, setExamInfo] = useState<any>(null);
  const [questions, setQuestions] = useState<RunnerQuestion[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);

  const [answers, setAnswers] = useState<Record<number, StudentAnswerPayload>>({});
  const [flagged, setFlagged] = useState<Record<number, boolean>>({});
  const [remainingSec, setRemainingSec] = useState(0);

  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [saveState, setSaveState] = useState<'IDLE' | 'SAVING' | 'SAVED' | 'OFFLINE_QUEUED'>('IDLE');

  // Anti-Cheat state
  const [violationCount, setViolationCount] = useState(0);
  const [warningMessage, setWarningMessage] = useState('');
  const [isLocked, setIsLocked] = useState(false);

  // Confirm submit & result modal
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [submitResult, setSubmitResult] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);

  const answersRef = useRef(answers);
  answersRef.current = answers;
  const flaggedRef = useRef(flagged);
  flaggedRef.current = flagged;
  const lastViolationTs = useRef(0);

  const storageKey = attemptId ? `edutest_queue_${attemptId}` : '';

  // 1. Start or Resume Exam
  useEffect(() => {
    let mounted = true;
    apiFetch<any>(`/api/exams/${examId}/start`, { method: 'POST' })
      .then((res) => {
        if (!mounted) return;
        setAttemptId(res.attempt.id);
        setExamInfo(res.exam);
        setQuestions(res.questions || []);
        setRemainingSec(res.attempt.remainingSeconds);
        setViolationCount(res.attempt.violationCount || 0);
        setIsLocked(Boolean(res.attempt.isLocked));

        // Restore saved answers + any localStorage offline backup
        const initAns: Record<number, StudentAnswerPayload> = {};
        const initFlag: Record<number, boolean> = {};
        for (const q of res.questions || []) {
          if (q.savedAnswer !== null && q.savedAnswer !== undefined && q.savedAnswer !== '') {
            initAns[q.id] = q.savedAnswer;
          }
          if (q.isFlaggedReview) initFlag[q.id] = true;
        }

        try {
          const cached = localStorage.getItem(`edutest_queue_${res.attempt.id}`);
          if (cached) {
            const parsed = JSON.parse(cached);
            Object.assign(initAns, parsed.answers || {});
            Object.assign(initFlag, parsed.flagged || {});
          }
        } catch {
          // ignore storage errors
        }

        setAnswers(initAns);
        setFlagged(initFlag);

        if (res.exam.requireFullscreen && document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen().catch(() => {});
        }
      })
      .catch((err) => setError(err.message || 'Gagal memulai ujian.'))
      .finally(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [examId]);

  // 2. Countdown timer
  useEffect(() => {
    if (!attemptId || submitResult || isLocked) return;
    const timer = setInterval(() => {
      setRemainingSec((s) => {
        if (s <= 1) {
          clearInterval(timer);
          handleConfirmSubmit(true);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [attemptId, submitResult, isLocked]);

  // 3. Autosave Sync Function (with offline queue persistence)
  const syncAnswersToServer = useCallback(
    async (specificQuestionId?: number) => {
      if (!attemptId || submitResult || isLocked) return;

      const payloadList = specificQuestionId
        ? [
            {
              questionId: specificQuestionId,
              answer: answersRef.current[specificQuestionId] ?? '',
              isFlaggedReview: Boolean(flaggedRef.current[specificQuestionId]),
            },
          ]
        : questions.map((q) => ({
            questionId: q.id,
            answer: answersRef.current[q.id] ?? '',
            isFlaggedReview: Boolean(flaggedRef.current[q.id]),
          }));

      // Always persist locally first so refresh/disconnect never loses work
      if (storageKey) {
        try {
          localStorage.setItem(
            storageKey,
            JSON.stringify({
              answers: answersRef.current,
              flagged: flaggedRef.current,
              updatedAt: Date.now(),
            })
          );
        } catch {
          // ignore
        }
      }

      if (!navigator.onLine) {
        setSaveState('OFFLINE_QUEUED');
        return;
      }

      setSaveState('SAVING');
      try {
        await apiFetch(`/api/exams/attempts/${attemptId}/autosave`, {
          method: 'POST',
          body: JSON.stringify({ answers: payloadList }),
        });
        setSaveState('SAVED');
      } catch (err: any) {
        if (err.status === 423) {
          setIsLocked(true);
        } else {
          setSaveState('OFFLINE_QUEUED');
        }
      }
    },
    [attemptId, questions, storageKey, submitResult, isLocked]
  );

  // Periodic 15s autosave + online recovery sync
  useEffect(() => {
    if (!attemptId || submitResult) return;
    const interval = setInterval(() => syncAnswersToServer(), 15000);
    const onOnline = () => {
      setIsOnline(true);
      syncAnswersToServer();
    };
    const onOffline = () => {
      setIsOnline(false);
      setSaveState('OFFLINE_QUEUED');
    };
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      clearInterval(interval);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [attemptId, submitResult, syncAnswersToServer]);

  // 4. Anti-Cheat Detection (Visibility API, Focus/Blur, Fullscreen Exit)
  const recordViolation = useCallback(
    async (eventType: string, description: string) => {
      if (!attemptId || !examInfo?.antiCheatEnabled || submitResult || isLocked) return;
      // Ignore during offline network hiccup or rapid duplicate events (< 1.5s)
      if (!navigator.onLine) return;
      const now = Date.now();
      if (now - lastViolationTs.current < 1500) return;
      lastViolationTs.current = now;

      setWarningMessage(
        'PERINGATAN! Anda terdeteksi meninggalkan halaman ujian. Aktivitas ini telah dicatat oleh sistem.'
      );

      try {
        const res = await apiFetch<{
          violationCount: number;
          isLocked: boolean;
        }>(`/api/exams/attempts/${attemptId}/violation`, {
          method: 'POST',
          body: JSON.stringify({ eventType, description }),
        });
        setViolationCount(res.violationCount);
        if (res.isLocked) setIsLocked(true);
      } catch {
        // ignore transient errors
      }
    },
    [attemptId, examInfo, submitResult, isLocked]
  );

  useEffect(() => {
    if (!attemptId || !examInfo?.antiCheatEnabled || submitResult) return;

    const handleVisibility = () => {
      if (document.hidden) {
        recordViolation(
          'TAB_SWITCH',
          'Siswa berpindah tab atau meminimalkan jendela browser saat ujian.'
        );
      }
    };
    const handleBlur = () => {
      recordViolation(
        'WINDOW_BLUR',
        'Jendela ujian kehilangan fokus (kemungkinan membuka aplikasi atau jendela lain).'
      );
    };
    const handleFullscreen = () => {
      if (examInfo.requireFullscreen && !document.fullscreenElement) {
        recordViolation(
          'FULLSCREEN_EXIT',
          'Siswa keluar dari mode layar penuh (Fullscreen).'
        );
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('blur', handleBlur);
    document.addEventListener('fullscreenchange', handleFullscreen);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('blur', handleBlur);
      document.removeEventListener('fullscreenchange', handleFullscreen);
    };
  }, [attemptId, examInfo, submitResult, recordViolation]);

  // Poll status if locked so student resumes seamlessly when proctor unlocks
  useEffect(() => {
    if (!isLocked || !attemptId) return;
    const poller = setInterval(async () => {
      try {
        const res = await apiFetch<{ attempt: { is_locked: number } }>(
          `/api/exams/attempts/${attemptId}/status`
        );
        if (res.attempt && !res.attempt.is_locked) {
          setIsLocked(false);
          setWarningMessage('');
        }
      } catch {
        // ignore
      }
    }, 3000);
    return () => clearInterval(poller);
  }, [isLocked, attemptId]);

  const handleAnswerChange = (qId: number, val: StudentAnswerPayload) => {
    setAnswers((prev) => {
      const next = { ...prev, [qId]: val };
      answersRef.current = next;
      return next;
    });
    syncAnswersToServer(qId);
  };

  const toggleFlag = (qId: number) => {
    setFlagged((prev) => {
      const next = { ...prev, [qId]: !prev[qId] };
      flaggedRef.current = next;
      return next;
    });
    syncAnswersToServer(qId);
  };

  const handleConfirmSubmit = async (autoTimeout = false) => {
    if (!attemptId || submitting) return;
    setSubmitting(true);
    try {
      const payloadList = questions.map((q) => ({
        questionId: q.id,
        answer: answersRef.current[q.id] ?? '',
        isFlaggedReview: Boolean(flaggedRef.current[q.id]),
      }));
      const res = await apiFetch<any>(`/api/exams/attempts/${attemptId}/submit`, {
        method: 'POST',
        body: JSON.stringify({ answers: payloadList, autoTimeout }),
      });
      if (storageKey) localStorage.removeItem(storageKey);
      if (document.fullscreenElement && document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setShowSubmitModal(false);
      setSubmitResult(res);
    } catch (err: any) {
      setError(err.message || 'Gagal mengirim jawaban.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-sm text-slate-600">
        Mempersiapkan lembar ujian digital...
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-md space-y-4">
          <div className="text-sm font-semibold text-red-700">{error}</div>
          <button
            type="button"
            onClick={onFinished}
            className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
          >
            Kembali ke Portal Siswa
          </button>
        </div>
      </div>
    );
  }

  if (submitResult) {
    const sum = submitResult.summary;
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="bg-white border border-slate-200 rounded-xl p-8 max-w-lg w-full space-y-5 text-center">
          <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Ujian Berhasil Dikumpulkan
          </h1>
          <p className="text-sm text-slate-600">
            Terima kasih, <span className="font-semibold">{user.fullName}</span>. Seluruh jawaban Anda untuk{' '}
            <span className="font-semibold">{examInfo?.title}</span> telah tersimpan di server sekolah.
          </p>

          {sum?.hiddenUntilPublished ? (
            <div className="rounded-lg bg-blue-50 border border-blue-200 p-4 text-xs text-blue-900">
              Nilai ujian sedang ditahan hingga diumumkan oleh guru mata pelajaran.
            </div>
          ) : (
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-5 space-y-2">
              <div className="text-xs text-slate-500">
                {sum?.hasPendingEssay
                  ? 'Skor Objektif Sementara (Esai menunggu koreksi guru)'
                  : 'Nilai Akhir'}
              </div>
              <div className="font-display text-4xl font-bold text-blue-700 tabular-nums">
                {sum?.normalizedScore ?? '-'}
              </div>
              {!sum?.hasPendingEssay && (
                <div
                  className={`text-xs font-semibold ${
                    sum?.passed ? 'text-emerald-700' : 'text-amber-700'
                  }`}
                >
                  {sum?.passed ? 'Tuntas Mencapai KKM' : 'Perlu Mengikuti Remedial'}
                </div>
              )}
            </div>
          )}

          <button
            type="button"
            onClick={onFinished}
            className="w-full rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 cursor-pointer"
          >
            Kembali ke Beranda Siswa
          </button>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIdx];
  const answeredCount = questions.filter((q) => {
    const a = answers[q.id];
    if (Array.isArray(a)) return a.length > 0;
    if (a && typeof a === 'object') return Object.keys(a).length > 0;
    return typeof a === 'string' && a.trim().length > 0;
  }).length;
  const unansweredCount = questions.length - answeredCount;

  const mins = Math.floor(remainingSec / 60);
  const secs = remainingSec % 60;
  const timerStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col select-none">
      {/* Exam Top Bar */}
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="text-xs font-semibold text-blue-700 truncate">
              {examInfo?.subjectName} · {examInfo?.title}
            </div>
            <div className="text-xs text-slate-600 truncate">
              {user.fullName} · NISN <span className="font-mono-tabular">{user.nipNisn}</span> · Kelas{' '}
              {user.className || '-'}
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Network & Autosave indicator */}
            <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-600">
              {isOnline ? (
                <Wifi className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <WifiOff className="w-3.5 h-3.5 text-amber-600" />
              )}
              <span>
                {saveState === 'SAVING'
                  ? 'Menyimpan...'
                  : saveState === 'OFFLINE_QUEUED'
                    ? 'Tersimpan lokal (menunggu koneksi)'
                    : 'Tersimpan otomatis'}
              </span>
            </div>

            {/* Timer */}
            <div
              className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 font-mono-tabular text-sm font-bold ${
                remainingSec < 300
                  ? 'border-red-300 bg-red-50 text-red-700'
                  : 'border-slate-300 bg-slate-50 text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>{timerStr}</span>
            </div>

            {examInfo?.requireFullscreen && !document.fullscreenElement && (
              <button
                type="button"
                onClick={() => document.documentElement.requestFullscreen?.().catch(() => {})}
                className="hidden sm:inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                title="Masuk Layar Penuh"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                Layar Penuh
              </button>
            )}

            <button
              type="button"
              onClick={() => setShowSubmitModal(true)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              Selesai Ujian
            </button>
          </div>
        </div>
      </header>

      {/* Anti-Cheat Warning Banner */}
      {warningMessage && (
        <div
          role="alert"
          className="bg-red-600 text-white px-4 py-3 text-xs sm:text-sm font-semibold flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-2 max-w-6xl mx-auto w-full">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <span>
              {warningMessage} (Pelanggaran tercatat: {violationCount}/{examInfo?.maxViolations})
            </span>
            <button
              type="button"
              onClick={() => setWarningMessage('')}
              className="ml-auto underline text-xs shrink-0 cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {/* Main Split Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Question Area */}
        {currentQ && (
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                <span className="text-sm font-bold text-slate-900 tabular-nums">
                  Soal Nomor {currentQ.number} dari {questions.length}
                </span>
                <span aria-hidden="true">·</span>
                <span className="text-blue-700">{currentQ.questionType.replace('_', ' ')}</span>
              </div>

              <button
                type="button"
                onClick={() => toggleFlag(currentQ.id)}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold cursor-pointer ${
                  flagged[currentQ.id]
                    ? 'border-amber-400 bg-amber-50 text-amber-800'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Flag className="w-3.5 h-3.5" />
                {flagged[currentQ.id] ? 'Ditandai Ragu-Ragu' : 'Tandai Periksa Ulang'}
              </button>
            </div>

            {/* Stimulus / Reading Passage / Diagram */}
            {(currentQ.stimulusText || currentQ.stimulusMedia?.length > 0) && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 space-y-3">
                {currentQ.stimulusTitle && (
                  <div className="font-display text-sm font-bold text-slate-900">
                    {currentQ.stimulusTitle}
                  </div>
                )}
                {currentQ.stimulusText && (
                  <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                    {currentQ.stimulusText}
                  </p>
                )}
                {currentQ.stimulusMedia?.map((m, mIdx) => (
                  <div key={mIdx} className="pt-1">
                    {m.htmlOrSvg && (
                      <div dangerouslySetInnerHTML={{ __html: m.htmlOrSvg }} />
                    )}
                    {m.url && m.type === 'image' && (
                      <img
                        src={m.url}
                        alt={m.caption || 'Gambar soal'}
                        referrerPolicy="no-referrer"
                        className="max-h-64 rounded border border-slate-200"
                      />
                    )}
                    {m.caption && (
                      <div className="text-[11px] text-slate-500 mt-1">{m.caption}</div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Question Stem */}
            <div className="text-base font-medium text-slate-900 leading-relaxed">
              <MathText text={currentQ.stem} />
            </div>

            {/* Answer Input by AKM Question Type */}
            {currentQ.questionType === 'PG' && (
              <div className="space-y-2.5">
                {currentQ.options.map((opt) => {
                  const selected = answers[currentQ.id] === opt.key;
                  return (
                    <label
                      key={opt.key}
                      className={`flex items-start gap-3 rounded-lg border p-3.5 cursor-pointer transition-colors ${
                        selected
                          ? 'border-blue-600 bg-blue-50/70'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name={`q-${currentQ.id}`}
                        checked={selected}
                        onChange={() => handleAnswerChange(currentQ.id, opt.key)}
                        className="mt-1"
                      />
                      <span className="font-bold text-sm text-slate-800 w-5 shrink-0">
                        {opt.key}.
                      </span>
                      <span className="text-sm text-slate-800">
                        <MathText text={opt.text} />
                      </span>
                    </label>
                  );
                })}
              </div>
            )}

            {currentQ.questionType === 'PG_KOMPLEKS' && (
              <div className="space-y-2.5">
                <p className="text-xs text-slate-500">
                  Pilih lebih dari satu jawaban yang benar:
                </p>
                {currentQ.options.map((opt) => {
                  const currentList = Array.isArray(answers[currentQ.id])
                    ? (answers[currentQ.id] as string[])
                    : [];
                  const checked = currentList.includes(opt.key);
                  return (
                    <label
                      key={opt.key}
                      className={`flex items-start gap-3 rounded-lg border p-3.5 cursor-pointer transition-colors ${
                        checked
                          ? 'border-blue-600 bg-blue-50/70'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => {
                          const next = checked
                            ? currentList.filter((k) => k !== opt.key)
                            : [...currentList, opt.key];
                          handleAnswerChange(currentQ.id, next);
                        }}
                        className="mt-1"
                      />
                      <span className="font-bold text-sm text-slate-800 w-5 shrink-0">
                        {opt.key}.
                      </span>
                      <span className="text-sm text-slate-800">
                        <MathText text={opt.text} />
                      </span>
                    </label>
                  );
                })}
              </div>
            )}

            {currentQ.questionType === 'MENJODOHKAN' && (
              <div className="space-y-3">
                <p className="text-xs text-slate-500">
                  Pasangkan setiap pernyataan di kiri dengan pilihan tepat di sebelah kanan:
                </p>
                {currentQ.matchingLeft.map((left) => {
                  const mapVal =
                    answers[currentQ.id] &&
                    typeof answers[currentQ.id] === 'object' &&
                    !Array.isArray(answers[currentQ.id])
                      ? (answers[currentQ.id] as Record<string, string>)
                      : {};
                  return (
                    <div
                      key={left.id}
                      className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center rounded-lg border border-slate-200 p-3 bg-slate-50"
                    >
                      <div className="text-sm font-medium text-slate-900">
                        {left.leftText}
                      </div>
                      <select
                        aria-label={`Pasangan untuk ${left.leftText}`}
                        value={mapVal[left.id] || ''}
                        onChange={(e) => {
                          handleAnswerChange(currentQ.id, {
                            ...mapVal,
                            [left.id]: e.target.value,
                          });
                        }}
                        className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                      >
                        <option value="">-- Pilih pasangan --</option>
                        {currentQ.matchingRightChoices.map((choice) => (
                          <option key={choice} value={choice}>
                            {choice}
                          </option>
                        ))}
                      </select>
                    </div>
                  );
                })}
              </div>
            )}

            {currentQ.questionType === 'ISIAN_SINGKAT' && (
              <div>
                <label
                  htmlFor={`short-${currentQ.id}`}
                  className="block text-xs font-semibold text-slate-600 mb-1.5"
                >
                  Jawaban Singkat Anda
                </label>
                <input
                  id={`short-${currentQ.id}`}
                  type="text"
                  value={typeof answers[currentQ.id] === 'string' ? (answers[currentQ.id] as string) : ''}
                  onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                  placeholder="Ketik kata atau angka jawaban..."
                  className="w-full max-w-md rounded-lg border border-slate-300 px-4 py-2.5 text-sm focus:border-blue-600 focus:outline-none"
                />
              </div>
            )}

            {currentQ.questionType === 'ESAI' && (
              <div>
                <label
                  htmlFor={`essay-${currentQ.id}`}
                  className="block text-xs font-semibold text-slate-600 mb-1.5"
                >
                  Jawaban Uraian / Esai
                </label>
                <textarea
                  id={`essay-${currentQ.id}`}
                  rows={6}
                  value={typeof answers[currentQ.id] === 'string' ? (answers[currentQ.id] as string) : ''}
                  onChange={(e) => handleAnswerChange(currentQ.id, e.target.value)}
                  placeholder="Tuliskan penjelasan lengkap Anda di sini..."
                  className="w-full rounded-lg border border-slate-300 p-3.5 text-sm leading-relaxed focus:border-blue-600 focus:outline-none"
                />
              </div>
            )}

            {/* Navigation Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <button
                type="button"
                disabled={currentIdx === 0 || !examInfo?.allowBackNavigation}
                onClick={() => {
                  syncAnswersToServer(currentQ.id);
                  setCurrentIdx((i) => Math.max(0, i - 1));
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                Soal Sebelumnya
              </button>

              {currentIdx < questions.length - 1 ? (
                <button
                  type="button"
                  onClick={() => {
                    syncAnswersToServer(currentQ.id);
                    setCurrentIdx((i) => Math.min(questions.length - 1, i + 1));
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 cursor-pointer"
                >
                  Soal Berikutnya
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  Kumpulkan Ujian
                </button>
              )}
            </div>
          </div>
        )}

        {/* Question Navigator Sidebar */}
        <aside className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="font-display text-sm font-bold text-slate-900">
            Navigasi Nomor Soal
          </div>
          <div className="grid grid-cols-5 gap-2">
            {questions.map((q, idx) => {
              const a = answers[q.id];
              const hasAns = Array.isArray(a)
                ? a.length > 0
                : a && typeof a === 'object'
                  ? Object.keys(a).length > 0
                  : typeof a === 'string' && a.trim().length > 0;
              const isFlag = flagged[q.id];
              const isActive = idx === currentIdx;

              return (
                <button
                  key={q.id}
                  type="button"
                  disabled={!examInfo?.allowBackNavigation && idx < currentIdx}
                  onClick={() => {
                    if (currentQ) syncAnswersToServer(currentQ.id);
                    setCurrentIdx(idx);
                  }}
                  className={`h-10 rounded-lg text-xs font-bold tabular-nums border transition-colors cursor-pointer ${
                    isActive
                      ? 'border-blue-700 ring-2 ring-blue-600/30 bg-blue-700 text-white'
                      : isFlag
                        ? 'border-amber-400 bg-amber-100 text-amber-900'
                        : hasAns
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {q.number}
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
            <div className="flex justify-between">
              <span>Sudah Dijawab</span>
              <span className="font-semibold text-emerald-700 tabular-nums">
                {answeredCount} soal
              </span>
            </div>
            <div className="flex justify-between">
              <span>Belum Dijawab</span>
              <span className="font-semibold text-slate-900 tabular-nums">
                {unansweredCount} soal
              </span>
            </div>
            {examInfo?.antiCheatEnabled && (
              <div className="flex justify-between pt-1 border-t border-slate-100">
                <span>Catatan Pengawasan</span>
                <span
                  className={`font-semibold tabular-nums ${
                    violationCount > 0 ? 'text-red-600' : 'text-slate-600'
                  }`}
                >
                  {violationCount}/{examInfo.maxViolations}
                </span>
              </div>
            )}
          </div>
        </aside>
      </main>

      {/* Lock Screen Overlay if Max Violations Exceeded */}
      {isLocked && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/90 flex items-center justify-center p-6"
        >
          <div className="bg-white rounded-xl p-8 max-w-md w-full text-center space-y-4">
            <Lock className="w-12 h-12 text-red-600 mx-auto" />
            <h2 className="font-display text-xl font-bold text-slate-900">
              Ujian Dikunci Sementara
            </h2>
            <p className="text-sm text-slate-600">
              Sistem mendeteksi Anda meninggalkan halaman ujian melebihi batas ({violationCount}x).
              Silakan melapor ke pengawas atau guru untuk pemeriksaan dan pembukaan kunci.
            </p>
            <div className="text-xs text-slate-500">
              Jawaban Anda sebelumnya tetap tersimpan aman. Halaman akan terbuka otomatis setelah pengawas menyetujui.
            </div>
          </div>
        </div>
      )}

      {/* Confirm Submit Modal */}
      {showSubmitModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-md w-full space-y-4">
            <h2 className="font-display text-lg font-bold text-slate-900">
              Konfirmasi Pengumpulan Ujian
            </h2>
            <p className="text-sm text-slate-600">
              Anda telah menjawab{' '}
              <span className="font-semibold text-slate-900 tabular-nums">
                {answeredCount} dari {questions.length}
              </span>{' '}
              soal.
              {unansweredCount > 0 && (
                <span className="block mt-1 text-amber-700 font-medium">
                  Perhatian: Masih ada {unansweredCount} soal yang belum dijawab.
                </span>
              )}
            </p>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowSubmitModal(false)}
                className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 cursor-pointer"
              >
                Periksa Kembali
              </button>
              <button
                type="button"
                disabled={submitting}
                onClick={() => handleConfirmSubmit(false)}
                className="rounded-lg bg-emerald-700 px-5 py-2 text-sm font-semibold text-white hover:bg-emerald-800 disabled:opacity-60 cursor-pointer"
              >
                {submitting ? 'Mengirim...' : 'Ya, Kumpulkan Jawaban'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
