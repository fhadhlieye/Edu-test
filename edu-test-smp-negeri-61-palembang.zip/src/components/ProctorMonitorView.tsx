import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Lock,
  RefreshCw,
  ShieldAlert,
  Unlock,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import type { ExamConfig } from '../types/exam';

export function ProctorMonitorView({
  initialExamId,
}: {
  initialExamId: number | null;
}) {
  const [exams, setExams] = useState<ExamConfig[]>([]);
  const [selectedExamId, setSelectedExamId] = useState<number | null>(initialExamId);
  const [monitorData, setMonitorData] = useState<{
    exam: any;
    attempts: any[];
    violations: any[];
    notStarted: any[];
  } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    apiFetch<{ exams: ExamConfig[] }>('/api/exams').then((res) => {
      const list = res.exams || [];
      setExams(list);
      if (!selectedExamId && list.length > 0) {
        const active = list.find((e) => e.status === 'ACTIVE') || list[0];
        setSelectedExamId(active.id);
      }
    });
  }, []);

  const fetchMonitor = async (id: number) => {
    setLoading(true);
    try {
      const res = await apiFetch<any>(`/api/exams/${id}/monitor`);
      setMonitorData(res);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedExamId) fetchMonitor(selectedExamId);
  }, [selectedExamId]);

  const handleUnlock = async (attemptId: number) => {
    await apiFetch(`/api/exams/attempts/${attemptId}/unlock`, {
      method: 'POST',
    });
    if (selectedExamId) fetchMonitor(selectedExamId);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Dashboard Pengawasan &amp; Anti-Curang
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Pantau status peserta ujian, riwayat pelanggaran tab/fokus, dan buka kunci peserta jika diperlukan.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <select
            aria-label="Pilih Ujian untuk Dipantau"
            value={selectedExamId || ''}
            onChange={(e) => setSelectedExamId(Number(e.target.value))}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
          >
            {exams.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.title} ({ex.status})
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => selectedExamId && fetchMonitor(selectedExamId)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Segarkan
          </button>
        </div>
      </div>

      {monitorData && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Participant Status Table */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-display text-base font-bold text-slate-900 mb-3">
                Peserta Ujian ({monitorData.attempts.length} memulai · {monitorData.notStarted.length} belum mulai)
              </h2>
              {monitorData.attempts.length === 0 ? (
                <p className="text-sm text-slate-500 py-8 text-center">
                  Belum ada siswa yang memulai ujian ini.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b border-slate-200 text-slate-500">
                      <tr>
                        <th className="py-2 pr-3 font-semibold">Siswa</th>
                        <th className="py-2 pr-3 font-semibold">Kelas</th>
                        <th className="py-2 pr-3 font-semibold">Status</th>
                        <th className="py-2 pr-3 font-semibold text-right">Terjawab</th>
                        <th className="py-2 pr-3 font-semibold text-right">Pelanggaran</th>
                        <th className="py-2 font-semibold text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {monitorData.attempts.map((a) => (
                        <tr key={a.id} className="hover:bg-slate-50">
                          <td className="py-2.5 pr-3">
                            <div className="font-semibold text-slate-900">
                              {a.student_name}
                            </div>
                            <div className="text-[11px] font-mono-tabular text-slate-500">
                              NISN {a.nip_nisn}
                            </div>
                          </td>
                          <td className="py-2.5 pr-3 text-slate-600">{a.class_name}</td>
                          <td className="py-2.5 pr-3">
                            {a.is_locked ? (
                              <span className="inline-flex items-center gap-1 font-semibold text-red-700">
                                <Lock className="w-3.5 h-3.5" />
                                Terkunci
                              </span>
                            ) : a.is_flagged ? (
                              <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                Perlu Perhatian
                              </span>
                            ) : (
                              <span className="font-medium text-slate-700">{a.status}</span>
                            )}
                          </td>
                          <td className="py-2.5 pr-3 text-right tabular-nums">
                            {a.answered_count}
                          </td>
                          <td className="py-2.5 pr-3 text-right tabular-nums font-semibold">
                            <span
                              className={
                                a.violation_count > 0 ? 'text-red-600' : 'text-slate-600'
                              }
                            >
                              {a.violation_count}x
                            </span>
                          </td>
                          <td className="py-2.5 text-right">
                            {a.is_locked ? (
                              <button
                                type="button"
                                onClick={() => handleUnlock(a.id)}
                                className="inline-flex items-center gap-1 rounded bg-blue-700 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-blue-800 cursor-pointer"
                              >
                                <Unlock className="w-3 h-3" />
                                Buka Kunci
                              </button>
                            ) : (
                              <span className="text-slate-400">—</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Violation Logs */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-5">
              <div className="flex items-center gap-2 mb-3">
                <ShieldAlert className="w-4 h-4 text-red-600" />
                <h2 className="font-display text-base font-bold text-slate-900">
                  Log Aktivitas Mencurigakan ({monitorData.violations.length})
                </h2>
              </div>
              {monitorData.violations.length === 0 ? (
                <p className="text-sm text-slate-500 py-8 text-center">
                  Belum ada pelanggaran tercatat pada ujian ini.
                </p>
              ) : (
                <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 text-xs">
                  {monitorData.violations.map((v) => (
                    <div key={v.id} className="py-2.5 space-y-0.5">
                      <div className="flex items-center justify-between font-semibold text-slate-900">
                        <span>
                          {v.student_name} ({v.class_name})
                        </span>
                        <span className="text-red-600">{v.event_type}</span>
                      </div>
                      <p className="text-slate-600">{v.description}</p>
                      <div className="text-[11px] font-mono-tabular text-slate-400">
                        {v.occurred_at}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Students Not Started */}
          {monitorData.notStarted.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-display text-sm font-bold text-slate-900 mb-2">
                Siswa Belum Memulai Ujian ({monitorData.notStarted.length})
              </h2>
              <div className="flex flex-wrap gap-2 text-xs">
                {monitorData.notStarted.map((s) => (
                  <span
                    key={s.id}
                    className="border border-slate-200 bg-slate-50 rounded px-2.5 py-1 text-slate-700"
                  >
                    {s.full_name} ({s.class_name})
                  </span>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
