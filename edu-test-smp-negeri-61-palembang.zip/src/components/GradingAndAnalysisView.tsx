import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Download,
  Eye,
  EyeOff,
  FileSpreadsheet,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import { downloadExamReportPdf } from '../utils/pdfReport';
import { BarDistributionChart, PassRateDonut } from './Charts';
import { MathText } from './SchoolCrest';
import type { ExamConfig, SchoolProfile } from '../types/exam';
import type {
  ClassSummaryStats,
  QuestionItemAnalysis,
} from '../utils/itemAnalysis';

export function GradingAndAnalysisView({
  school,
  initialExamId,
}: {
  school: SchoolProfile | null;
  initialExamId: number | null;
}) {
  const [exams, setExams] = useState<ExamConfig[]>([]);
  const [selectedExamId, setSelectedExamId] = useState<number | null>(initialExamId);
  const [tab, setTab] = useState<'grading' | 'analysis'>('grading');

  const [subData, setSubData] = useState<{
    exam: any;
    questions: any[];
    submissions: any[];
  } | null>(null);

  const [analysisData, setAnalysisData] = useState<{
    exam: any;
    summary: ClassSummaryStats;
    itemAnalysis: QuestionItemAnalysis[];
    participants: any[];
  } | null>(null);

  const [selectedAttempt, setSelectedAttempt] = useState<any | null>(null);
  const [aiLoadingId, setAiLoadingId] = useState<number | null>(null);
  const [scoreDrafts, setScoreDrafts] = useState<Record<number, string>>({});

  useEffect(() => {
    apiFetch<{ exams: ExamConfig[] }>('/api/exams').then((res) => {
      const list = res.exams || [];
      setExams(list);
      if (!selectedExamId && list.length > 0) {
        const closed = list.find((e) => e.status === 'CLOSED') || list[0];
        setSelectedExamId(closed.id);
      }
    });
  }, []);

  const loadExamData = async (examId: number) => {
    const [sRes, aRes] = await Promise.all([
      apiFetch<any>(`/api/analytics/exams/${examId}/submissions`),
      apiFetch<any>(`/api/analytics/exams/${examId}/analysis`),
    ]);
    setSubData(sRes);
    setAnalysisData(aRes);
    if (sRes.submissions?.length) {
      const updated = sRes.submissions.find(
        (x: any) => x.id === selectedAttempt?.id
      );
      setSelectedAttempt(updated || sRes.submissions[0]);
    } else {
      setSelectedAttempt(null);
    }
  };

  useEffect(() => {
    if (selectedExamId) loadExamData(selectedExamId);
  }, [selectedExamId]);

  const handleAiRecommend = async (answerId: number) => {
    setAiLoadingId(answerId);
    try {
      const res = await apiFetch<{
        recommendedScore: number;
        feedback: string;
      }>(`/api/analytics/answers/${answerId}/ai-recommend`, {
        method: 'POST',
      });
      setScoreDrafts((prev) => ({
        ...prev,
        [answerId]: String(res.recommendedScore),
      }));
      if (selectedExamId) await loadExamData(selectedExamId);
    } finally {
      setAiLoadingId(null);
    }
  };

  const handleApproveEssayScore = async (answerId: number, fallbackVal: number) => {
    const val = Number(scoreDrafts[answerId] ?? fallbackVal);
    await apiFetch(`/api/analytics/answers/${answerId}/grade`, {
      method: 'POST',
      body: JSON.stringify({ manualScore: val }),
    });
    if (selectedExamId) await loadExamData(selectedExamId);
  };

  const handleTogglePublishScores = async () => {
    if (!subData?.exam) return;
    await apiFetch(`/api/analytics/exams/${subData.exam.id}/publish-scores`, {
      method: 'PATCH',
      body: JSON.stringify({
        showScoreImmediately: !subData.exam.show_score_immediately,
      }),
    });
    if (selectedExamId) await loadExamData(selectedExamId);
  };

  const handleGrantRemedial = async () => {
    if (!subData?.exam) return;
    await apiFetch(`/api/analytics/exams/${subData.exam.id}/remedial-grant`, {
      method: 'POST',
    });
    if (selectedExamId) await loadExamData(selectedExamId);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Koreksi Hasil &amp; Analisis Butir Soal
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Tinjau koreksi otomatis, beri persetujuan penilaian esai dengan bantuan AI, dan unduh laporan PDF/Excel/CSV.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <select
            aria-label="Pilih Ujian"
            value={selectedExamId || ''}
            onChange={(e) => setSelectedExamId(Number(e.target.value))}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
          >
            {exams.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.title}
              </option>
            ))}
          </select>

          <div className="inline-flex rounded-lg bg-slate-200/70 p-1">
            <button
              type="button"
              onClick={() => setTab('grading')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                tab === 'grading'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600'
              }`}
            >
              Koreksi &amp; Nilai
            </button>
            <button
              type="button"
              onClick={() => setTab('analysis')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                tab === 'analysis'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600'
              }`}
            >
              Analisis Butir &amp; Laporan
            </button>
          </div>
        </div>
      </div>

      {tab === 'grading' && subData && (
        <div className="space-y-5">
          {/* Action Toolbar */}
          <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs text-slate-600">
              Status Tampilan Nilai ke Siswa:{' '}
              <span className="font-semibold text-slate-900">
                {subData.exam.show_score_immediately
                  ? 'Ditampilkan ke Siswa'
                  : 'Ditahan (Menunggu Pengumuman Guru)'}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleTogglePublishScores}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                {subData.exam.show_score_immediately ? (
                  <>
                    <EyeOff className="w-3.5 h-3.5" /> Tahan Nilai
                  </>
                ) : (
                  <>
                    <Eye className="w-3.5 h-3.5" /> Umumkan Nilai
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleGrantRemedial}
                className="inline-flex items-center gap-1.5 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Aktifkan Ujian Remedial
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Student List */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 font-display text-sm font-bold text-slate-900">
                Daftar Nilai Peserta ({subData.submissions.length})
              </div>
              {subData.submissions.length === 0 ? (
                <p className="p-6 text-sm text-slate-500 text-center">
                  Belum ada peserta yang mengumpulkan ujian ini.
                </p>
              ) : (
                <div className="divide-y divide-slate-100 max-h-[520px] overflow-y-auto">
                  {subData.submissions.map((sub) => {
                    const isSelected = selectedAttempt?.id === sub.id;
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => setSelectedAttempt(sub)}
                        className={`w-full text-left px-4 py-3 flex items-center justify-between gap-3 hover:bg-slate-50 cursor-pointer ${
                          isSelected ? 'bg-blue-50/80' : ''
                        }`}
                      >
                        <div>
                          <div className="text-sm font-semibold text-slate-900">
                            {sub.student_name}
                          </div>
                          <div className="text-xs text-slate-500">
                            {sub.class_name} · {sub.status} · {sub.violation_count} pelanggaran
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono-tabular text-base font-bold text-slate-900">
                            {sub.final_score}
                          </div>
                          <div
                            className={`text-[11px] font-semibold ${
                              sub.passed ? 'text-emerald-700' : 'text-amber-700'
                            }`}
                          >
                            {sub.passed ? 'Tuntas' : 'Remedial'}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Selected Student Answer Inspector & Essay Grader */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-5 space-y-4">
              {!selectedAttempt ? (
                <p className="text-sm text-slate-500 py-10 text-center">
                  Pilih salah satu peserta di sebelah kiri untuk memeriksa jawaban.
                </p>
              ) : (
                <>
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <div>
                      <h2 className="font-display text-base font-bold text-slate-900">
                        Lembar Jawaban: {selectedAttempt.student_name}
                      </h2>
                      <p className="text-xs text-slate-500 tabular-nums">
                        Objektif: {selectedAttempt.objective_score} · Esai:{' '}
                        {selectedAttempt.essay_score} · Nilai Akhir:{' '}
                        {selectedAttempt.final_score}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4 max-h-[480px] overflow-y-auto pr-1">
                    {subData.questions.map((q) => {
                      const ansRow = selectedAttempt.answers.find(
                        (a: any) => a.question_id === q.id
                      );
                      const isEssay = q.questionType === 'ESAI';
                      const draftVal =
                        scoreDrafts[ansRow?.id] ??
                        String(
                          ansRow?.manual_score ??
                            ansRow?.ai_recommended_score ??
                            ''
                        );

                      return (
                        <div
                          key={q.id}
                          className="rounded-lg border border-slate-200 p-4 space-y-2.5"
                        >
                          <div className="flex items-center justify-between text-xs text-slate-500">
                            <span className="font-semibold text-slate-800">
                              Soal #{q.orderIndex} ({q.questionType}) · Maks {q.weight} poin
                            </span>
                            <span className="font-mono-tabular font-semibold text-slate-900">
                              Skor:{' '}
                              {isEssay
                                ? ansRow?.is_graded
                                  ? ansRow.manual_score
                                  : 'Belum dikoreksi'
                                : ansRow?.auto_score ?? 0}
                            </span>
                          </div>
                          <p className="text-sm text-slate-900 font-medium">{q.stem}</p>
                          <div className="rounded bg-slate-50 border border-slate-200 p-2.5 text-xs text-slate-800">
                            <span className="font-semibold text-slate-500">
                              Jawaban Siswa:{' '}
                            </span>
                            {ansRow
                              ? typeof ansRow.answer === 'object'
                                ? JSON.stringify(ansRow.answer)
                                : String(ansRow.answer || '(Kosong)')
                              : '(Tidak dijawab)'}
                          </div>

                          {isEssay && ansRow && (
                            <div className="pt-2 border-t border-slate-100 space-y-2.5">
                              {ansRow.ai_feedback && (
                                <div className="rounded-md bg-blue-50 border border-blue-200 p-3 text-xs text-blue-900 space-y-1">
                                  <div className="font-semibold">
                                    Rekomendasi Asisten AI (Skor: {ansRow.ai_recommended_score}/{q.weight})
                                  </div>
                                  <p>{ansRow.ai_feedback}</p>
                                </div>
                              )}
                              <div className="flex flex-wrap items-center gap-2">
                                <button
                                  type="button"
                                  disabled={aiLoadingId === ansRow.id}
                                  onClick={() => handleAiRecommend(ansRow.id)}
                                  className="inline-flex items-center gap-1.5 rounded-lg border border-blue-300 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-800 hover:bg-blue-100 cursor-pointer"
                                >
                                  <Sparkles className="w-3.5 h-3.5" />
                                  {aiLoadingId === ansRow.id
                                    ? 'Menganalisis...'
                                    : 'Minta Rekomendasi AI'}
                                </button>
                                <input
                                  type="number"
                                  step="0.5"
                                  min={0}
                                  max={q.weight}
                                  aria-label={`Nilai esai soal ${q.orderIndex}`}
                                  value={draftVal}
                                  onChange={(e) =>
                                    setScoreDrafts((prev) => ({
                                      ...prev,
                                      [ansRow.id]: e.target.value,
                                    }))
                                  }
                                  placeholder={`0–${q.weight}`}
                                  className="w-24 rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs tabular-nums"
                                />
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleApproveEssayScore(
                                      ansRow.id,
                                      Number(draftVal || ansRow.ai_recommended_score || 0)
                                    )
                                  }
                                  className="inline-flex items-center gap-1 rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  Setujui Nilai Final
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === 'analysis' && analysisData && (
        <div className="space-y-6">
          {/* Export Buttons */}
          <div className="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="text-sm font-semibold text-slate-900">
              Ekspor Laporan Akademik: {analysisData.exam.title}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  downloadExamReportPdf({
                    school,
                    examTitle: analysisData.exam.title,
                    subjectName: analysisData.exam.subject_name,
                    scheduledDate: analysisData.exam.scheduled_date,
                    summary: analysisData.summary,
                    participants: analysisData.participants,
                  })
                }
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Unduh PDF
              </button>
              <a
                href={`/api/analytics/exams/${analysisData.exam.id}/export?format=xlsx`}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                Unduh Excel (.xlsx)
              </a>
              <a
                href={`/api/analytics/exams/${analysisData.exam.id}/export?format=csv`}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                <Download className="w-3.5 h-3.5" />
                Unduh CSV
              </a>
            </div>
          </div>

          {/* Summary KPI Row */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="text-xs text-slate-500">Rata-Rata Kelas</div>
              <div className="font-display text-2xl font-bold text-slate-900 tabular-nums mt-1">
                {analysisData.summary.mean}
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="text-xs text-slate-500">Nilai Tertinggi</div>
              <div className="font-display text-2xl font-bold text-emerald-700 tabular-nums mt-1">
                {analysisData.summary.max}
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="text-xs text-slate-500">Nilai Terendah</div>
              <div className="font-display text-2xl font-bold text-red-700 tabular-nums mt-1">
                {analysisData.summary.min}
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="text-xs text-slate-500">Tuntas KKM</div>
              <div className="font-display text-2xl font-bold text-blue-700 tabular-nums mt-1">
                {analysisData.summary.passRate}%
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-lg p-4">
              <div className="text-xs text-slate-500">Butuh Remedial</div>
              <div className="font-display text-2xl font-bold text-amber-700 tabular-nums mt-1">
                {analysisData.summary.remedialCount} siswa
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-display text-base font-bold text-slate-900 mb-3">
                Distribusi Nilai Ujian
              </h2>
              <BarDistributionChart
                data={analysisData.summary.distribution.map((d) => ({
                  label: d.label,
                  value: d.count,
                }))}
              />
            </div>
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-5">
              <h2 className="font-display text-base font-bold text-slate-900 mb-4">
                Persentase Ketuntasan
              </h2>
              <PassRateDonut
                passCount={analysisData.summary.passCount}
                remedialCount={analysisData.summary.remedialCount}
              />
            </div>
          </div>

          {/* Psychometric Item Analysis Table */}
          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <h2 className="font-display text-base font-bold text-slate-900 mb-3">
              Analisis Kualitas Butir Soal (Tingkat Kesukaran, Daya Pembeda &amp; Pengecoh)
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 text-slate-500">
                  <tr>
                    <th className="py-2 pr-3 font-semibold">No</th>
                    <th className="py-2 pr-3 font-semibold">Butir Soal &amp; Tipe</th>
                    <th className="py-2 pr-3 font-semibold text-right">% Benar</th>
                    <th className="py-2 pr-3 font-semibold">Tingkat Kesukaran (P)</th>
                    <th className="py-2 pr-3 font-semibold">Daya Pembeda (D)</th>
                    <th className="py-2 font-semibold">Efektivitas Pengecoh (PG)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {analysisData.itemAnalysis.map((it) => (
                    <tr key={it.questionId} className="align-top hover:bg-slate-50">
                      <td className="py-3 pr-3 font-mono-tabular font-bold">
                        #{it.questionNumber}
                      </td>
                      <td className="py-3 pr-3 max-w-xs">
                        <div className="font-semibold text-slate-800">
                          {it.questionType}
                        </div>
                        <div className="text-slate-600 line-clamp-2">
                          <MathText text={it.stem} />
                        </div>
                      </td>
                      <td className="py-3 pr-3 text-right font-mono-tabular font-semibold">
                        {it.correctPercent}%
                      </td>
                      <td className="py-3 pr-3 font-mono-tabular">
                        <span className="font-semibold">{it.pValue}</span> ·{' '}
                        {it.difficultyLabel}
                      </td>
                      <td className="py-3 pr-3 font-mono-tabular">
                        <span className="font-semibold">{it.discriminationIndex}</span> ·{' '}
                        <span
                          className={
                            it.discriminationLabel === 'PERLU_REVISI'
                              ? 'text-red-600 font-semibold'
                              : 'text-emerald-700 font-semibold'
                          }
                        >
                          {it.discriminationLabel.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3">
                        {it.distractorStats.length === 0 ? (
                          <span className="text-slate-400">Non-PG</span>
                        ) : (
                          <div className="flex flex-wrap gap-2 font-mono-tabular">
                            {it.distractorStats.map((d) => (
                              <span
                                key={d.optionKey}
                                className={
                                  d.isCorrect
                                    ? 'font-bold text-emerald-700'
                                    : d.effective
                                      ? 'text-slate-700'
                                      : 'text-amber-700'
                                }
                              >
                                {d.optionKey}:{d.percent}%
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
