import React, { useEffect, useState } from 'react';
import {
  Database,
  Download,
  KeyRound,
  Megaphone,
  Plus,
  School,
  Trash2,
  Upload,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import type { Role, SchoolProfile, UserAccount } from '../types/exam';

export function AdminConsoleView({
  onSchoolUpdated,
}: {
  onSchoolUpdated: () => void;
}) {
  const [subTab, setSubTab] = useState<
    'users' | 'academic' | 'school' | 'backup' | 'audit'
  >('users');

  const [school, setSchool] = useState<SchoolProfile | null>(null);
  const [classes, setClasses] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [backups, setBackups] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [roleFilter, setRoleFilter] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Quick add user form
  const [newUser, setNewUser] = useState({
    fullName: '',
    username: '',
    nipNisn: '',
    role: 'SISWA' as Role,
    classId: '',
    password: '',
  });

  // New class / subject
  const [newClassName, setNewClassName] = useState('');
  const [newClassGrade, setNewClassGrade] = useState('IX');
  const [newSubjCode, setNewSubjCode] = useState('');
  const [newSubjName, setNewSubjName] = useState('');

  // Announcement form
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');

  const loadAll = async () => {
    const [refRes, userRes, bkpRes, audRes] = await Promise.all([
      apiFetch<{ school: any; classes: any[]; subjects: any[] }>(
        '/api/admin/reference-data'
      ),
      apiFetch<{ users: any[] }>(
        `/api/admin/users${roleFilter ? `?role=${roleFilter}` : ''}`
      ),
      apiFetch<{ backups: any[] }>('/api/admin/backups'),
      apiFetch<{ logs: any[] }>('/api/admin/audit-logs'),
    ]);
    if (refRes.school) {
      setSchool({
        id: refRes.school.id,
        name: refRes.school.name,
        npsn: refRes.school.npsn,
        address: refRes.school.address,
        city: refRes.school.city,
        headmaster: refRes.school.headmaster,
        nipHeadmaster: refRes.school.nip_headmaster,
        academicYear: refRes.school.academic_year,
        activeSemester: refRes.school.active_semester,
        headerText: refRes.school.header_text,
        logoUrl: refRes.school.logo_url,
      });
    }
    setClasses(refRes.classes || []);
    setSubjects(refRes.subjects || []);
    setUsers(userRes.users || []);
    setBackups(bkpRes.backups || []);
    setAuditLogs(audRes.logs || []);
  };

  useEffect(() => {
    loadAll();
  }, [roleFilter]);

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setStatusMsg('');
    try {
      await apiFetch('/api/admin/users', {
        method: 'POST',
        body: JSON.stringify({
          ...newUser,
          classId: newUser.classId ? Number(newUser.classId) : null,
        }),
      });
      setNewUser({
        fullName: '',
        username: '',
        nipNisn: '',
        role: 'SISWA',
        classId: '',
        password: '',
      });
      setStatusMsg('Akun pengguna berhasil ditambahkan.');
      loadAll();
    } catch (err: any) {
      setErrorMsg(err.message);
    }
  };

  const handleExcelImportUsers = async (
    e: React.ChangeEvent<HTMLInputElement>,
    targetRole: 'SISWA' | 'GURU'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg('');
    setStatusMsg('');
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('role', targetRole);
      const res = await apiFetch<{ importedCount: number; skippedCount: number }>(
        '/api/admin/users/import-excel',
        { method: 'POST', body: form }
      );
      setStatusMsg(
        `Impor Excel selesai: ${res.importedCount} akun ${targetRole} ditambahkan (${res.skippedCount} dilewati).`
      );
      loadAll();
    } catch (err: any) {
      setErrorMsg(err.message);
    }
  };

  const handleResetUserPassword = async (userId: number, fullName: string) => {
    await apiFetch(`/api/admin/users/${userId}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ newPassword: 'smpn61reset' }),
    });
    setStatusMsg(`Kata sandi ${fullName} direset ke: smpn61reset`);
  };

  const handleSaveSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!school) return;
    await apiFetch('/api/admin/school', {
      method: 'PUT',
      body: JSON.stringify(school),
    });
    setStatusMsg('Identitas dan kop laporan sekolah berhasil disimpan.');
    onSchoolUpdated();
  };

  const handleCreateBackup = async () => {
    await apiFetch('/api/admin/backups', { method: 'POST' });
    setStatusMsg('Cadangan database berhasil dibuat.');
    loadAll();
  };

  const handleRestoreBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    try {
      const res = await apiFetch<{ message: string }>('/api/admin/backups/restore', {
        method: 'POST',
        body: form,
      });
      setStatusMsg(res.message);
      loadAll();
    } catch (err: any) {
      setErrorMsg(err.message);
    }
  };

  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle || !annContent) return;
    await apiFetch('/api/admin/announcements', {
      method: 'POST',
      body: JSON.stringify({ title: annTitle, content: annContent, targetRole: 'ALL' }),
    });
    setAnnTitle('');
    setAnnContent('');
    setStatusMsg('Pengumuman berhasil dikirim ke seluruh pengguna.');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Administrasi Sekolah
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Kelola akun guru/siswa, rombel, mata pelajaran, identitas sekolah, audit log, dan backup database.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-200/70 p-1 rounded-lg overflow-x-auto max-w-full">
          {(
            [
              ['users', 'Pengguna'],
              ['academic', 'Rombel & Mapel'],
              ['school', 'Sekolah'],
              ['backup', 'Backup DB'],
              ['audit', 'Audit Log'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setSubTab(id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer whitespace-nowrap shrink-0 ${
                subTab === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {statusMsg && (
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {statusMsg}
        </div>
      )}
      {errorMsg && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {errorMsg}
        </div>
      )}

      {subTab === 'users' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <form
              onSubmit={handleAddUser}
              className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-5 space-y-3"
            >
              <h2 className="font-display text-base font-bold text-slate-900">
                Tambah Akun Baru
              </h2>
              <input
                type="text"
                required
                placeholder="Nama Lengkap"
                value={newUser.fullName}
                onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  required
                  placeholder="Username"
                  value={newUser.username}
                  onChange={(e) =>
                    setNewUser({ ...newUser, username: e.target.value })
                  }
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
                <input
                  type="text"
                  placeholder="NIP / NISN"
                  value={newUser.nipNisn}
                  onChange={(e) =>
                    setNewUser({ ...newUser, nipNisn: e.target.value })
                  }
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={newUser.role}
                  onChange={(e) =>
                    setNewUser({ ...newUser, role: e.target.value as Role })
                  }
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="SISWA">Siswa</option>
                  <option value="GURU">Guru</option>
                  <option value="ADMIN_SEKOLAH">Admin Sekolah</option>
                </select>
                <select
                  value={newUser.classId}
                  onChange={(e) =>
                    setNewUser({ ...newUser, classId: e.target.value })
                  }
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="">Tanpa Rombel</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <input
                type="password"
                placeholder="Kata sandi (default: siswa123 / guru123)"
                value={newUser.password}
                onChange={(e) =>
                  setNewUser({ ...newUser, password: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Simpan Akun
              </button>

              <div className="pt-3 border-t border-slate-200 space-y-2">
                <div className="text-xs font-semibold text-slate-700">
                  Impor Massal via Excel (.xlsx / .csv)
                </div>
                <div className="flex flex-wrap gap-2">
                  <label className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    Impor Siswa
                    <input
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      className="hidden"
                      onChange={(e) => handleExcelImportUsers(e, 'SISWA')}
                    />
                  </label>
                  <label className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    Impor Guru
                    <input
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      className="hidden"
                      onChange={(e) => handleExcelImportUsers(e, 'GURU')}
                    />
                  </label>
                </div>
              </div>
            </form>

            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-5">
              <div className="flex items-center justify-between gap-3 mb-3">
                <h2 className="font-display text-base font-bold text-slate-900">
                  Daftar Pengguna ({users.length})
                </h2>
                <select
                  aria-label="Filter Peran Pengguna"
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs bg-white"
                >
                  <option value="">Semua Peran</option>
                  <option value="SISWA">Siswa</option>
                  <option value="GURU">Guru</option>
                  <option value="ADMIN_SEKOLAH">Admin Sekolah</option>
                </select>
              </div>
              <div className="overflow-x-auto max-h-[420px]">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 text-slate-500">
                    <tr>
                      <th className="py-2 pr-3 font-semibold">Nama &amp; Username</th>
                      <th className="py-2 pr-3 font-semibold">Peran</th>
                      <th className="py-2 pr-3 font-semibold">NISN/NIP</th>
                      <th className="py-2 pr-3 font-semibold">Kelas</th>
                      <th className="py-2 font-semibold text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50">
                        <td className="py-2.5 pr-3">
                          <div className="font-semibold text-slate-900">{u.full_name}</div>
                          <div className="font-mono-tabular text-[11px] text-slate-500">
                            {u.username}
                          </div>
                        </td>
                        <td className="py-2.5 pr-3 text-slate-700">{u.role}</td>
                        <td className="py-2.5 pr-3 font-mono-tabular text-slate-600">
                          {u.nip_nisn || '-'}
                        </td>
                        <td className="py-2.5 pr-3 text-slate-600">
                          {u.class_name || '-'}
                        </td>
                        <td className="py-2.5 text-right space-x-2 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleResetUserPassword(u.id, u.full_name)}
                            className="inline-flex items-center gap-1 text-blue-700 hover:underline cursor-pointer"
                            title="Reset Kata Sandi"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                            Reset
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await apiFetch(`/api/admin/users/${u.id}`, {
                                method: 'DELETE',
                              });
                              loadAll();
                            }}
                            className="inline-flex items-center gap-1 text-red-600 hover:underline cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Hapus
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Broadcast Announcement */}
          <form
            onSubmit={handlePostAnnouncement}
            className="bg-white border border-slate-200 rounded-lg p-5 space-y-3"
          >
            <div className="flex items-center gap-2 font-display text-base font-bold text-slate-900">
              <Megaphone className="w-4 h-4 text-amber-600" />
              <span>Kirim Pengumuman Ujian</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <input
                type="text"
                placeholder="Judul pengumuman"
                value={annTitle}
                onChange={(e) => setAnnTitle(e.target.value)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
              <input
                type="text"
                placeholder="Isi pengumuman untuk siswa dan guru..."
                value={annContent}
                onChange={(e) => setAnnContent(e.target.value)}
                className="md:col-span-2 rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <button
              type="submit"
              className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
            >
              Terbitkan Pengumuman &amp; Notifikasi
            </button>
          </form>
        </div>
      )}

      {subTab === 'academic' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
            <h2 className="font-display text-base font-bold text-slate-900">
              Rombongan Belajar ({classes.length})
            </h2>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Nama kelas (mis. VII-C)"
                value={newClassName}
                onChange={(e) => setNewClassName(e.target.value)}
                className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
              />
              <select
                value={newClassGrade}
                onChange={(e) => setNewClassGrade(e.target.value)}
                className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-sm bg-white"
              >
                <option value="VII">VII</option>
                <option value="VIII">VIII</option>
                <option value="IX">IX</option>
              </select>
              <button
                type="button"
                onClick={async () => {
                  if (!newClassName.trim()) return;
                  await apiFetch('/api/admin/classes', {
                    method: 'POST',
                    body: JSON.stringify({
                      name: newClassName,
                      gradeLevel: newClassGrade,
                    }),
                  });
                  setNewClassName('');
                  loadAll();
                }}
                className="rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white cursor-pointer"
              >
                Tambah
              </button>
            </div>
            <div className="divide-y divide-slate-100 text-sm">
              {classes.map((c) => (
                <div key={c.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-900">{c.name}</span>
                    <span className="text-xs text-slate-500 ml-2">
                      Tingkat {c.grade_level} · {c.student_count} siswa
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      await apiFetch(`/api/admin/classes/${c.id}`, { method: 'DELETE' });
                      loadAll();
                    }}
                    className="text-xs text-red-600 hover:underline cursor-pointer"
                  >
                    Hapus
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4">
            <h2 className="font-display text-base font-bold text-slate-900">
              Mata Pelajaran ({subjects.length})
            </h2>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Kode (mis. PKN)"
                value={newSubjCode}
                onChange={(e) => setNewSubjCode(e.target.value)}
                className="w-28 rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
              />
              <input
                type="text"
                placeholder="Nama Mata Pelajaran"
                value={newSubjName}
                onChange={(e) => setNewSubjName(e.target.value)}
                className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm"
              />
              <button
                type="button"
                onClick={async () => {
                  if (!newSubjCode.trim() || !newSubjName.trim()) return;
                  await apiFetch('/api/admin/subjects', {
                    method: 'POST',
                    body: JSON.stringify({ code: newSubjCode, name: newSubjName, kkm: 75 }),
                  });
                  setNewSubjCode('');
                  setNewSubjName('');
                  loadAll();
                }}
                className="rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white cursor-pointer"
              >
                Tambah
              </button>
            </div>
            <div className="divide-y divide-slate-100 text-sm">
              {subjects.map((s) => (
                <div key={s.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <span className="font-mono-tabular font-semibold text-blue-700 mr-2">
                      {s.code}
                    </span>
                    <span className="font-medium text-slate-900">{s.name}</span>
                    <span className="text-xs text-slate-500 ml-2">KKM {s.kkm}</span>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      await apiFetch(`/api/admin/subjects/${s.id}`, { method: 'DELETE' });
                      loadAll();
                    }}
                    className="text-xs text-red-600 hover:underline cursor-pointer"
                  >
                    Hapus
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {subTab === 'school' && school && (
        <form
          onSubmit={handleSaveSchool}
          className="bg-white border border-slate-200 rounded-lg p-6 space-y-4 max-w-3xl"
        >
          <div className="flex items-center gap-2 font-display text-base font-bold text-slate-900">
            <School className="w-5 h-5 text-blue-700" />
            <span>Identitas Sekolah &amp; Kop Laporan Resmi</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nama Sekolah
              </label>
              <input
                type="text"
                value={school.name}
                onChange={(e) => setSchool({ ...school, name: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                NPSN
              </label>
              <input
                type="text"
                value={school.npsn}
                onChange={(e) => setSchool({ ...school, npsn: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono-tabular"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Alamat Lengkap
              </label>
              <input
                type="text"
                value={school.address}
                onChange={(e) => setSchool({ ...school, address: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Kepala Sekolah
              </label>
              <input
                type="text"
                value={school.headmaster}
                onChange={(e) =>
                  setSchool({ ...school, headmaster: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                NIP Kepala Sekolah
              </label>
              <input
                type="text"
                value={school.nipHeadmaster}
                onChange={(e) =>
                  setSchool({ ...school, nipHeadmaster: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono-tabular"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tahun Pelajaran
              </label>
              <input
                type="text"
                value={school.academicYear}
                onChange={(e) =>
                  setSchool({ ...school, academicYear: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Semester Aktif
              </label>
              <select
                value={school.activeSemester}
                onChange={(e) =>
                  setSchool({ ...school, activeSemester: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white"
              >
                <option value="Ganjil">Ganjil</option>
                <option value="Genap">Genap</option>
              </select>
            </div>
          </div>
          <button
            type="submit"
            className="rounded-lg bg-blue-700 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-800 cursor-pointer"
          >
            Simpan Pengaturan Sekolah
          </button>
        </form>
      )}

      {subTab === 'backup' && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-700" />
              <div>
                <h2 className="font-display text-base font-bold text-slate-900">
                  Backup Otomatis &amp; Pemulihan Database
                </h2>
                <p className="text-xs text-slate-500">
                  Sistem mencadangkan database otomatis setiap 6 jam. Anda juga dapat membuat atau memulihkan snapshot kapan saja.
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleCreateBackup}
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 cursor-pointer"
              >
                Buat Backup Sekarang
              </button>
              <label className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                Restore dari File (.db)
                <input
                  type="file"
                  accept=".db"
                  className="hidden"
                  onChange={handleRestoreBackup}
                />
              </label>
            </div>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {backups.length === 0 ? (
              <p className="text-slate-500 py-4">
                Belum ada file backup manual. Klik "Buat Backup Sekarang" untuk membuat snapshot pertama.
              </p>
            ) : (
              backups.map((b) => (
                <div
                  key={b.filename}
                  className="py-2.5 flex items-center justify-between"
                >
                  <div>
                    <div className="font-mono-tabular font-semibold text-slate-900">
                      {b.filename}
                    </div>
                    <div className="text-slate-500">
                      {(b.size / 1024).toFixed(1)} KB · {new Date(b.createdAt).toLocaleString('id-ID')}
                    </div>
                  </div>
                  <a
                    href={`/api/admin/backups/download/${encodeURIComponent(b.filename)}`}
                    className="inline-flex items-center gap-1 text-blue-700 hover:underline font-semibold"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Unduh
                  </a>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {subTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-display text-base font-bold text-slate-900 mb-3">
            Audit Log Aktivitas Pengguna
          </h2>
          <div className="overflow-x-auto max-h-[480px]">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-200 text-slate-500">
                <tr>
                  <th className="py-2 pr-3 font-semibold">Waktu</th>
                  <th className="py-2 pr-3 font-semibold">Pengguna</th>
                  <th className="py-2 pr-3 font-semibold">Aksi</th>
                  <th className="py-2 font-semibold">Detail</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditLogs.map((l) => (
                  <tr key={l.id}>
                    <td className="py-2 pr-3 font-mono-tabular text-slate-500 whitespace-nowrap">
                      {l.created_at}
                    </td>
                    <td className="py-2 pr-3 font-medium text-slate-900">
                      {l.full_name || 'Sistem'} ({l.role || '-'})
                    </td>
                    <td className="py-2 pr-3 font-mono-tabular font-semibold text-blue-700">
                      {l.action}
                    </td>
                    <td className="py-2 text-slate-600">{l.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
