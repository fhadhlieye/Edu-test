import React, { useEffect, useState } from 'react';
import {
  Copy,
  Download,
  Edit3,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import { MathText } from './SchoolCrest';
import type { Difficulty, QuestionItem, QuestionType } from '../types/exam';

const TYPE_LABELS: Record<QuestionType, string> = {
  PG: 'Pilihan Ganda',
  PG_KOMPLEKS: 'PG Kompleks',
  MENJODOHKAN: 'Menjodohkan',
  ISIAN_SINGKAT: 'Isian Singkat',
  ESAI: 'Uraian / Esai',
};

export function BankSoalView() {
  const [questions, setQuestions] = useState<QuestionItem[]>([]);
  const [subjects, setSubjects] = useState<Array<{ id: number; name: string }>>([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState('');
  const [filterSubject, setFilterSubject] = useState('');
  const [filterGrade, setFilterGrade] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterDifficulty, setFilterDifficulty] = useState('');

  const [editing, setEditing] = useState<QuestionItem | null>(null);
  const [saving, setSaving] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams();
      if (search) qs.set('q', search);
      if (filterSubject) qs.set('subjectId', filterSubject);
      if (filterGrade) qs.set('gradeLevel', filterGrade);
      if (filterType) qs.set('questionType', filterType);
      if (filterDifficulty) qs.set('difficulty', filterDifficulty);

      const [qRes, refRes] = await Promise.all([
        apiFetch<{ questions: QuestionItem[] }>(`/api/questions?${qs.toString()}`),
        apiFetch<{ subjects: Array<{ id: number; name: string }> }>(
          '/api/admin/reference-data'
        ),
      ]);
      setQuestions(qRes.questions || []);
      setSubjects(refRes.subjects || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [filterSubject, filterGrade, filterType, filterDifficulty]);

  const openNewQuestion = () => {
    setEditing({
      subjectId: subjects[0]?.id || 1,
      gradeLevel: 'IX',
      topic: 'Umum',
      difficulty: 'SEDANG',
      questionType: 'PG',
      stimulusTitle: '',
      stimulusText: '',
      stem: '',
      options: [
        { key: 'A', text: '' },
        { key: 'B', text: '' },
        { key: 'C', text: '' },
        { key: 'D', text: '' },
      ],
      correctAnswer: 'A',
      matchingPairs: [
        { id: 'p1', leftText: '', rightText: '' },
        { id: 'p2', leftText: '', rightText: '' },
      ],
      shortAnswerConfig: {
        acceptedAnswers: [''],
        caseSensitive: false,
        ignoreWhitespace: false,
        numericTolerance: 0,
      },
      rubric: [
        {
          id: 'r1',
          aspect: 'Ketepatan Konsep',
          maxPoints: 5,
          description: 'Jawaban sesuai konsep materi.',
        },
      ],
      weight: 2,
      partialScoring: true,
      pgkMode: 'PARTIAL',
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing || !editing.stem.trim()) return;
    setSaving(true);
    try {
      if (editing.id) {
        await apiFetch(`/api/questions/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(editing),
        });
      } else {
        await apiFetch('/api/questions', {
          method: 'POST',
          body: JSON.stringify(editing),
        });
      }
      setEditing(null);
      loadData();
    } finally {
      setSaving(false);
    }
  };

  const handleDuplicate = async (id: number) => {
    await apiFetch(`/api/questions/${id}/duplicate`, { method: 'POST' });
    loadData();
  };

  const handleDelete = async (id: number) => {
    await apiFetch(`/api/questions/${id}`, { method: 'DELETE' });
    loadData();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Bank Soal AKM
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Kelola kumpulan butir soal reusable lintas mata pelajaran, kelas, dan tingkat kesulitan.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <a
            href="/api/questions/export?format=xlsx"
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <Download className="w-4 h-4" />
            Ekspor Excel
          </a>
          <button
            type="button"
            onClick={openNewQuestion}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Buat Soal Baru
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
        <div className="lg:col-span-2 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && loadData()}
            placeholder="Cari pertanyaan atau topik..."
            className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-sm"
          />
        </div>
        <select
          aria-label="Filter Mata Pelajaran"
          value={filterSubject}
          onChange={(e) => setFilterSubject(e.target.value)}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
        >
          <option value="">Semua Mapel</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <select
          aria-label="Filter Kelas"
          value={filterGrade}
          onChange={(e) => setFilterGrade(e.target.value)}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
        >
          <option value="">Semua Kelas</option>
          <option value="VII">Kelas VII</option>
          <option value="VIII">Kelas VIII</option>
          <option value="IX">Kelas IX</option>
        </select>
        <select
          aria-label="Filter Tipe AKM"
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
        >
          <option value="">Semua Tipe Soal</option>
          <option value="PG">Pilihan Ganda</option>
          <option value="PG_KOMPLEKS">PG Kompleks</option>
          <option value="MENJODOHKAN">Menjodohkan</option>
          <option value="ISIAN_SINGKAT">Isian Singkat</option>
          <option value="ESAI">Uraian / Esai</option>
        </select>
        <select
          aria-label="Filter Tingkat Kesulitan"
          value={filterDifficulty}
          onChange={(e) => setFilterDifficulty(e.target.value)}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
        >
          <option value="">Semua Kesulitan</option>
          <option value="MUDAH">Mudah</option>
          <option value="SEDANG">Sedang</option>
          <option value="SUKAR">Sukar</option>
        </select>
      </div>

      {/* Question List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-28 bg-white border border-slate-200 rounded-lg animate-pulse" />
          ))}
        </div>
      ) : questions.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-lg p-10 text-center">
          <p className="text-sm text-slate-600">
            Tidak ada soal yang sesuai dengan filter.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {questions.map((q) => (
            <div
              key={q.id}
              className="bg-white border border-slate-200 rounded-lg p-5 space-y-2.5"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-blue-700">
                    {TYPE_LABELS[q.questionType]}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{q.subjectName}</span>
                  <span aria-hidden="true">·</span>
                  <span>Kelas {q.gradeLevel}</span>
                  <span aria-hidden="true">·</span>
                  <span>{q.topic}</span>
                  <span aria-hidden="true">·</span>
                  <span>{q.difficulty}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums font-medium text-slate-700">
                    Bobot {q.weight}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditing(q)}
                    aria-label={`Edit soal ${q.id}`}
                    className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => q.id && handleDuplicate(q.id)}
                    aria-label={`Duplikasi soal ${q.id}`}
                    className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Duplikasi
                  </button>
                  <button
                    type="button"
                    onClick={() => q.id && handleDelete(q.id)}
                    aria-label={`Hapus soal ${q.id}`}
                    className="inline-flex items-center gap-1 rounded border border-red-200 px-2.5 py-1 text-xs font-medium text-red-600 hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Hapus
                  </button>
                </div>
              </div>

              {q.stimulusText && (
                <div className="rounded bg-slate-50 border border-slate-200 p-3 text-xs text-slate-700">
                  <div className="font-semibold text-slate-800 mb-1">
                    {q.stimulusTitle || 'Stimulus Bacaan'}
                  </div>
                  <p className="line-clamp-3">{q.stimulusText}</p>
                </div>
              )}

              <div className="text-sm font-medium text-slate-900">
                <MathText text={q.stem} />
              </div>

              <div className="text-xs text-slate-500">
                Kunci:{' '}
                <span className="font-mono-tabular font-semibold text-emerald-700">
                  {q.questionType === 'MENJODOHKAN'
                    ? `${q.matchingPairs.length} pasangan`
                    : Array.isArray(q.correctAnswer)
                      ? q.correctAnswer.join(', ')
                      : String(q.correctAnswer || '-')}
                </span>
                {' · '}Pembuat: {q.creatorName}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Modal */}
      {editing && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4"
        >
          <form
            onSubmit={handleSave}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6 space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="font-display text-lg font-bold text-slate-900">
                {editing.id ? 'Edit Butir Soal' : 'Buat Soal AKM Baru'}
              </h2>
              <button
                type="button"
                aria-label="Tutup editor soal"
                onClick={() => setEditing(null)}
                className="p-1 text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mata Pelajaran
                </label>
                <select
                  value={editing.subjectId}
                  onChange={(e) =>
                    setEditing({ ...editing, subjectId: Number(e.target.value) })
                  }
                  className="w-full rounded border border-slate-300 px-2.5 py-1.5 text-sm"
                >
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tipe Soal
                </label>
                <select
                  value={editing.questionType}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      questionType: e.target.value as QuestionType,
                    })
                  }
                  className="w-full rounded border border-slate-300 px-2.5 py-1.5 text-sm"
                >
                  <option value="PG">Pilihan Ganda</option>
                  <option value="PG_KOMPLEKS">PG Kompleks</option>
                  <option value="MENJODOHKAN">Menjodohkan</option>
                  <option value="ISIAN_SINGKAT">Isian Singkat</option>
                  <option value="ESAI">Uraian / Esai</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kelas &amp; Kesulitan
                </label>
                <div className="flex gap-1.5">
                  <select
                    value={editing.gradeLevel}
                    onChange={(e) =>
                      setEditing({ ...editing, gradeLevel: e.target.value })
                    }
                    className="w-1/2 rounded border border-slate-300 px-2 py-1.5 text-xs"
                  >
                    <option value="VII">VII</option>
                    <option value="VIII">VIII</option>
                    <option value="IX">IX</option>
                  </select>
                  <select
                    value={editing.difficulty}
                    onChange={(e) =>
                      setEditing({
                        ...editing,
                        difficulty: e.target.value as Difficulty,
                      })
                    }
                    className="w-1/2 rounded border border-slate-300 px-2 py-1.5 text-xs"
                  >
                    <option value="MUDAH">Mudah</option>
                    <option value="SEDANG">Sedang</option>
                    <option value="SUKAR">Sukar</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Bobot Nilai
                </label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={editing.weight}
                  onChange={(e) =>
                    setEditing({ ...editing, weight: Number(e.target.value) || 1 })
                  }
                  className="w-full rounded border border-slate-300 px-2.5 py-1.5 text-sm tabular-nums"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Topik / Bab Materi
                </label>
                <input
                  type="text"
                  value={editing.topic}
                  onChange={(e) =>
                    setEditing({ ...editing, topic: e.target.value })
                  }
                  className="w-full rounded border border-slate-300 px-3 py-1.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Judul Stimulus (Opsional)
                </label>
                <input
                  type="text"
                  value={editing.stimulusTitle || ''}
                  onChange={(e) =>
                    setEditing({ ...editing, stimulusTitle: e.target.value })
                  }
                  className="w-full rounded border border-slate-300 px-3 py-1.5 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Teks Stimulus / Bacaan Panjang (Opsional)
              </label>
              <textarea
                rows={2}
                value={editing.stimulusText || ''}
                onChange={(e) =>
                  setEditing({ ...editing, stimulusText: e.target.value })
                }
                className="w-full rounded border border-slate-300 p-2.5 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Pertanyaan (mendukung rumus LaTeX seperti $x^2 + 5 = 14$)
              </label>
              <textarea
                rows={3}
                required
                value={editing.stem}
                onChange={(e) => setEditing({ ...editing, stem: e.target.value })}
                className="w-full rounded border border-slate-300 p-2.5 text-sm"
              />
            </div>

            {(editing.questionType === 'PG' ||
              editing.questionType === 'PG_KOMPLEKS') && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700">
                    Pilihan Jawaban (Klik huruf untuk menandai kunci)
                  </span>
                  <div className="flex items-center gap-2">
                    {editing.questionType === 'PG_KOMPLEKS' && (
                      <select
                        value={editing.pgkMode}
                        onChange={(e) =>
                          setEditing({
                            ...editing,
                            pgkMode: e.target.value as 'ALL_OR_NOTHING' | 'PARTIAL',
                            partialScoring: e.target.value === 'PARTIAL',
                          })
                        }
                        className="rounded border border-slate-300 px-2 py-1 text-xs"
                      >
                        <option value="PARTIAL">Skor Parsial</option>
                        <option value="ALL_OR_NOTHING">Harus Benar Semua</option>
                      </select>
                    )}
                    {editing.options.length < 5 && (
                      <button
                        type="button"
                        onClick={() => {
                          const keys = ['A', 'B', 'C', 'D', 'E'];
                          const nextKey = keys[editing.options.length] || 'E';
                          setEditing({
                            ...editing,
                            options: [...editing.options, { key: nextKey, text: '' }],
                          });
                        }}
                        className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
                      >
                        + Opsi E
                      </button>
                    )}
                  </div>
                </div>
                {editing.options.map((opt, idx) => {
                  const isKey = Array.isArray(editing.correctAnswer)
                    ? editing.correctAnswer.includes(opt.key)
                    : editing.correctAnswer === opt.key;
                  return (
                    <div key={opt.key} className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (editing.questionType === 'PG') {
                            setEditing({ ...editing, correctAnswer: opt.key });
                          } else {
                            const cur = Array.isArray(editing.correctAnswer)
                              ? editing.correctAnswer
                              : [];
                            const next = cur.includes(opt.key)
                              ? cur.filter((k) => k !== opt.key)
                              : [...cur, opt.key];
                            setEditing({ ...editing, correctAnswer: next });
                          }
                        }}
                        className={`w-8 h-8 rounded text-xs font-bold shrink-0 cursor-pointer ${
                          isKey
                            ? 'bg-emerald-700 text-white'
                            : 'bg-slate-100 border border-slate-300 text-slate-700'
                        }`}
                      >
                        {opt.key}
                      </button>
                      <input
                        type="text"
                        value={opt.text}
                        onChange={(e) => {
                          const next = editing.options.map((o, i) =>
                            i === idx ? { ...o, text: e.target.value } : o
                          );
                          setEditing({ ...editing, options: next });
                        }}
                        placeholder={`Teks pilihan ${opt.key}`}
                        className="flex-1 rounded border border-slate-300 px-3 py-1.5 text-sm"
                      />
                    </div>
                  );
                })}
              </div>
            )}

            {editing.questionType === 'MENJODOHKAN' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700">
                    Pasangan Pernyataan &amp; Jawaban
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setEditing({
                        ...editing,
                        matchingPairs: [
                          ...editing.matchingPairs,
                          { id: `p${Date.now()}`, leftText: '', rightText: '' },
                        ],
                      })
                    }
                    className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
                  >
                    + Tambah Pasangan
                  </button>
                </div>
                {editing.matchingPairs.map((pair, idx) => (
                  <div key={pair.id} className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={pair.leftText}
                      onChange={(e) => {
                        const next = editing.matchingPairs.map((p, i) =>
                          i === idx ? { ...p, leftText: e.target.value } : p
                        );
                        setEditing({ ...editing, matchingPairs: next });
                      }}
                      placeholder="Pernyataan kiri"
                      className="rounded border border-slate-300 px-2.5 py-1.5 text-sm"
                    />
                    <input
                      type="text"
                      value={pair.rightText}
                      onChange={(e) => {
                        const next = editing.matchingPairs.map((p, i) =>
                          i === idx ? { ...p, rightText: e.target.value } : p
                        );
                        setEditing({ ...editing, matchingPairs: next });
                      }}
                      placeholder="Pasangan kanan"
                      className="rounded border border-slate-300 px-2.5 py-1.5 text-sm"
                    />
                  </div>
                ))}
              </div>
            )}

            {editing.questionType === 'ISIAN_SINGKAT' && (
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  Alternatif Jawaban Benar (pisahkan dengan koma)
                </label>
                <input
                  type="text"
                  value={editing.shortAnswerConfig.acceptedAnswers.join(', ')}
                  onChange={(e) => {
                    const alts = e.target.value
                      .split(',')
                      .map((s) => s.trim())
                      .filter(Boolean);
                    setEditing({
                      ...editing,
                      correctAnswer: alts[0] || '',
                      shortAnswerConfig: {
                        ...editing.shortAnswerConfig,
                        acceptedAnswers: alts,
                      },
                    });
                  }}
                  placeholder="Contoh: Palembang, Kota Palembang"
                  className="w-full rounded border border-slate-300 px-3 py-1.5 text-sm"
                />
                <div className="flex flex-wrap gap-4 text-xs text-slate-700 pt-1">
                  <label className="flex items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={editing.shortAnswerConfig.caseSensitive}
                      onChange={(e) =>
                        setEditing({
                          ...editing,
                          shortAnswerConfig: {
                            ...editing.shortAnswerConfig,
                            caseSensitive: e.target.checked,
                          },
                        })
                      }
                    />
                    Peka huruf besar/kecil
                  </label>
                  <label className="flex items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={editing.shortAnswerConfig.ignoreWhitespace}
                      onChange={(e) =>
                        setEditing({
                          ...editing,
                          shortAnswerConfig: {
                            ...editing.shortAnswerConfig,
                            ignoreWhitespace: e.target.checked,
                          },
                        })
                      }
                    />
                    Abaikan spasi berlebih
                  </label>
                  <label className="flex items-center gap-1.5">
                    Toleransi angka:
                    <input
                      type="number"
                      step="0.01"
                      min={0}
                      value={editing.shortAnswerConfig.numericTolerance}
                      onChange={(e) =>
                        setEditing({
                          ...editing,
                          shortAnswerConfig: {
                            ...editing.shortAnswerConfig,
                            numericTolerance: Number(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-16 rounded border border-slate-300 px-2 py-0.5 tabular-nums"
                    />
                  </label>
                </div>
              </div>
            )}

            {editing.questionType === 'ESAI' && (
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  Acuan Kunci / Rubrik Penilaian Esai
                </label>
                <textarea
                  rows={2}
                  value={String(editing.correctAnswer || '')}
                  onChange={(e) =>
                    setEditing({ ...editing, correctAnswer: e.target.value })
                  }
                  placeholder="Tuliskan poin jawaban ideal untuk membantu koreksi guru & AI..."
                  className="w-full rounded border border-slate-300 p-2 text-sm"
                />
              </div>
            )}

            <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={saving}
                className="rounded-lg bg-blue-700 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60 cursor-pointer"
              >
                {saving ? 'Menyimpan...' : 'Simpan Soal'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
