import React, { useEffect, useState } from 'react';
import { Eye, EyeOff, KeyRound, LogIn, ShieldCheck } from 'lucide-react';
import { apiFetch } from '../utils/api';
import { SchoolCrest } from './SchoolCrest';
import type { UserAccount } from '../types/exam';

interface DemoAccount {
  role: string;
  label: string;
  username: string;
  hint: string;
}

export function LoginView({
  onLoggedIn,
}: {
  onLoggedIn: (user: UserAccount) => void;
}) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [demoAccounts, setDemoAccounts] = useState<DemoAccount[]>([]);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    apiFetch<{ accounts: DemoAccount[] }>('/api/auth/demo-accounts')
      .then((res) => setDemoAccounts(res.accounts || []))
      .catch(() => {});
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!identifier.trim() || !password) {
      setError('Masukkan username, NISN, atau email beserta kata sandi.');
      return;
    }
    setLoading(true);
    try {
      const res = await apiFetch<{ user: UserAccount }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ identifier: identifier.trim(), password }),
      });
      onLoggedIn(res.user);
    } catch (err: any) {
      setError(err.message || 'Gagal masuk ke sistem.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickFill = (acc: DemoAccount) => {
    setIdentifier(acc.username);
    setPassword(acc.hint);
    setError('');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 px-6 py-3.5">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <SchoolCrest className="w-9 h-9 shrink-0" />
            <span className="font-display text-lg font-bold text-slate-900 tracking-tight whitespace-nowrap">
              EDU-TEST SMP Negeri 61 Palembang
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-600">
            <ShieldCheck className="w-4 h-4 text-blue-700" />
            <span>Platform Asesmen Digital Standar AKM</span>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-5xl bg-white border border-slate-200 rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
          {/* Left Institutional Panel */}
          <div className="lg:col-span-6 relative bg-blue-900 text-white flex flex-col justify-between min-h-[320px]">
            {!imgError ? (
              <img
                src="/src/assets/images/campus_exam_banner_1794791547180.jpg"
                alt="Ruang Ujian Digital SMP Negeri 61 Palembang"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="absolute inset-0 w-full h-full object-cover"
              />
            ) : null}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-blue-950/70 to-blue-900/50" />
            <div className="relative z-10 p-8 flex flex-col justify-between h-full gap-8">
              <div>
                <p className="text-xs font-medium text-amber-300 tracking-wide mb-2">
                  Pemerintah Kota Palembang · Dinas Pendidikan
                </p>
                <h1
                  className="font-display text-2xl sm:text-3xl font-bold leading-tight text-white"
                  style={{ textWrap: 'balance' }}
                >
                  Sistem Evaluasi &amp; Ujian Digital Terpadu
                </h1>
                <p className="mt-3 text-sm text-slate-200 leading-relaxed max-w-md">
                  Mendukung impor soal Word/PDF otomatis, lima bentuk soal AKM, pengawasan
                  kejujuran ujian, koreksi otomatis, dan analisis butir soal.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/15 text-xs">
                <div>
                  <div className="font-display text-lg font-bold text-white tabular-nums">
                    5 Tipe AKM
                  </div>
                  <div className="text-slate-300">PG, PGK, Jodohkan, Isian, Esai</div>
                </div>
                <div>
                  <div className="font-display text-lg font-bold text-amber-300 tabular-nums">
                    Smart Import
                  </div>
                  <div className="text-slate-300">DOCX, PDF &amp; Scan OCR</div>
                </div>
                <div>
                  <div className="font-display text-lg font-bold text-white tabular-nums">
                    Anti-Cheat
                  </div>
                  <div className="text-slate-300">Fullscreen &amp; Tab Audit</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Login Form */}
          <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-center">
            <div className="mb-6">
              <h2 className="font-display text-xl font-bold text-slate-900">
                Masuk ke Portal Ujian
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                Gunakan akun Guru, Siswa (NISN), atau Administrator Sekolah.
              </p>
            </div>

            {error && (
              <div
                role="alert"
                className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
              >
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="login-identifier"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  Username / NISN / Email
                </label>
                <input
                  id="login-identifier"
                  type="text"
                  autoComplete="username"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="Contoh: siswa.ahmad atau guru.ratna"
                  className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                />
              </div>

              <div>
                <label
                  htmlFor="login-password"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  Kata Sandi
                </label>
                <div className="relative">
                  <input
                    id="login-password"
                    type={showPass ? 'text' : 'password'}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Masukkan kata sandi"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 pr-10 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                  />
                  <button
                    type="button"
                    aria-label={showPass ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60 transition-colors cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                {loading ? 'Memverifikasi...' : 'Masuk Sekarang'}
              </button>
            </form>

            {demoAccounts.length > 0 && (
              <div className="mt-7 pt-6 border-t border-slate-200">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2.5">
                  <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                  <span>Akun Contoh Pengujian (Klik untuk isi otomatis)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {demoAccounts.map((acc) => (
                    <button
                      key={acc.username}
                      type="button"
                      onClick={() => handleQuickFill(acc)}
                      className="text-left rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 hover:border-blue-400 hover:bg-blue-50/50 transition-colors cursor-pointer"
                    >
                      <div className="text-xs font-semibold text-slate-800">
                        {acc.label}
                      </div>
                      <div className="text-[11px] font-mono-tabular text-slate-500">
                        {acc.username} · {acc.hint}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
