import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Archive,
  CheckCircle2,
  Download,
  FileText,
  FileUp,
  Plus,
  Save,
  Trash2,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import type { ParsedQuestionDraft } from '../utils/questionParser';
import type { QuestionType } from '../types/exam';

interface SubjectOption {
  id: number;
  name: string;
  code: string;
}

interface ArchiveItem {
  id: number;
  original_filename: string;
  extraction_method: string;
  total_detected: number;
  created_at: string;
  uploader_name: string;
}

const SAMPLE_DOC_TEXT = `Bacalah teks berikut untuk menjawab soal nomor 1 dan 2!
Jembatan Ampera merupakan ikon Kota Palembang yang membentang di atas Sungai Musi sejak tahun 1965. Jembatan ini menghubungkan kawasan Seberang Ulu dan Seberang Ilir.

1. Berdasarkan bacaan di atas, di atas sungai apakah Jembatan Ampera berdiri?
A. Sungai Batanghari
B. Sungai Musi
C. Sungai Mahakam
D. Sungai Kampar
Kunci: B

2. Pilih lebih dari satu pernyataan yang sesuai dengan isi bacaan tentang Jembatan Ampera!
A. Menghubungkan Seberang Ulu dan Seberang Ilir
B. Berdiri di atas Sungai Musi
C. Dibangun pada tahun 1995
D. Berada di Kota Medan
Kunci: A, B

3. Jodohkan istilah berikut dengan pasangannya yang tepat:
Seberang Ilir -> Wilayah utara Sungai Musi
Jembatan Ampera -> Ikon Kota Palembang

4. Jembatan Ampera mulai diresmikan pada tahun ____.
Kunci: 1965

5. Jelaskan bagaimana keberadaan Jembatan Ampera memengaruhi mobilitas dan ekonomi masyarakat Palembang!`;

export function SmartImportView({
  onSavedToBank,
}: {
  onSavedToBank: () => void;
}) {
  const [subjects, setSubjects] = useState<SubjectOption[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number>(1);
  const [gradeLevel, setGradeLevel] = useState('IX');
  const [defaultTopic, setDefaultTopic] = useState('Asesmen AKM');

  const [file, setFile] = useState<File | null>(null);
  const [rawText, setRawText] = useState('');
  const [progress, setProgress] = useState(0);
  const [extracting, setExtracting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const [sourceDocumentId, setSourceDocumentId] = useState<number | null>(null);
  const [extractionMethod, setExtractionMethod] = useState('');
  const [drafts, setDrafts] = useState<ParsedQuestionDraft[]>([]);
  const [archives, setArchives] = useState<ArchiveItem[]>([]);

  const loadRefs = async () => {
    try {
      const [refRes, archRes] = await Promise.all([
        apiFetch<{ subjects: SubjectOption[] }>('/api/admin/reference-data'),
        apiFetch<{ archives: ArchiveItem[] }>('/api/questions/archives'),
      ]);
      setSubjects(refRes.subjects || []);
      if (refRes.subjects?.length) setSelectedSubjectId(refRes.subjects[0].id);
      setArchives(archRes.archives || []);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    loadRefs();
  }, []);

  const handleExtract = async () => {
    setError('');
    setSuccessMsg('');
    if (!file && !rawText.trim()) {
      setError('Pilih file (.doc, .docx, .pdf, gambar scan) atau tempel teks soal terlebih dahulu.');
      return;
    }

    setExtracting(true);
    setProgress(15);
    const timer = setInterval(() => {
      setProgress((p) => (p < 85 ? p + 12 : p));
    }, 350);

    try {
      const form = new FormData();
      if (file) form.append('file', file);
      if (rawText.trim()) form.append('rawText', rawText);
      form.append('topic', defaultTopic);

      const res = await apiFetch<{
        sourceDocumentId: number;
        extractionMethod: string;
        totalDetected: number;
        questions: ParsedQuestionDraft[];
      }>('/api/questions/smart-import', {
        method: 'POST',
        body: form,
      });

      setProgress(100);
      setSourceDocumentId(res.sourceDocumentId);
      setExtractionMethod(res.extractionMethod);
      setDrafts(res.questions || []);
      loadRefs();
      if (!res.questions?.length) {
        setError('Dokumen terbaca namun belum ada soal bernomor yang terdeteksi. Anda dapat menambah soal secara manual di bawah.');
      }
    } catch (err: any) {
      setError(err.message || 'Gagal memproses dokumen.');
    } finally {
      clearInterval(timer);
      setExtracting(false);
    }
  };

  const updateDraft = (idx: number, patch: Partial<ParsedQuestionDraft>) => {
    setDrafts((prev) =>
      prev.map((d, i) => (i === idx ? { ...d, ...patch } : d))
    );
  };

  const addEmptyDraft = () => {
    setDrafts((prev) => [
      ...prev,
      {
        tempId: `manual-${Date.now()}`,
        orderNumber: prev.length + 1,
        questionType: 'PG',
        stem: '',
        options: [
          { key: 'A', text: '' },
          { key: 'B', text: '' },
          { key: 'C', text: '' },
          { key: 'D', text: '' },
        ],
        correctAnswer: 'A',
        matchingPairs: [],
        shortAnswerConfig: {
          acceptedAnswers: [],
          caseSensitive: false,
          ignoreWhitespace: false,
          numericTolerance: 0,
        },
        rubric: [],
        difficulty: 'SEDANG',
        topic: defaultTopic,
        weight: 2,
        partialScoring: false,
        pgkMode: 'ALL_OR_NOTHING',
        warnings: [],
      },
    ]);
  };

  const handleSaveToBank = async () => {
    setError('');
    setSuccessMsg('');
    if (drafts.length === 0) return;
    setSaving(true);
    try {
      const res = await apiFetch<{ count: number }>('/api/questions/bulk-save', {
        method: 'POST',
        body: JSON.stringify({
          subjectId: selectedSubjectId,
          gradeLevel,
          sourceDocumentId,
          questions: drafts,
        }),
      });
      setSuccessMsg(`${res.count} soal berhasil disimpan ke Bank Soal SMP Negeri 61 Palembang.`);
      onSavedToBank();
    } catch (err: any) {
      setError(err.message || 'Gagal menyimpan ke Bank Soal.');
    } finally {
      setSaving(false);
    }
  };

  const warningCount = drafts.filter((d) => d.warnings && d.warnings.length > 0).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900">
          Smart Question Import
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Unggah soal dari Microsoft Word (.doc/.docx), PDF teks, atau hasil scan gambar tanpa perlu mengubah format template.
        </p>
      </div>

      {/* Upload & Metadata Panel */}
      <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="si-subject" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Mata Pelajaran Tujuan
            </label>
            <select
              id="si-subject"
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="si-grade" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Tingkat Kelas
            </label>
            <select
              id="si-grade"
              value={gradeLevel}
              onChange={(e) => setGradeLevel(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              <option value="VII">Kelas VII</option>
              <option value="VIII">Kelas VIII</option>
              <option value="IX">Kelas IX</option>
            </select>
          </div>
          <div>
            <label htmlFor="si-topic" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Topik / Bab Materi
            </label>
            <input
              id="si-topic"
              type="text"
              value={defaultTopic}
              onChange={(e) => setDefaultTopic(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* File Dropzone */}
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-5 bg-slate-50 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
                <FileUp className="w-4 h-4 text-blue-700" />
                <span>Unggah Dokumen Soal (.doc, .docx, .pdf, .png, .jpg)</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Dokumen asli otomatis diarsipkan agar tidak pernah hilang.
              </p>
              <input
                type="file"
                accept=".doc,.docx,.pdf,.txt,.png,.jpg,.jpeg,.webp"
                aria-label="Pilih dokumen soal untuk diimpor"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                className="mt-4 block w-full text-xs text-slate-600 file:mr-3 file:rounded-md file:border-0 file:bg-blue-700 file:px-3.5 file:py-2 file:text-xs file:font-semibold file:text-white hover:file:bg-blue-800 cursor-pointer"
              />
              {file && (
                <div className="mt-3 text-xs font-medium text-blue-700">
                  File terpilih: {file.name} ({Math.round(file.size / 1024)} KB)
                </div>
              )}
            </div>
          </div>

          {/* Paste Text or Load Sample */}
          <div className="flex flex-col">
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="si-raw-text" className="text-xs font-semibold text-slate-700">
                Atau Tempel Teks Naskah Soal Langsung
              </label>
              <button
                type="button"
                onClick={() => {
                  setFile(null);
                  setRawText(SAMPLE_DOC_TEXT);
                }}
                className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
              >
                Muat Contoh Naskah 5 Tipe AKM
              </button>
            </div>
            <textarea
              id="si-raw-text"
              rows={5}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Tempel isi soal dari Word/PDF di sini untuk ekstraksi cepat..."
              className="w-full rounded-lg border border-slate-300 bg-white p-3 text-xs text-slate-800 font-mono"
            />
          </div>
        </div>

        {/* Progress Bar */}
        {extracting && (
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-medium text-slate-700">
              <span>Membaca dokumen, mendeteksi stimulus &amp; mengklasifikasi tipe AKM...</span>
              <span className="tabular-nums">{progress}%</span>
            </div>
            <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-700 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        {successMsg && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="text-xs text-slate-500">
            Sistem menjaga keaslian teks soal guru tanpa mengarang isi.
          </div>
          <button
            type="button"
            disabled={extracting}
            onClick={handleExtract}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60 cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            {extracting ? 'Mengekstrak Soal...' : 'Ekstrak Soal Otomatis'}
          </button>
        </div>
      </div>

      {/* Extraction Preview & Editor */}
      {drafts.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-900">
                Preview Hasil Ekstraksi ({drafts.length} Soal Terbaca)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Metode: {extractionMethod === 'GEMINI_AI' ? 'AI Multimodal & Struktur Dokumen' : 'Parser Heuristik Lokal'}
                {warningCount > 0 && ` · ${warningCount} soal perlu diperiksa`}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={addEmptyDraft}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Tambah Soal
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={handleSaveToBank}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-800 disabled:opacity-60 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                {saving ? 'Menyimpan...' : `Simpan ${drafts.length} Soal ke Bank Soal`}
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {drafts.map((d, idx) => (
              <div
                key={d.tempId}
                className="rounded-lg border border-slate-200 bg-slate-50/70 p-4 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3 text-sm font-bold text-slate-900">
                    <span className="tabular-nums">Soal #{idx + 1}</span>
                    <select
                      aria-label={`Tipe soal ${idx + 1}`}
                      value={d.questionType}
                      onChange={(e) =>
                        updateDraft(idx, {
                          questionType: e.target.value as QuestionType,
                        })
                      }
                      className="rounded-md border border-slate-300 bg-white px-2.5 py-1 text-xs font-semibold text-slate-800"
                    >
                      <option value="PG">Pilihan Ganda</option>
                      <option value="PG_KOMPLEKS">Pilihan Ganda Kompleks</option>
                      <option value="MENJODOHKAN">Menjodohkan</option>
                      <option value="ISIAN_SINGKAT">Isian Singkat</option>
                      <option value="ESAI">Uraian / Esai</option>
                    </select>
                    <label className="text-xs font-normal text-slate-600 flex items-center gap-1.5">
                      Bobot:
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={d.weight}
                        onChange={(e) =>
                          updateDraft(idx, { weight: Number(e.target.value) || 1 })
                        }
                        className="w-16 rounded border border-slate-300 bg-white px-2 py-0.5 text-xs tabular-nums"
                      />
                    </label>
                  </div>
                  <button
                    type="button"
                    aria-label={`Hapus soal ${idx + 1}`}
                    onClick={() =>
                      setDrafts((prev) => prev.filter((_, i) => i !== idx))
                    }
                    className="inline-flex items-center gap-1 text-xs font-medium text-red-600 hover:text-red-800 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Hapus
                  </button>
                </div>

                {d.warnings && d.warnings.length > 0 && (
                  <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>{d.warnings.join(' ')}</div>
                  </div>
                )}

                {d.stimulusText && (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Stimulus Bacaan Terhubung
                    </label>
                    <textarea
                      rows={2}
                      value={d.stimulusText}
                      onChange={(e) =>
                        updateDraft(idx, { stimulusText: e.target.value })
                      }
                      className="w-full rounded-md border border-slate-300 bg-white p-2 text-xs text-slate-700"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Teks Pertanyaan
                  </label>
                  <textarea
                    rows={2}
                    value={d.stem}
                    onChange={(e) => updateDraft(idx, { stem: e.target.value })}
                    className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm text-slate-900"
                  />
                </div>

                {/* Type-specific key editor */}
                {(d.questionType === 'PG' || d.questionType === 'PG_KOMPLEKS') && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {d.options.map((opt, oIdx) => {
                      const isKey = Array.isArray(d.correctAnswer)
                        ? d.correctAnswer.includes(opt.key)
                        : d.correctAnswer === opt.key;
                      return (
                        <div key={opt.key} className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              if (d.questionType === 'PG') {
                                updateDraft(idx, {
                                  correctAnswer: opt.key,
                                  warnings: [],
                                });
                              } else {
                                const cur = Array.isArray(d.correctAnswer)
                                  ? d.correctAnswer
                                  : [];
                                const next = cur.includes(opt.key)
                                  ? cur.filter((k) => k !== opt.key)
                                  : [...cur, opt.key];
                                updateDraft(idx, {
                                  correctAnswer: next,
                                  warnings: [],
                                });
                              }
                            }}
                            className={`w-7 h-7 rounded text-xs font-bold shrink-0 cursor-pointer ${
                              isKey
                                ? 'bg-emerald-700 text-white'
                                : 'bg-white border border-slate-300 text-slate-700'
                            }`}
                            title="Klik untuk jadikan kunci jawaban"
                          >
                            {opt.key}
                          </button>
                          <input
                            type="text"
                            value={opt.text}
                            onChange={(e) => {
                              const nextOpts = d.options.map((o, oi) =>
                                oi === oIdx ? { ...o, text: e.target.value } : o
                              );
                              updateDraft(idx, { options: nextOpts });
                            }}
                            className="flex-1 rounded border border-slate-300 bg-white px-2.5 py-1 text-xs"
                          />
                        </div>
                      );
                    })}
                  </div>
                )}

                {d.questionType === 'MENJODOHKAN' && (
                  <div className="space-y-1.5">
                    <div className="text-[11px] font-semibold text-slate-600">
                      Pasangan Pernyataan &amp; Jawaban
                    </div>
                    {d.matchingPairs.map((pair, pIdx) => (
                      <div key={pair.id} className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={pair.leftText}
                          onChange={(e) => {
                            const next = d.matchingPairs.map((p, pi) =>
                              pi === pIdx ? { ...p, leftText: e.target.value } : p
                            );
                            updateDraft(idx, { matchingPairs: next });
                          }}
                          className="rounded border border-slate-300 bg-white px-2.5 py-1 text-xs"
                        />
                        <input
                          type="text"
                          value={pair.rightText}
                          onChange={(e) => {
                            const next = d.matchingPairs.map((p, pi) =>
                              pi === pIdx ? { ...p, rightText: e.target.value } : p
                            );
                            updateDraft(idx, { matchingPairs: next });
                          }}
                          className="rounded border border-slate-300 bg-white px-2.5 py-1 text-xs"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {d.questionType === 'ISIAN_SINGKAT' && (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Kunci Jawaban Alternatif (pisahkan dengan koma)
                    </label>
                    <input
                      type="text"
                      value={d.shortAnswerConfig.acceptedAnswers.join(', ')}
                      onChange={(e) => {
                        const alts = e.target.value
                          .split(',')
                          .map((s) => s.trim())
                          .filter(Boolean);
                        updateDraft(idx, {
                          correctAnswer: alts[0] || '',
                          shortAnswerConfig: {
                            ...d.shortAnswerConfig,
                            acceptedAnswers: alts,
                          },
                          warnings: [],
                        });
                      }}
                      className="w-full rounded border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Archived Original Documents */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex items-center gap-2 mb-3">
          <Archive className="w-4 h-4 text-slate-600" />
          <h2 className="font-display text-base font-bold text-slate-900">
            Arsip Dokumen Soal Asli
          </h2>
        </div>
        {archives.length === 0 ? (
          <p className="text-xs text-slate-500">Belum ada dokumen yang diarsipkan.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-200 text-slate-500">
                <tr>
                  <th className="py-2 pr-4 font-semibold">Nama Dokumen</th>
                  <th className="py-2 pr-4 font-semibold">Pengunggah</th>
                  <th className="py-2 pr-4 font-semibold">Metode</th>
                  <th className="py-2 pr-4 font-semibold text-right">Soal Terdeteksi</th>
                  <th className="py-2 font-semibold text-right">Unduh</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {archives.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50">
                    <td className="py-2.5 pr-4 font-medium text-slate-900">
                      {a.original_filename}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-600">{a.uploader_name}</td>
                    <td className="py-2.5 pr-4 text-slate-600">{a.extraction_method}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums">
                      {a.total_detected}
                    </td>
                    <td className="py-2.5 text-right">
                      <a
                        href={`/api/questions/archives/${a.id}/download`}
                        className="inline-flex items-center gap-1 text-blue-700 hover:underline font-medium"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Arsip Asli
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
