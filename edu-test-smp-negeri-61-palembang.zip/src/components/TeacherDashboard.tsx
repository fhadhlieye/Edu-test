import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BookOpen,
  ClipboardCheck,
  FileUp,
  GraduationCap,
  ShieldAlert,
} from 'lucide-react';
import { apiFetch } from '../utils/api';
import {
  BarDistributionChart,
  PassRateDonut,
  TrendLineChart,
} from './Charts';

interface DashboardData {
  counts: {
    totalExams: number;
    activeExams: number;
    closedExams: number;
    totalQuestions: number;
    totalStudents: number;
    totalTeachers: number;
    totalClasses: number;
    totalViolations: number;
    pendingEssayCount: number;
    notCompletedActive: number;
  };
  summary: {
    totalParticipants: number;
    mean: number;
    median: number;
    min: number;
    max: number;
    passCount: number;
    remedialCount: number;
    passRate: number;
    distribution: Array<{ label: string; count: number }>;
    classBreakdown: Array<{
      className: string;
      mean: number;
      count: number;
      passRate: number;
    }>;
  };
  examTrend: Array<{
    id: number;
    title: string;
    scheduled_date: string;
    avg_score: number | null;
    participants: number;
  }>;
}

export function TeacherDashboard({
  onNavigate,
}: {
  onNavigate: (tab: string) => void;
}) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    apiFetch<DashboardData>('/api/analytics/dashboard')
      .then(setData)
      .catch((e) => setError(e.message || 'Gagal memuat dashboard.'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-white border border-slate-200 rounded-lg animate-pulse" />
          ))}
        </div>
        <div className="h-64 bg-white border border-slate-200 rounded-lg animate-pulse" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
        {error || 'Data dashboard tidak tersedia.'}
      </div>
    );
  }

  const { counts, summary, examTrend } = data;

  return (
    <div className="space-y-6">
      {/* Header Action Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Ringkasan Akademik &amp; Ujian
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Data pelaksanaan ujian, bank soal AKM, dan capaian siswa SMP Negeri 61 Palembang.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => onNavigate('smart-import')}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 transition-colors cursor-pointer whitespace-nowrap"
          >
            <FileUp className="w-4 h-4" />
            Smart Question Import
          </button>
          <button
            type="button"
            onClick={() => onNavigate('exams')}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            Kelola Ujian
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Total Ujian</span>
            <ClipboardCheck className="w-4 h-4 text-blue-700" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-900 tabular-nums">
            {counts.totalExams}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            {counts.activeExams} aktif · {counts.closedExams} selesai
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Bank Soal AKM</span>
            <BookOpen className="w-4 h-4 text-blue-700" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-900 tabular-nums">
            {counts.totalQuestions}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Butir soal tersimpan &amp; siap pakai
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Rata-Rata Nilai</span>
            <GraduationCap className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-900 tabular-nums">
            {summary.mean}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            Tertinggi {summary.max} · Terendah {summary.min}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Peserta &amp; Pengawasan</span>
            <ShieldAlert className="w-4 h-4 text-red-600" />
          </div>
          <div className="mt-2 font-display text-2xl font-bold text-slate-900 tabular-nums">
            {counts.totalStudents} Siswa
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            {counts.notCompletedActive} belum selesai ujian aktif · {counts.totalViolations} catatan
          </div>
        </div>
      </div>

      {/* Pending Action Notices */}
      {(counts.pendingEssayCount > 0 || counts.totalViolations > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {counts.pendingEssayCount > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    {counts.pendingEssayCount} Jawaban Esai Menunggu Koreksi
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Gunakan Asisten AI Rubrik untuk meninjau dan menyetujui skor akhir.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('grading')}
                className="shrink-0 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700 cursor-pointer whitespace-nowrap"
              >
                Koreksi Esai
              </button>
            </div>
          )}

          {counts.totalViolations > 0 && (
            <div className="bg-white border border-slate-200 rounded-lg p-4 flex items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    {counts.totalViolations} Log Aktivitas Pengawasan Tercatat
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Pantau peserta dengan peringatan pindah tab atau keluar fullscreen.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('monitor')}
                className="shrink-0 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer whitespace-nowrap"
              >
                Buka Pengawasan
              </button>
            </div>
          )}
        </div>
      )}

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-display text-base font-bold text-slate-900">
              Distribusi Nilai Siswa
            </h2>
            <span className="text-xs text-slate-500 tabular-nums">
              {summary.totalParticipants} hasil ujian terekam
            </span>
          </div>
          <BarDistributionChart
            data={summary.distribution.map((d) => ({
              label: d.label,
              value: d.count,
            }))}
          />
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h2 className="font-display text-base font-bold text-slate-900 mb-4">
              Ketuntasan Belajar (KKM)
            </h2>
            <PassRateDonut
              passCount={summary.passCount}
              remedialCount={summary.remedialCount}
            />
          </div>
          <div className="pt-4 mt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-xs">
            <div>
              <span className="text-slate-500 block">Median</span>
              <span className="font-semibold text-slate-900 tabular-nums">
                {summary.median}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Lulus KKM</span>
              <span className="font-semibold text-emerald-700 tabular-nums">
                {summary.passCount} siswa
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Remedial</span>
              <span className="font-semibold text-amber-700 tabular-nums">
                {summary.remedialCount} siswa
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Class Comparison & Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-display text-base font-bold text-slate-900 mb-3">
            Perbandingan Rata-Rata Antar Kelas
          </h2>
          {summary.classBreakdown.length === 0 ? (
            <p className="text-sm text-slate-500 py-8 text-center">
              Belum ada nilai antar kelas yang tercatat.
            </p>
          ) : (
            <BarDistributionChart
              data={summary.classBreakdown.map((c) => ({
                label: c.className,
                value: c.mean,
              }))}
              barColor="#0284C7"
              unitLabel="poin"
            />
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <h2 className="font-display text-base font-bold text-slate-900 mb-3">
            Perkembangan Rata-Rata Hasil Ujian
          </h2>
          <TrendLineChart
            points={examTrend
              .filter((e) => e.avg_score !== null)
              .map((e) => ({
                label: e.title,
                value: Number(e.avg_score || 0),
              }))}
          />
        </div>
      </div>
    </div>
  );
}
