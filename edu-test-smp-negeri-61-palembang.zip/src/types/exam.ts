export type Role = 'SUPER_ADMIN' | 'ADMIN_SEKOLAH' | 'GURU' | 'SISWA';

export type QuestionType =
  | 'PG'
  | 'PG_KOMPLEKS'
  | 'MENJODOHKAN'
  | 'ISIAN_SINGKAT'
  | 'ESAI';

export type Difficulty = 'MUDAH' | 'SEDANG' | 'SUKAR';
export type RoundingMode = 'NONE' | 'NEAREST' | 'CEIL' | 'FLOOR';
export type PGKMode = 'ALL_OR_NOTHING' | 'PARTIAL';
export type ExamStatus = 'DRAFT' | 'PUBLISHED' | 'ACTIVE' | 'CLOSED';
export type AttemptStatus = 'IN_PROGRESS' | 'LOCKED' | 'SUBMITTED' | 'GRADED';

export interface QuestionOption {
  key: string; // 'A' | 'B' | 'C' | 'D' | 'E'
  text: string;
  imageUrl?: string;
}

export interface MatchingPair {
  id: string;
  leftText: string;
  rightText: string;
}

export interface ShortAnswerConfig {
  acceptedAnswers: string[];
  caseSensitive: boolean;
  ignoreWhitespace: boolean;
  numericTolerance: number; // 0 = exact numeric/string match
}

export interface RubricCriterion {
  id: string;
  aspect: string;
  maxPoints: number;
  description: string;
}

export interface StimulusMedia {
  type: 'image' | 'table' | 'audio' | 'video' | 'svg';
  url?: string;
  caption?: string;
  htmlOrSvg?: string;
}

export interface QuestionItem {
  id?: number;
  schoolId?: number;
  subjectId: number;
  subjectName?: string;
  createdBy?: number;
  creatorName?: string;
  sourceDocumentId?: number | null;
  gradeLevel: string; // 'VII' | 'VIII' | 'IX'
  topic: string;
  difficulty: Difficulty;
  questionType: QuestionType;
  stimulusTitle?: string;
  stimulusText?: string;
  stimulusMedia?: StimulusMedia[];
  stem: string;
  mathLatex?: string;
  options: QuestionOption[];
  correctAnswer: string | string[]; // PG: 'A', PGK: ['A','C'], Menjodohkan: unused (uses matchingPairs), Isian: first accepted, Esai: model answer
  matchingPairs: MatchingPair[];
  shortAnswerConfig: ShortAnswerConfig;
  rubric: RubricCriterion[];
  weight: number;
  partialScoring: boolean;
  pgkMode: PGKMode;
  warnings?: string[];
  year?: number;
  createdAt?: string;
}

export type StudentAnswerPayload =
  | string // PG ('A'), ISIAN_SINGKAT ('Jakarta'), ESAI ('...')
  | string[] // PG_KOMPLEKS (['A', 'C'])
  | Record<string, string>; // MENJODOHKAN ({ [pairId]: selectedRightText })

export interface SchoolProfile {
  id: number;
  name: string;
  npsn: string;
  address: string;
  city: string;
  headmaster: string;
  nipHeadmaster: string;
  academicYear: string;
  activeSemester: string;
  headerText: string;
  logoUrl?: string;
}

export interface UserAccount {
  id: number;
  schoolId: number;
  username: string;
  email: string;
  fullName: string;
  role: Role;
  nipNisn: string;
  classId: number | null;
  className?: string;
  phone?: string;
  isActive: boolean;
}

export interface ExamConfig {
  id: number;
  schoolId: number;
  title: string;
  subjectId: number;
  subjectName?: string;
  createdBy: number;
  creatorName?: string;
  semester: string;
  academicYear: string;
  targetClassIds: number[];
  targetClassNames?: string[];
  scheduledDate: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  maxScore: number;
  passingScore: number;
  roundingMode: RoundingMode;
  maxAttempts: number;
  allowRemedial: boolean;
  showScoreImmediately: boolean;
  randomizeQuestions: boolean;
  randomizeOptions: boolean;
  allowBackNavigation: boolean;
  antiCheatEnabled: boolean;
  requireFullscreen: boolean;
  maxViolations: number;
  lockOnMaxViolations: boolean;
  lowBandwidthMode: boolean;
  instructions: string;
  status: ExamStatus;
  questionCount?: number;
}
