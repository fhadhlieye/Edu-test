# EDU-TEST SMP Negeri 61 Palembang

Platform ujian digital cerdas (Smart Assessment & Digital Examination Platform) berbasis standar AKM untuk SMP Negeri 61 Palembang.

## Fitur Utama
- **Smart Question Import**: Unggah soal dari `.doc`, `.docx`, `.pdf`, atau gambar hasil scan tanpa template khusus. Mendukung ekstraksi AI multimodal (`@google/genai` `gemini-4-hydrogen`) sekaligus fallback parser heuristik lokal. Arsip dokumen asli tersimpan otomatis.
- **5 Jenis Soal Standar AKM**: Pilihan Ganda, Pilihan Ganda Kompleks (all-or-nothing & skor parsial), Menjodohkan, Isian Singkat (toleransi spasi/kapital/numerik & alternatif jawaban), dan Uraian/Esai dengan Rubrik + Asisten AI Penilaian yang wajib disetujui guru.
- **Exam Engine & Anti-Curang**: Pengacakan soal/opsi per siswa, timer server-synced, autosave + antrean lokal saat offline, deteksi pindah tab/kehilangan fokus/keluar layar penuh, pencatatan log pelanggaran, penguncian sementara, dan dashboard buka kunci oleh pengawas.
- **Analisis & Laporan Akademik**: Rekap nilai, tingkat kesukaran ($P$), daya pembeda ($D$), efektivitas pengecoh PG, ekspor **PDF** (dengan Kop Surat SMP Negeri 61 Palembang), **Excel (.xlsx)**, **CSV**, Kartu Peserta Digital, Daftar Peserta, dan Berita Acara Ujian.
- **Administrasi Sekolah & RBAC**: Peran `SUPER_ADMIN`, `ADMIN_SEKOLAH`, `GURU`, dan `SISWA`, manajemen rombel & mapel, impor massal guru/siswa via Excel, audit log, dan backup/restore database otomatis.

## Konfigurasi & Menjalankan Lokal
1. Salin `.env.example` ke `.env` dan isi `GEMINI_API_KEY` (opsional; jika kosong, sistem tetap berjalan dengan parser heuristik & rubrik lokal).
2. Instal dependensi: `npm install`
3. Jalankan mode pengembangan: `npm run dev` (berjalan di `http://localhost:3000`)
4. Build produksi: `npm run build` lalu `npm start`

## Akun Contoh Pengujian
- **Super Admin**: `superadmin` / `admin123`
- **Admin Sekolah**: `admin61` / `admin123`
- **Guru Matematika**: `guru.ratna` / `guru123`
- **Guru B. Indonesia**: `guru.budi` / `guru123`
- **Siswa IX-A**: `siswa.ahmad` / `siswa123`
