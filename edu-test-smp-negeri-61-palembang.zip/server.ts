import express from 'express';
import path from 'node:path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { createBackupSnapshot } from './server/db.ts';
import { seedDatabaseIfEmpty } from './server/seed.ts';
import { authRouter } from './server/routes/authRoutes.ts';
import { adminRouter } from './server/routes/adminRoutes.ts';
import { questionRouter } from './server/routes/questionRoutes.ts';
import { examRouter } from './server/routes/examRoutes.ts';
import { gradingAnalyticsRouter } from './server/routes/gradingAnalyticsRoutes.ts';

dotenv.config();

async function startServer() {
  seedDatabaseIfEmpty();

  const app = express();
  app.set('trust proxy', 1);

  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));

  // Basic security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    next();
  });

  // Healthcheck
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'edu-test-smpn61-palembang' });
  });

  // API Routes
  app.use('/api/auth', authRouter);
  app.use('/api/admin', adminRouter);
  app.use('/api/questions', questionRouter);
  app.use('/api/exams', examRouter);
  app.use('/api/analytics', gradingAnalyticsRouter);

  // Automatic periodic DB backup every 6 hours
  const backupInterval = setInterval(() => {
    try {
      createBackupSnapshot('auto');
    } catch (err) {
      console.error('Auto backup failed:', err);
    }
  }, 6 * 60 * 60 * 1000);
  backupInterval.unref();

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  // Global error handler
  app.use(
    (
      err: any,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      console.error('Unhandled server error:', err);
      res.status(err.status || 500).json({
        error: err.message || 'Terjadi kesalahan internal pada server.',
      });
    }
  );

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EDU-TEST SMP Negeri 61 Palembang berjalan di http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
