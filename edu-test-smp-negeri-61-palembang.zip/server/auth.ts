import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { getDb } from './db.ts';
import type { Role } from '../src/types/exam.ts';

const SESSION_SECRET =
  process.env.SESSION_SECRET ||
  crypto
    .createHash('sha256')
    .update(`edutest-smpn61-${process.cwd()}`)
    .digest('hex');

const COOKIE_NAME = 'edutest_session';

export interface SessionUser {
  id: number;
  schoolId: number;
  username: string;
  email: string;
  fullName: string;
  role: Role;
  nipNisn: string;
  classId: number | null;
  className?: string;
}

export interface AuthRequest extends Request {
  authUser?: SessionUser;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derived = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derived.length) return false;
  return crypto.timingSafeEqual(keyBuf, derived);
}

export function signSessionToken(userId: number, role: Role): string {
  const exp = Date.now() + 1000 * 60 * 60 * 12; // 12h
  const payload = Buffer.from(JSON.stringify({ userId, role, exp })).toString('base64url');
  const sig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payload)
    .digest('base64url');
  return `${payload}.${sig}`;
}

export function verifySessionToken(
  token: string
): { userId: number; role: Role; exp: number } | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payload)
    .digest('base64url');
  if (sig.length !== expectedSig.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!parsed.userId || !parsed.exp || Date.now() > parsed.exp) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function parseCookieHeader(header: string | undefined): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!header) return cookies;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const val = decodeURIComponent(part.slice(idx + 1).trim());
    cookies[key] = val;
  }
  return cookies;
}

export function setSessionCookie(res: Response, token: string): void {
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 1000 * 60 * 60 * 12,
  });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(COOKIE_NAME, { path: '/' });
}

export function requireAuth(
  req: AuthRequest,
  res: Response,
  next: NextFunction
): void {
  const cookies = parseCookieHeader(req.headers.cookie);
  const bearer = req.headers.authorization?.startsWith('Bearer ')
    ? req.headers.authorization.slice(7)
    : undefined;
  const token = cookies[COOKIE_NAME] || bearer;
  if (!token) {
    res.status(401).json({ error: 'Sesi belum login. Silakan masuk terlebih dahulu.' });
    return;
  }
  const verified = verifySessionToken(token);
  if (!verified) {
    res.status(401).json({ error: 'Sesi login telah berakhir atau tidak valid.' });
    return;
  }

  const db = getDb();
  const row = db
    .prepare(
      `SELECT u.id, u.school_id, u.username, u.email, u.full_name, u.role, u.nip_nisn, u.class_id, u.is_active,
              c.name as class_name
       FROM users u
       LEFT JOIN classes c ON c.id = u.class_id
       WHERE u.id = ?`
    )
    .get(verified.userId) as
    | {
        id: number;
        school_id: number;
        username: string;
        email: string;
        full_name: string;
        role: Role;
        nip_nisn: string;
        class_id: number | null;
        is_active: number;
        class_name: string | null;
      }
    | undefined;

  if (!row || !row.is_active) {
    res.status(401).json({ error: 'Akun pengguna tidak ditemukan atau nonaktif.' });
    return;
  }

  req.authUser = {
    id: row.id,
    schoolId: row.school_id,
    username: row.username,
    email: row.email,
    fullName: row.full_name,
    role: row.role,
    nipNisn: row.nip_nisn,
    classId: row.class_id,
    className: row.class_name || undefined,
  };
  next();
}

export function requireRole(...roles: Role[]) {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.authUser) {
      res.status(401).json({ error: 'Autentikasi diperlukan.' });
      return;
    }
    if (!roles.includes(req.authUser.role)) {
      res.status(403).json({
        error: `Akses ditolak. Fitur ini khusus untuk peran: ${roles.join(', ')}.`,
      });
      return;
    }
    next();
  };
}

// Simple sliding-window rate limiter to protect auth and AI routes
const rateBuckets = new Map<string, number[]>();

export function rateLimit(maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const key = `${req.ip}:${req.path}`;
    const now = Date.now();
    const list = (rateBuckets.get(key) || []).filter((ts) => now - ts < windowMs);
    if (list.length >= maxRequests) {
      res.status(429).json({
        error: 'Terlalu banyak permintaan dalam waktu singkat. Coba lagi sebentar.',
      });
      return;
    }
    list.push(now);
    rateBuckets.set(key, list);
    next();
  };
}

export function sanitizePlainText(input: unknown): string {
  if (typeof input !== 'string') return '';
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/on\w+\s*=\s*(['"]).*?\1/gi, '')
    .trim();
}
