import { getDb, initSchema } from './db.ts';
import { hashPassword } from './auth.ts';
import { gradeObjectiveQuestion, calculateExamSummary } from '../src/utils/grading.ts';

export function seedDatabaseIfEmpty(): void {
  initSchema();
  const db = getDb();
  const countRow = db.prepare('SELECT COUNT(*) as cnt FROM schools').get() as {
    cnt: number;
  };
  if (countRow.cnt > 0) return;

  const tx = db.transaction(() => {
    // 1. School
    const schoolRes = db
      .prepare(
        `INSERT INTO schools (name, npsn, address, city, headmaster, nip_headmaster, academic_year, active_semester, header_text)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        'SMP Negeri 61 Palembang',
        '10603861',
        'Jl. Soekarno Hatta / Alang-Alang Lebar, Kota Palembang, Sumatera Selatan',
        'Palembang',
        'Drs. H. Hendra Wijaya, M.Pd.',
        '196904121995121002',
        '2025/2026',
        'Ganjil',
        'PEMERINTAH KOTA PALEMBANG · DINAS PENDIDIKAN · SMP NEGERI 61 PALEMBANG'
      );
    const schoolId = Number(schoolRes.lastInsertRowid);

    // 2. Classes (Rombel)
    const insertClass = db.prepare(
      'INSERT INTO classes (school_id, name, grade_level) VALUES (?, ?, ?)'
    );
    const classIds: Record<string, number> = {};
    for (const [name, grade] of [
      ['VII-A', 'VII'],
      ['VII-B', 'VII'],
      ['VIII-A', 'VIII'],
      ['VIII-B', 'VIII'],
      ['IX-A', 'IX'],
      ['IX-B', 'IX'],
    ]) {
      const r = insertClass.run(schoolId, name, grade);
      classIds[name] = Number(r.lastInsertRowid);
    }

    // 3. Subjects
    const insertSubject = db.prepare(
      'INSERT INTO subjects (school_id, code, name, kkm) VALUES (?, ?, ?, ?)'
    );
    const subjIds: Record<string, number> = {};
    for (const [code, name, kkm] of [
      ['MAT', 'Matematika', 75],
      ['BIND', 'Bahasa Indonesia', 75],
      ['IPA', 'Ilmu Pengetahuan Alam', 75],
      ['IPS', 'Ilmu Pengetahuan Sosial', 75],
      ['BING', 'Bahasa Inggris', 75],
    ] as const) {
      const r = insertSubject.run(schoolId, code, name, kkm);
      subjIds[code] = Number(r.lastInsertRowid);
    }

    // 4. Users (Super Admin, Admin Sekolah, Guru, Siswa)
    const insertUser = db.prepare(
      `INSERT INTO users (school_id, username, email, password_hash, full_name, role, nip_nisn, class_id, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const adminPass = hashPassword('admin123');
    const guruPass = hashPassword('guru123');
    const siswaPass = hashPassword('siswa123');

    insertUser.run(
      schoolId,
      'superadmin',
      'superadmin@smpn61palembang.sch.id',
      adminPass,
      'Administrator Platform Dinas',
      'SUPER_ADMIN',
      '198501012010011001',
      null,
      '081270001001'
    );

    const adminSekolahId = Number(
      insertUser.run(
        schoolId,
        'admin61',
        'tatausaha@smpn61palembang.sch.id',
        adminPass,
        'Dian Kusuma, S.Kom.',
        'ADMIN_SEKOLAH',
        '198807142014022003',
        null,
        '081270001002'
      ).lastInsertRowid
    );

    const guruRatnaId = Number(
      insertUser.run(
        schoolId,
        'guru.ratna',
        'ratna.sari@smpn61palembang.sch.id',
        guruPass,
        'Ratna Sari, S.Pd.',
        'GURU',
        '198403222009032005',
        classIds['IX-A'],
        '081270002001'
      ).lastInsertRowid
    );

    const guruBudiId = Number(
      insertUser.run(
        schoolId,
        'guru.budi',
        'budi.santoso@smpn61palembang.sch.id',
        guruPass,
        'Budi Santoso, M.Pd.',
        'GURU',
        '198111082008011004',
        classIds['IX-B'],
        '081270002002'
      ).lastInsertRowid
    );

    db.prepare('UPDATE classes SET homeroom_teacher_id = ? WHERE id = ?').run(
      guruRatnaId,
      classIds['IX-A']
    );
    db.prepare('UPDATE classes SET homeroom_teacher_id = ? WHERE id = ?').run(
      guruBudiId,
      classIds['IX-B']
    );

    const students = [
      ['siswa.ahmad', 'ahmad.pratama@siswa.smpn61.sch.id', 'Ahmad Pratama', '0091234501', classIds['IX-A']],
      ['siswa.putri', 'putri.amalia@siswa.smpn61.sch.id', 'Putri Amalia', '0091234502', classIds['IX-A']],
      ['siswa.rizky', 'rizky.ramadhan@siswa.smpn61.sch.id', 'Rizky Ramadhan', '0091234503', classIds['IX-A']],
      ['siswa.citra', 'citra.lestari@siswa.smpn61.sch.id', 'Citra Lestari', '0091234504', classIds['IX-B']],
      ['siswa.dewi', 'dewi.anggraini@siswa.smpn61.sch.id', 'Dewi Anggraini', '0091234505', classIds['IX-B']],
      ['siswa.fajar', 'fajar.nugroho@siswa.smpn61.sch.id', 'Fajar Nugroho', '0101234506', classIds['VIII-A']],
    ] as const;

    const studentIds: number[] = [];
    for (const [uname, email, fname, nisn, cid] of students) {
      const sid = Number(
        insertUser.run(
          schoolId,
          uname,
          email,
          siswaPass,
          fname,
          'SISWA',
          nisn,
          cid,
          ''
        ).lastInsertRowid
      );
      studentIds.push(sid);
    }

    // 5. Bank Soal AKM (All 5 types + Stimulus + Math LaTeX + SVG Diagram)
    const insertQuestion = db.prepare(
      `INSERT INTO questions (
        school_id, subject_id, created_by, grade_level, topic, difficulty, question_type,
        stimulus_title, stimulus_text, stimulus_media_json, stem, math_latex,
        options_json, correct_answer_json, matching_pairs_json, short_answer_config_json,
        rubric_json, weight, partial_scoring, pgk_mode, year
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const svgDiagram = `<svg viewBox="0 0 320 150" xmlns="http://www.w3.org/2000/svg" style="max-width:300px;background:#f8fafc;border-radius:8px;padding:8px">
      <polygon points="40,120 260,120 40,30" fill="#dbeafe" stroke="#1d4ed8" stroke-width="2.5"/>
      <rect x="40" y="104" width="16" height="16" fill="none" stroke="#1d4ed8" stroke-width="2"/>
      <text x="150" y="138" font-size="13" fill="#0f172a" text-anchor="middle">Alas = 12 cm</text>
      <text x="20" y="78" font-size="13" fill="#0f172a" text-anchor="middle" transform="rotate(-90 20 78)">Tinggi = 5 cm</text>
      <text x="165" y="65" font-size="13" fill="#1d4ed8" font-weight="bold">Sisi miring = ?</text>
    </svg>`;

    const q1Id = Number(
      insertQuestion.run(
        schoolId,
        subjIds.MAT,
        guruRatnaId,
        'IX',
        'Teorema Pythagoras & Numerasi',
        'MUDAH',
        'PG',
        'Desain Penyangga Jembatan Ampera Miniatur',
        'Sebuah tim siswa SMP Negeri 61 Palembang membuat miniatur rangka jembatan berbentuk segitiga siku-siku dengan panjang alas 12 cm dan tinggi 5 cm seperti pada diagram.',
        JSON.stringify([{ type: 'svg', caption: 'Diagram Segitiga Siku-Siku', htmlOrSvg: svgDiagram }]),
        'Berdasarkan gambar dan rumus $c = \\sqrt{a^2 + b^2}$, berapakah panjang sisi miring rangka miniatur tersebut?',
        'c = \\sqrt{12^2 + 5^2}',
        JSON.stringify([
          { key: 'A', text: '11 cm' },
          { key: 'B', text: '13 cm' },
          { key: 'C', text: '15 cm' },
          { key: 'D', text: '17 cm' },
        ]),
        JSON.stringify('B'),
        '[]',
        '{}',
        '[]',
        2,
        0,
        'ALL_OR_NOTHING',
        2026
      ).lastInsertRowid
    );

    const q2Id = Number(
      insertQuestion.run(
        schoolId,
        subjIds.MAT,
        guruRatnaId,
        'IX',
        'Statistika & Peluang AKM',
        'SEDANG',
        'PG_KOMPLEKS',
        'Data Pengunjung Perpustakaan SMP Negeri 61 Palembang',
        'Selama 5 hari kerja, jumlah siswa yang mengunjungi perpustakaan berturut-turut adalah: Senin (32 siswa), Selasa (40 siswa), Rabu (38 siswa), Kamis (45 siswa), Jumat (45 siswa).',
        '[]',
        'Pilihlah SEMUA pernyataan yang benar berdasarkan data kunjungan perpustakaan di atas (jawaban benar lebih dari satu):',
        '',
        JSON.stringify([
          { key: 'A', text: 'Rata-rata kunjungan siswa per hari adalah 40 siswa.' },
          { key: 'B', text: 'Modus data kunjungan terjadi pada hari Kamis dan Jumat.' },
          { key: 'C', text: 'Jangkauan (range) data kunjungan adalah 15 siswa.' },
          { key: 'D', text: 'Median data kunjungan adalah 38 siswa.' },
        ]),
        JSON.stringify(['A', 'B']),
        '[]',
        '{}',
        '[]',
        4,
        1,
        'PARTIAL',
        2026
      ).lastInsertRowid
    );

    const q3Id = Number(
      insertQuestion.run(
        schoolId,
        subjIds.BIND,
        guruBudiId,
        'IX',
        'Literasi Teks Informasi Sungai Musi',
        'SEDANG',
        'MENJODOHKAN',
        'Ekosistem & Budaya Sungai Musi Palembang',
        'Sungai Musi memiliki panjang sekitar 750 km yang membelah Kota Palembang menjadi kawasan Seberang Ilir dan Seberang Ulu. Di atasnya berdiri Jembatan Ampera sebagai ikon kota.',
        '[]',
        'Pasangkan unsur pada kolom kiri dengan informasi yang tepat pada kolom kanan:',
        '',
        '[]',
        '""',
        JSON.stringify([
          { id: 'p1', leftText: 'Jembatan Ampera', rightText: 'Ikon penghubung Ilir dan Ulu' },
          { id: 'p2', leftText: 'Panjang Sungai Musi', rightText: 'Sekitar 750 kilometer' },
          { id: 'p3', leftText: 'Wilayah Kota Palembang', rightText: 'Seberang Ilir dan Seberang Ulu' },
        ]),
        '{}',
        '[]',
        3,
        1,
        'ALL_OR_NOTHING',
        2026
      ).lastInsertRowid
    );

    const q4Id = Number(
      insertQuestion.run(
        schoolId,
        subjIds.MAT,
        guruRatnaId,
        'IX',
        'Aljabar & Persamaan Linear',
        'MUDAH',
        'ISIAN_SINGKAT',
        '',
        '',
        '[]',
        'Jika diketahui persamaan $3x + 6 = 21$, tuliskan nilai $x$ yang memenuhi (dalam angka):',
        '3x + 6 = 21',
        '[]',
        JSON.stringify('5'),
        '[]',
        JSON.stringify({
          acceptedAnswers: ['5', '5.0', 'x=5', 'x = 5'],
          caseSensitive: false,
          ignoreWhitespace: true,
          numericTolerance: 0,
        }),
        '[]',
        2,
        0,
        'ALL_OR_NOTHING',
        2026
      ).lastInsertRowid
    );

    const q5Id = Number(
      insertQuestion.run(
        schoolId,
        subjIds.BIND,
        guruBudiId,
        'IX',
        'Literasi Lingkungan & Penalaran',
        'SUKAR',
        'ESAI',
        'Program Sekolah Adiwiyata SMP Negeri 61 Palembang',
        'Untuk mengurangi sampah plastik sekali pakai di kantin sekolah, OSIS mengusulkan kewajiban membawa tumbler minum dan kotak makan sendiri bagi seluruh siswa.',
        '[]',
        'Jelaskan 2 dampak positif lingkungan dan 1 strategi agar seluruh siswa disiplin menjalankan program membawa tumbler tersebut!',
        '',
        '[]',
        JSON.stringify(
          'Dampak positif meliputi berkurangnya limbah plastik di sekolah dan penghematan biaya pengelolaan sampah; strategi dapat berupa lomba kelas peduli lingkungan atau penyediaan stasiun isi ulang air.'
        ),
        '[]',
        '{}',
        JSON.stringify([
          {
            id: 'r1',
            aspect: 'Menyebutkan 2 Dampak Positif Lingkungan',
            maxPoints: 3,
            description: 'Menjelaskan pengurangan sampah plastik dan kebersihan lingkungan sekolah.',
          },
          {
            id: 'r2',
            aspect: 'Strategi Implementasi yang Realistis',
            maxPoints: 2,
            description: 'Memberikan langkah konkret seperti penyediaan galon isi ulang atau poin kelas.',
          },
        ]),
        5,
        0,
        'ALL_OR_NOTHING',
        2026
      ).lastInsertRowid
    );

    // Additional bank questions for variety (IPA, IPS, BING)
    const q6Id = Number(
      insertQuestion.run(
        schoolId,
        subjIds.IPA,
        guruRatnaId,
        'IX',
        'Listrik Dinamis',
        'SEDANG',
        'PG',
        '',
        '',
        '[]',
        'Sebuah lampu memiliki hambatan $10\\ \\Omega$ dihubungkan dengan tegangan $20\\text{ V}$. Berapakah kuat arus listrik yang mengalir?',
        'I = \\frac{V}{R}',
        JSON.stringify([
          { key: 'A', text: '0,5 Ampere' },
          { key: 'B', text: '2 Ampere' },
          { key: 'C', text: '10 Ampere' },
          { key: 'D', text: '200 Ampere' },
        ]),
        JSON.stringify('B'),
        '[]',
        '{}',
        '[]',
        2,
        0,
        'ALL_OR_NOTHING',
        2026
      ).lastInsertRowid
    );

    insertQuestion.run(
      schoolId,
      subjIds.IPA,
      guruRatnaId,
      'VIII',
      'Sistem Pernapasan Manusia',
      'MUDAH',
      'PG_KOMPLEKS',
      '',
      '',
      '[]',
      'Manakah organ yang termasuk saluran pernapasan bagian atas? (Pilih lebih dari satu)',
      '',
      JSON.stringify([
        { key: 'A', text: 'Rongga Hidung' },
        { key: 'B', text: 'Faring' },
        { key: 'C', text: 'Alveolus' },
        { key: 'D', text: 'Bronkiolus' },
      ]),
      JSON.stringify(['A', 'B']),
      '[]',
      '{}',
      '[]',
      3,
      1,
      'PARTIAL',
      2026
    );

    insertQuestion.run(
      schoolId,
      subjIds.BING,
      guruBudiId,
      'IX',
      'Procedure Text',
      'MUDAH',
      'ISIAN_SINGKAT',
      '',
      '',
      '[]',
      'Complete the sentence: "First, ____ the water in a kettle until it boils."',
      '',
      '[]',
      JSON.stringify('boil'),
      '[]',
      JSON.stringify({
        acceptedAnswers: ['boil', 'heat'],
        caseSensitive: false,
        ignoreWhitespace: true,
        numericTolerance: 0,
      }),
      '[]',
      2,
      0,
      'ALL_OR_NOTHING',
      2026
    );

    // 6. Exams
    const insertExam = db.prepare(
      `INSERT INTO exams (
        school_id, title, subject_id, created_by, semester, academic_year, target_class_ids_json,
        scheduled_date, start_time, end_time, duration_minutes, max_score, passing_score, rounding_mode,
        max_attempts, allow_remedial, show_score_immediately, randomize_questions, randomize_options,
        allow_back_navigation, anti_cheat_enabled, require_fullscreen, max_violations,
        lock_on_max_violations, low_bandwidth_mode, instructions, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const todayStr = new Date().toISOString().slice(0, 10);

    // Exam 1: ACTIVE exam for Kelas IX-A & IX-B (ready for siswa.ahmad to take live)
    const activeExamId = Number(
      insertExam.run(
        schoolId,
        'Asesmen AKM Literasi & Numerasi Kelas IX',
        subjIds.MAT,
        guruRatnaId,
        'Ganjil',
        '2025/2026',
        JSON.stringify([classIds['IX-A'], classIds['IX-B']]),
        todayStr,
        '07:30',
        '16:00',
        45,
        100,
        75,
        'NEAREST',
        2,
        1,
        1,
        0,
        0,
        1,
        1,
        1,
        3,
        1,
        0,
        'Bacalah stimulus dengan saksama. Kerjakan 5 tipe soal AKM (PG, PG Kompleks, Menjodohkan, Isian Singkat, dan Esai). Jangan meninggalkan halaman ujian selama sesi berlangsung.',
        'ACTIVE'
      ).lastInsertRowid
    );

    const linkExamQuestion = db.prepare(
      'INSERT INTO exam_questions (exam_id, question_id, order_index) VALUES (?, ?, ?)'
    );
    [q1Id, q2Id, q3Id, q4Id, q5Id].forEach((qid, idx) => {
      linkExamQuestion.run(activeExamId, qid, idx + 1);
    });

    // Exam 2: Completed Exam with 5 real graded/submitted attempts for rich Analytics & Essay AI Grading!
    const completedExamId = Number(
      insertExam.run(
        schoolId,
        'Try Out Sumatif Tengah Semester IPA & Matematika IX',
        subjIds.MAT,
        guruRatnaId,
        'Ganjil',
        '2025/2026',
        JSON.stringify([classIds['IX-A'], classIds['IX-B']]),
        todayStr,
        '08:00',
        '10:00',
        60,
        100,
        75,
        'NEAREST',
        1,
        1,
        1,
        0,
        0,
        1,
        1,
        1,
        3,
        0,
        0,
        'Kerjakan soal dengan jujur dan teliti.',
        'CLOSED'
      ).lastInsertRowid
    );
    [q1Id, q2Id, q4Id, q6Id, q5Id].forEach((qid, idx) => {
      linkExamQuestion.run(completedExamId, qid, idx + 1);
    });

    // Exam 3: Upcoming Published Exam
    const upcomingExamId = Number(
      insertExam.run(
        schoolId,
        'Evaluasi Bahasa Indonesia — Teks Eksplanasi',
        subjIds.BIND,
        guruBudiId,
        'Ganjil',
        '2025/2026',
        JSON.stringify([classIds['IX-A'], classIds['IX-B'], classIds['VIII-A']]),
        '2026-11-20',
        '09:00',
        '11:00',
        60,
        100,
        75,
        'NEAREST',
        1,
        1,
        0,
        1,
        1,
        1,
        1,
        1,
        3,
        1,
        0,
        'Nilai akan diumumkan setelah pemeriksaan esai oleh guru.',
        'PUBLISHED'
      ).lastInsertRowid
    );
    [q3Id, q5Id].forEach((qid, idx) => {
      linkExamQuestion.run(upcomingExamId, qid, idx + 1);
    });

    // Seed realistic submitted attempts on completedExamId (and Putri's attempt on activeExamId too so live monitor shows data!)
    const seededSubmissions = [
      {
        studentId: studentIds[1], // Putri (IX-A) - high performer
        answers: {
          [q1Id]: 'B',
          [q2Id]: ['A', 'B'],
          [q4Id]: '5',
          [q6Id]: 'B',
          [q5Id]:
            'Penggunaan tumbler mengurangi sampah botol plastik hingga ratusan per minggu dan menekan biaya sampah sekolah. Strateginya adalah membuat poin Adiwiyata antar kelas serta menyediakan dispenser air minum gratis.',
        },
        essayManual: 5,
        violations: 0,
      },
      {
        studentId: studentIds[2], // Rizky (IX-A) - needs remedial
        answers: {
          [q1Id]: 'C',
          [q2Id]: ['A'],
          [q4Id]: '5',
          [q6Id]: 'A',
          [q5Id]: 'Supaya sekolah bersih dan tidak banyak plastik.',
        },
        essayManual: 2,
        violations: 2,
      },
      {
        studentId: studentIds[3], // Citra (IX-B) - high performer
        answers: {
          [q1Id]: 'B',
          [q2Id]: ['A', 'B'],
          [q4Id]: '5',
          [q6Id]: 'B',
          [q5Id]:
            'Dampak positifnya mengurangi limbah plastik kantin dan menjaga selokan sekolah tidak tersumbat. OSIS bisa mengadakan razia ramah lingkungan dan memberi penghargaan kelas terbersih.',
        },
        essayManual: 4.5,
        violations: 0,
      },
      {
        studentId: studentIds[4], // Dewi (IX-B) - medium, pending essay review!
        answers: {
          [q1Id]: 'B',
          [q2Id]: ['B', 'C'],
          [q4Id]: '6',
          [q6Id]: 'B',
          [q5Id]:
            'Membawa tumbler membantu lingkungan lebih bersih dari sampah plastik dan melatih siswa hidup hemat. Sekolah dapat menyiapkan stasiun isi ulang air bersih.',
        },
        essayManual: null, // Un-graded so teacher can test Essay AI Rubric Assistant immediately!
        violations: 1,
      },
      {
        studentId: studentIds[0], // Ahmad (IX-A) - completed Try Out too
        answers: {
          [q1Id]: 'B',
          [q2Id]: ['A', 'B'],
          [q4Id]: '5',
          [q6Id]: 'B',
          [q5Id]:
            'Mengurangi sampah plastik sekali pakai dan mencegah pencemaran lingkungan sekolah. Strateginya menyediakan isi ulang air dan kampanye rutin setiap Senin.',
        },
        essayManual: 4.5,
        violations: 0,
      },
    ];

    const qRows = db
      .prepare('SELECT * FROM questions WHERE id IN (?, ?, ?, ?, ?)')
      .all(q1Id, q2Id, q4Id, q6Id, q5Id) as any[];
    const qMap = new Map(qRows.map((r) => [r.id, r]));

    for (const sub of seededSubmissions) {
      const attemptRes = db
        .prepare(
          `INSERT INTO exam_attempts (exam_id, student_id, attempt_number, status, submitted_at, question_order_json, violation_count, is_flagged)
           VALUES (?, ?, 1, ?, CURRENT_TIMESTAMP, ?, ?, ?)`
        )
        .run(
          completedExamId,
          sub.studentId,
          sub.essayManual === null ? 'SUBMITTED' : 'GRADED',
          JSON.stringify([q1Id, q2Id, q4Id, q6Id, q5Id]),
          sub.violations,
          sub.violations >= 2 ? 1 : 0
        );
      const attemptId = Number(attemptRes.lastInsertRowid);

      const summaryInputs: Array<{
        earnedObjective: number;
        earnedManual: number | null;
        maxPoints: number;
        isEssay: boolean;
        isGraded: boolean;
      }> = [];

      for (const qid of [q1Id, q2Id, q4Id, q6Id, q5Id]) {
        const q = qMap.get(qid);
        const rawAns = sub.answers[qid];
        const graded = gradeObjectiveQuestion(
          {
            questionType: q.question_type,
            correctAnswer: JSON.parse(q.correct_answer_json || '""'),
            matchingPairs: JSON.parse(q.matching_pairs_json || '[]'),
            shortAnswerConfig: JSON.parse(q.short_answer_config_json || '{}'),
            weight: q.weight,
            partialScoring: Boolean(q.partial_scoring),
            pgkMode: q.pgk_mode,
          },
          rawAns
        );

        const isEssay = q.question_type === 'ESAI';
        const manualScore = isEssay ? sub.essayManual : null;
        const isGraded = !isEssay || sub.essayManual !== null;

        db.prepare(
          `INSERT INTO student_answers (attempt_id, question_id, answer_json, auto_score, manual_score, is_graded, graded_by)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        ).run(
          attemptId,
          qid,
          JSON.stringify(rawAns),
          graded.score,
          manualScore,
          isGraded ? 1 : 0,
          isEssay && sub.essayManual !== null ? guruRatnaId : null
        );

        summaryInputs.push({
          earnedObjective: graded.score,
          earnedManual: manualScore,
          maxPoints: q.weight,
          isEssay,
          isGraded,
        });
      }

      const summary = calculateExamSummary(summaryInputs, {
        maxScore: 100,
        passingScore: 75,
        roundingMode: 'NEAREST',
      });

      db.prepare(
        `UPDATE exam_attempts SET objective_score = ?, essay_score = ?, final_score = ?, passed = ? WHERE id = ?`
      ).run(
        summary.objectivePoints,
        summary.essayPoints,
        summary.normalizedScore,
        summary.passed ? 1 : 0,
        attemptId
      );

      if (sub.violations > 0) {
        for (let v = 0; v < sub.violations; v++) {
          db.prepare(
            `INSERT INTO violation_logs (attempt_id, student_id, exam_id, event_type, description)
             VALUES (?, ?, ?, ?, ?)`
          ).run(
            attemptId,
            sub.studentId,
            completedExamId,
            'TAB_SWITCH',
            'Terdeteksi berpindah tab atau keluar dari fokus jendela ujian.'
          );
        }
      }
    }

    // Seed Announcements & Notifications
    db.prepare(
      `INSERT INTO announcements (school_id, title, content, target_role, exam_id, created_by)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(
      schoolId,
      'Pelaksanaan Asesmen AKM Literasi & Numerasi Kelas IX',
      'Seluruh siswa kelas IX-A dan IX-B wajib mengikuti asesmen AKM secara daring. Gunakan browser mode layar penuh dan pastikan koneksi stabil.',
      'SISWA',
      activeExamId,
      adminSekolahId
    );

    db.prepare(
      `INSERT INTO announcements (school_id, title, content, target_role, exam_id, created_by)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(
      schoolId,
      'Panduan Smart Question Import untuk Bapak/Ibu Guru',
      'Bapak/Ibu Guru dapat langsung mengunggah file soal berformat .docx, .pdf, atau hasil scan tanpa mengubah format dokumen.',
      'GURU',
      null,
      adminSekolahId
    );

    for (const sid of studentIds) {
      db.prepare(
        `INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)`
      ).run(
        sid,
        'Ujian Aktif Tersedia',
        'Asesmen AKM Literasi & Numerasi Kelas IX telah dibuka. Silakan periksa jadwal dan kartu peserta Anda.'
      );
    }
  });

  tx();
}
