import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
export const UPLOAD_ARCHIVE_DIR = path.resolve(process.cwd(), 'uploads', 'archive');
export const DB_PATH = path.join(DATA_DIR, 'edutest.db');

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(BACKUP_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_ARCHIVE_DIR, { recursive: true });

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!_db) {
    _db = new Database(DB_PATH);
    _db.pragma('journal_mode = WAL');
    _db.pragma('foreign_keys = ON');
    _db.pragma('busy_timeout = 5000');
  }
  return _db;
}

export function initSchema(): void {
  const db = getDb();
  db.exec(`
    CREATE TABLE IF NOT EXISTS schools (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      npsn TEXT NOT NULL,
      address TEXT NOT NULL,
      city TEXT NOT NULL,
      headmaster TEXT NOT NULL,
      nip_headmaster TEXT NOT NULL,
      academic_year TEXT NOT NULL,
      active_semester TEXT NOT NULL,
      header_text TEXT NOT NULL,
      logo_url TEXT DEFAULT '',
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS classes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      school_id INTEGER NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      grade_level TEXT NOT NULL,
      homeroom_teacher_id INTEGER
    );

    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      school_id INTEGER NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      kkm INTEGER NOT NULL DEFAULT 75
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      school_id INTEGER NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('SUPER_ADMIN','ADMIN_SEKOLAH','GURU','SISWA')),
      nip_nisn TEXT NOT NULL DEFAULT '',
      class_id INTEGER REFERENCES classes(id) ON DELETE SET NULL,
      phone TEXT DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS uploaded_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uploaded_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      original_filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_size INTEGER NOT NULL,
      stored_path TEXT NOT NULL,
      extracted_text TEXT NOT NULL DEFAULT '',
      extraction_method TEXT NOT NULL DEFAULT 'HEURISTIC',
      total_detected INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      school_id INTEGER NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      created_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      source_document_id INTEGER REFERENCES uploaded_documents(id) ON DELETE SET NULL,
      grade_level TEXT NOT NULL DEFAULT 'IX',
      topic TEXT NOT NULL DEFAULT 'Umum',
      difficulty TEXT NOT NULL DEFAULT 'SEDANG',
      question_type TEXT NOT NULL CHECK(question_type IN ('PG','PG_KOMPLEKS','MENJODOHKAN','ISIAN_SINGKAT','ESAI')),
      stimulus_title TEXT DEFAULT '',
      stimulus_text TEXT DEFAULT '',
      stimulus_media_json TEXT NOT NULL DEFAULT '[]',
      stem TEXT NOT NULL,
      math_latex TEXT DEFAULT '',
      options_json TEXT NOT NULL DEFAULT '[]',
      correct_answer_json TEXT NOT NULL DEFAULT '""',
      matching_pairs_json TEXT NOT NULL DEFAULT '[]',
      short_answer_config_json TEXT NOT NULL DEFAULT '{}',
      rubric_json TEXT NOT NULL DEFAULT '[]',
      weight REAL NOT NULL DEFAULT 2,
      partial_scoring INTEGER NOT NULL DEFAULT 0,
      pgk_mode TEXT NOT NULL DEFAULT 'ALL_OR_NOTHING',
      warnings_json TEXT NOT NULL DEFAULT '[]',
      year INTEGER NOT NULL DEFAULT 2026,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS exams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      school_id INTEGER NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      created_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      semester TEXT NOT NULL DEFAULT 'Ganjil',
      academic_year TEXT NOT NULL DEFAULT '2025/2026',
      target_class_ids_json TEXT NOT NULL DEFAULT '[]',
      scheduled_date TEXT NOT NULL,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      duration_minutes INTEGER NOT NULL DEFAULT 60,
      max_score REAL NOT NULL DEFAULT 100,
      passing_score REAL NOT NULL DEFAULT 75,
      rounding_mode TEXT NOT NULL DEFAULT 'NEAREST',
      max_attempts INTEGER NOT NULL DEFAULT 1,
      allow_remedial INTEGER NOT NULL DEFAULT 1,
      show_score_immediately INTEGER NOT NULL DEFAULT 1,
      randomize_questions INTEGER NOT NULL DEFAULT 0,
      randomize_options INTEGER NOT NULL DEFAULT 0,
      allow_back_navigation INTEGER NOT NULL DEFAULT 1,
      anti_cheat_enabled INTEGER NOT NULL DEFAULT 1,
      require_fullscreen INTEGER NOT NULL DEFAULT 1,
      max_violations INTEGER NOT NULL DEFAULT 3,
      lock_on_max_violations INTEGER NOT NULL DEFAULT 1,
      low_bandwidth_mode INTEGER NOT NULL DEFAULT 0,
      instructions TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','PUBLISHED','ACTIVE','CLOSED')),
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS exam_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
      order_index INTEGER NOT NULL DEFAULT 0,
      weight_override REAL
    );

    CREATE TABLE IF NOT EXISTS exam_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      attempt_number INTEGER NOT NULL DEFAULT 1,
      is_remedial INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'IN_PROGRESS' CHECK(status IN ('IN_PROGRESS','LOCKED','SUBMITTED','GRADED')),
      started_at TEXT DEFAULT CURRENT_TIMESTAMP,
      submitted_at TEXT,
      last_heartbeat_at TEXT DEFAULT CURRENT_TIMESTAMP,
      question_order_json TEXT NOT NULL DEFAULT '[]',
      option_orders_json TEXT NOT NULL DEFAULT '{}',
      objective_score REAL NOT NULL DEFAULT 0,
      essay_score REAL NOT NULL DEFAULT 0,
      final_score REAL NOT NULL DEFAULT 0,
      passed INTEGER NOT NULL DEFAULT 0,
      violation_count INTEGER NOT NULL DEFAULT 0,
      is_flagged INTEGER NOT NULL DEFAULT 0,
      is_locked INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS student_answers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      attempt_id INTEGER NOT NULL REFERENCES exam_attempts(id) ON DELETE CASCADE,
      question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
      answer_json TEXT NOT NULL DEFAULT '""',
      is_flagged_review INTEGER NOT NULL DEFAULT 0,
      auto_score REAL NOT NULL DEFAULT 0,
      manual_score REAL,
      ai_recommended_score REAL,
      ai_feedback TEXT DEFAULT '',
      ai_rubric_breakdown_json TEXT NOT NULL DEFAULT '[]',
      is_graded INTEGER NOT NULL DEFAULT 0,
      graded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(attempt_id, question_id)
    );

    CREATE TABLE IF NOT EXISTS violation_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      attempt_id INTEGER NOT NULL REFERENCES exam_attempts(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      event_type TEXT NOT NULL,
      description TEXT NOT NULL,
      occurred_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      school_id INTEGER NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      target_role TEXT NOT NULL DEFAULT 'ALL',
      exam_id INTEGER REFERENCES exams(id) ON DELETE SET NULL,
      created_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT DEFAULT '',
      details TEXT DEFAULT '',
      ip_address TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
}

export function logAudit(
  userId: number | null,
  action: string,
  entityType: string,
  entityId: string | number = '',
  details = '',
  ipAddress = ''
): void {
  try {
    const db = getDb();
    db.prepare(
      `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(userId, action, entityType, String(entityId), details, ipAddress);
  } catch (err) {
    console.error('Audit log error:', err);
  }
}

export function createBackupSnapshot(reason = 'manual'): {
  filename: string;
  filepath: string;
  size: number;
  createdAt: string;
} {
  const db = getDb();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `edutest-backup-${reason}-${stamp}.db`;
  const filepath = path.join(BACKUP_DIR, filename);
  db.pragma('wal_checkpoint(FULL)');
  fs.copyFileSync(DB_PATH, filepath);
  const stat = fs.statSync(filepath);
  return {
    filename,
    filepath,
    size: stat.size,
    createdAt: new Date().toISOString(),
  };
}

export function listBackups(): Array<{
  filename: string;
  size: number;
  createdAt: string;
}> {
  if (!fs.existsSync(BACKUP_DIR)) return [];
  return fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.endsWith('.db'))
    .map((f) => {
      const st = fs.statSync(path.join(BACKUP_DIR, f));
      return {
        filename: f,
        size: st.size,
        createdAt: st.mtime.toISOString(),
      };
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function restoreBackupFromBuffer(buffer: Buffer): void {
  if (buffer.subarray(0, 15).toString('utf8') !== 'SQLite format 3') {
    throw new Error('File backup tidak valid (bukan format database SQLite3).');
  }
  if (_db) {
    _db.close();
    _db = null;
  }
  const tmpPath = `${DB_PATH}.restore-tmp`;
  fs.writeFileSync(tmpPath, buffer);
  // Remove WAL/SHM files before replacing
  for (const suffix of ['-wal', '-shm']) {
    if (fs.existsSync(DB_PATH + suffix)) fs.unlinkSync(DB_PATH + suffix);
  }
  fs.renameSync(tmpPath, DB_PATH);
  getDb();
}
