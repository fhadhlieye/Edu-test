import { Router } from 'express';
import { getDb, logAudit } from '../db.ts';
import {
  requireAuth,
  requireRole,
  sanitizePlainText,
  type AuthRequest,
} from '../auth.ts';
import {
  calculateExamSummary,
  gradeObjectiveQuestion,
} from '../../src/utils/grading.ts';

export const examRouter = Router();

function shuffleArray<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function serializeExam(row: any, classMap: Map<number, string>) {
  const targetClassIds: number[] = JSON.parse(row.target_class_ids_json || '[]');
  return {
    id: row.id,
    schoolId: row.school_id,
    title: row.title,
    subjectId: row.subject_id,
    subjectName: row.subject_name,
    createdBy: row.created_by,
    creatorName: row.creator_name,
    semester: row.semester,
    academicYear: row.academic_year,
    targetClassIds,
    targetClassNames: targetClassIds.map((cid) => classMap.get(cid) || `Kelas #${cid}`),
    scheduledDate: row.scheduled_date,
    startTime: row.start_time,
    endTime: row.end_time,
    durationMinutes: row.duration_minutes,
    maxScore: row.max_score,
    passingScore: row.passing_score,
    roundingMode: row.rounding_mode,
    maxAttempts: row.max_attempts,
    allowRemedial: Boolean(row.allow_remedial),
    showScoreImmediately: Boolean(row.show_score_immediately),
    randomizeQuestions: Boolean(row.randomize_questions),
    randomizeOptions: Boolean(row.randomize_options),
    allowBackNavigation: Boolean(row.allow_back_navigation),
    antiCheatEnabled: Boolean(row.anti_cheat_enabled),
    requireFullscreen: Boolean(row.require_fullscreen),
    maxViolations: row.max_violations,
    lockOnMaxViolations: Boolean(row.lock_on_max_violations),
    lowBandwidthMode: Boolean(row.low_bandwidth_mode),
    instructions: row.instructions,
    status: row.status,
    questionCount: row.question_count ?? 0,
    attemptCount: row.attempt_count ?? 0,
    createdAt: row.created_at,
  };
}

// List exams (Teacher/Admin sees all school exams; Student sees exams targeted to their class)
examRouter.get('/', requireAuth, (req: AuthRequest, res) => {
  const db = getDb();
  const classes = db
    .prepare('SELECT id, name FROM classes WHERE school_id = ?')
    .all(req.authUser!.schoolId) as Array<{ id: number; name: string }>;
  const classMap = new Map(classes.map((c) => [c.id, c.name]));

  const rows = db
    .prepare(
      `SELECT e.*, s.name as subject_name, u.full_name as creator_name,
              (SELECT COUNT(*) FROM exam_questions eq WHERE eq.exam_id = e.id) as question_count,
              (SELECT COUNT(*) FROM exam_attempts ea WHERE ea.exam_id = e.id) as attempt_count
       FROM exams e
       JOIN subjects s ON s.id = e.subject_id
       JOIN users u ON u.id = e.created_by
       WHERE e.school_id = ?
       ORDER BY e.id DESC`
    )
    .all(req.authUser!.schoolId) as any[];

  let exams = rows.map((r) => serializeExam(r, classMap));

  if (req.authUser!.role === 'SISWA') {
    const studentClassId = req.authUser!.classId;
    exams = exams
      .filter(
        (ex) =>
          ex.status !== 'DRAFT' &&
          (ex.targetClassIds.length === 0 ||
            (studentClassId !== null && ex.targetClassIds.includes(studentClassId)))
      )
      .map((ex) => {
        const attempts = db
          .prepare(
            `SELECT id, attempt_number, is_remedial, status, started_at, submitted_at, final_score, passed, violation_count, is_locked
             FROM exam_attempts
             WHERE exam_id = ? AND student_id = ?
             ORDER BY attempt_number DESC`
          )
          .all(ex.id, req.authUser!.id) as any[];
        const latest = attempts[0] || null;
        return {
          ...ex,
          myAttempts: attempts,
          myLatestAttempt: latest
            ? {
                ...latest,
                finalScore:
                  ex.showScoreImmediately || latest.status === 'GRADED'
                    ? latest.final_score
                    : null,
              }
            : null,
        };
      });
  }

  res.json({ exams });
});

// Get exam detail + attached questions (Teacher/Admin)
examRouter.get(
  '/:id/detail',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const row = db
      .prepare(
        `SELECT e.*, s.name as subject_name, u.full_name as creator_name
         FROM exams e
         JOIN subjects s ON s.id = e.subject_id
         JOIN users u ON u.id = e.created_by
         WHERE e.id = ? AND e.school_id = ?`
      )
      .get(Number(req.params.id), req.authUser!.schoolId) as any;
    if (!row) {
      res.status(404).json({ error: 'Ujian tidak ditemukan.' });
      return;
    }

    const classes = db
      .prepare('SELECT id, name FROM classes WHERE school_id = ?')
      .all(req.authUser!.schoolId) as Array<{ id: number; name: string }>;
    const classMap = new Map(classes.map((c) => [c.id, c.name]));

    const questions = db
      .prepare(
        `SELECT eq.order_index, eq.weight_override, q.*
         FROM exam_questions eq
         JOIN questions q ON q.id = eq.question_id
         WHERE eq.exam_id = ?
         ORDER BY eq.order_index ASC`
      )
      .all(row.id) as any[];

    res.json({
      exam: serializeExam(row, classMap),
      questions: questions.map((q) => ({
        id: q.id,
        orderIndex: q.order_index,
        questionType: q.question_type,
        stem: q.stem,
        topic: q.topic,
        difficulty: q.difficulty,
        weight: q.weight_override ?? q.weight,
        options: JSON.parse(q.options_json || '[]'),
        correctAnswer: JSON.parse(q.correct_answer_json || '""'),
        matchingPairs: JSON.parse(q.matching_pairs_json || '[]'),
        shortAnswerConfig: JSON.parse(q.short_answer_config_json || '{}'),
        rubric: JSON.parse(q.rubric_json || '[]'),
      })),
    });
  }
);

// Create exam
examRouter.post(
  '/',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const b = req.body || {};
    if (!b.title || !b.subjectId) {
      res.status(400).json({ error: 'Nama ujian dan mata pelajaran wajib diisi.' });
      return;
    }
    const db = getDb();
    const info = db
      .prepare(
        `INSERT INTO exams (
          school_id, title, subject_id, created_by, semester, academic_year, target_class_ids_json,
          scheduled_date, start_time, end_time, duration_minutes, max_score, passing_score, rounding_mode,
          max_attempts, allow_remedial, show_score_immediately, randomize_questions, randomize_options,
          allow_back_navigation, anti_cheat_enabled, require_fullscreen, max_violations,
          lock_on_max_violations, low_bandwidth_mode, instructions, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        req.authUser!.schoolId,
        sanitizePlainText(b.title),
        Number(b.subjectId),
        req.authUser!.id,
        sanitizePlainText(b.semester || 'Ganjil'),
        sanitizePlainText(b.academicYear || '2025/2026'),
        JSON.stringify(Array.isArray(b.targetClassIds) ? b.targetClassIds.map(Number) : []),
        sanitizePlainText(b.scheduledDate || new Date().toISOString().slice(0, 10)),
        sanitizePlainText(b.startTime || '07:30'),
        sanitizePlainText(b.endTime || '16:00'),
        Number(b.durationMinutes) || 60,
        Number(b.maxScore) || 100,
        Number(b.passingScore) || 75,
        b.roundingMode || 'NEAREST',
        Number(b.maxAttempts) || 1,
        b.allowRemedial !== false ? 1 : 0,
        b.showScoreImmediately !== false ? 1 : 0,
        b.randomizeQuestions ? 1 : 0,
        b.randomizeOptions ? 1 : 0,
        b.allowBackNavigation !== false ? 1 : 0,
        b.antiCheatEnabled !== false ? 1 : 0,
        b.requireFullscreen !== false ? 1 : 0,
        Number(b.maxViolations) || 3,
        b.lockOnMaxViolations !== false ? 1 : 0,
        b.lowBandwidthMode ? 1 : 0,
        String(b.instructions || ''),
        b.status || 'PUBLISHED'
      );

    const examId = Number(info.lastInsertRowid);
    if (Array.isArray(b.questionIds) && b.questionIds.length > 0) {
      const linkStmt = db.prepare(
        'INSERT INTO exam_questions (exam_id, question_id, order_index) VALUES (?, ?, ?)'
      );
      b.questionIds.forEach((qid: number, idx: number) => {
        linkStmt.run(examId, Number(qid), idx + 1);
      });
    }

    logAudit(req.authUser!.id, 'CREATE_EXAM', 'exam', examId, sanitizePlainText(b.title), req.ip);
    res.json({ id: examId });
  }
);

// Update exam config & question list
examRouter.put(
  '/:id',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const examId = Number(req.params.id);
    const b = req.body || {};
    const db = getDb();

    db.prepare(
      `UPDATE exams SET
        title = ?, subject_id = ?, semester = ?, academic_year = ?, target_class_ids_json = ?,
        scheduled_date = ?, start_time = ?, end_time = ?, duration_minutes = ?,
        max_score = ?, passing_score = ?, rounding_mode = ?, max_attempts = ?, allow_remedial = ?,
        show_score_immediately = ?, randomize_questions = ?, randomize_options = ?,
        allow_back_navigation = ?, anti_cheat_enabled = ?, require_fullscreen = ?,
        max_violations = ?, lock_on_max_violations = ?, low_bandwidth_mode = ?, instructions = ?, status = ?
       WHERE id = ? AND school_id = ?`
    ).run(
      sanitizePlainText(b.title),
      Number(b.subjectId),
      sanitizePlainText(b.semester || 'Ganjil'),
      sanitizePlainText(b.academicYear || '2025/2026'),
      JSON.stringify(Array.isArray(b.targetClassIds) ? b.targetClassIds.map(Number) : []),
      sanitizePlainText(b.scheduledDate),
      sanitizePlainText(b.startTime),
      sanitizePlainText(b.endTime),
      Number(b.durationMinutes) || 60,
      Number(b.maxScore) || 100,
      Number(b.passingScore) || 75,
      b.roundingMode || 'NEAREST',
      Number(b.maxAttempts) || 1,
      b.allowRemedial ? 1 : 0,
      b.showScoreImmediately ? 1 : 0,
      b.randomizeQuestions ? 1 : 0,
      b.randomizeOptions ? 1 : 0,
      b.allowBackNavigation ? 1 : 0,
      b.antiCheatEnabled ? 1 : 0,
      b.requireFullscreen ? 1 : 0,
      Number(b.maxViolations) || 3,
      b.lockOnMaxViolations ? 1 : 0,
      b.lowBandwidthMode ? 1 : 0,
      String(b.instructions || ''),
      b.status || 'PUBLISHED',
      examId,
      req.authUser!.schoolId
    );

    if (Array.isArray(b.questionIds)) {
      const tx = db.transaction(() => {
        db.prepare('DELETE FROM exam_questions WHERE exam_id = ?').run(examId);
        const ins = db.prepare(
          'INSERT INTO exam_questions (exam_id, question_id, order_index) VALUES (?, ?, ?)'
        );
        b.questionIds.forEach((qid: number, idx: number) => {
          ins.run(examId, Number(qid), idx + 1);
        });
      });
      tx();
    }

    res.json({ ok: true });
  }
);

// Update exam status (DRAFT / PUBLISHED / ACTIVE / CLOSED)
examRouter.patch(
  '/:id/status',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const status = String(req.body?.status || '').toUpperCase();
    if (!['DRAFT', 'PUBLISHED', 'ACTIVE', 'CLOSED'].includes(status)) {
      res.status(400).json({ error: 'Status ujian tidak valid.' });
      return;
    }
    const db = getDb();
    db.prepare('UPDATE exams SET status = ? WHERE id = ? AND school_id = ?').run(
      status,
      Number(req.params.id),
      req.authUser!.schoolId
    );
    logAudit(req.authUser!.id, 'UPDATE_EXAM_STATUS', 'exam', req.params.id, `Status -> ${status}`, req.ip);
    res.json({ ok: true, status });
  }
);

// Duplicate exam
examRouter.post(
  '/:id/duplicate',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const orig = db
      .prepare('SELECT * FROM exams WHERE id = ? AND school_id = ?')
      .get(Number(req.params.id), req.authUser!.schoolId) as any;
    if (!orig) {
      res.status(404).json({ error: 'Ujian tidak ditemukan.' });
      return;
    }
    const info = db
      .prepare(
        `INSERT INTO exams (
          school_id, title, subject_id, created_by, semester, academic_year, target_class_ids_json,
          scheduled_date, start_time, end_time, duration_minutes, max_score, passing_score, rounding_mode,
          max_attempts, allow_remedial, show_score_immediately, randomize_questions, randomize_options,
          allow_back_navigation, anti_cheat_enabled, require_fullscreen, max_violations,
          lock_on_max_violations, low_bandwidth_mode, instructions, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT')`
      )
      .run(
        orig.school_id,
        `${orig.title} (Salinan)`,
        orig.subject_id,
        req.authUser!.id,
        orig.semester,
        orig.academic_year,
        orig.target_class_ids_json,
        orig.scheduled_date,
        orig.start_time,
        orig.end_time,
        orig.duration_minutes,
        orig.max_score,
        orig.passing_score,
        orig.rounding_mode,
        orig.max_attempts,
        orig.allow_remedial,
        orig.show_score_immediately,
        orig.randomize_questions,
        orig.randomize_options,
        orig.allow_back_navigation,
        orig.anti_cheat_enabled,
        orig.require_fullscreen,
        orig.max_violations,
        orig.lock_on_max_violations,
        orig.low_bandwidth_mode,
        orig.instructions
      );
    const newId = Number(info.lastInsertRowid);
    const eqs = db
      .prepare('SELECT question_id, order_index, weight_override FROM exam_questions WHERE exam_id = ?')
      .all(orig.id) as any[];
    const ins = db.prepare(
      'INSERT INTO exam_questions (exam_id, question_id, order_index, weight_override) VALUES (?, ?, ?, ?)'
    );
    for (const eq of eqs) {
      ins.run(newId, eq.question_id, eq.order_index, eq.weight_override);
    }
    res.json({ id: newId });
  }
);

// STUDENT: Start or resume exam attempt
examRouter.post(
  '/:id/start',
  requireAuth,
  requireRole('SISWA'),
  (req: AuthRequest, res) => {
    const examId = Number(req.params.id);
    const studentId = req.authUser!.id;
    const db = getDb();

    const exam = db
      .prepare(
        `SELECT e.*, s.name as subject_name
         FROM exams e
         JOIN subjects s ON s.id = e.subject_id
         WHERE e.id = ? AND e.school_id = ?`
      )
      .get(examId, req.authUser!.schoolId) as any;

    if (!exam) {
      res.status(404).json({ error: 'Ujian tidak ditemukan.' });
      return;
    }
    if (exam.status !== 'ACTIVE' && exam.status !== 'PUBLISHED') {
      res.status(400).json({ error: 'Ujian belum dibuka atau sudah ditutup.' });
      return;
    }

    // Check existing active/locked attempt
    let attempt = db
      .prepare(
        `SELECT * FROM exam_attempts
         WHERE exam_id = ? AND student_id = ? AND status IN ('IN_PROGRESS', 'LOCKED')
         ORDER BY attempt_number DESC LIMIT 1`
      )
      .get(examId, studentId) as any;

    const eqRows = db
      .prepare(
        `SELECT q.*, eq.order_index, eq.weight_override
         FROM exam_questions eq
         JOIN questions q ON q.id = eq.question_id
         WHERE eq.exam_id = ?
         ORDER BY eq.order_index ASC`
      )
      .all(examId) as any[];

    if (eqRows.length === 0) {
      res.status(400).json({ error: 'Ujian ini belum memiliki butir soal.' });
      return;
    }

    if (!attempt) {
      const prevCountRow = db
        .prepare('SELECT COUNT(*) as cnt FROM exam_attempts WHERE exam_id = ? AND student_id = ?')
        .get(examId, studentId) as { cnt: number };

      if (prevCountRow.cnt >= exam.max_attempts) {
        res.status(403).json({
          error: `Batas maksimal percobaan ujian (${exam.max_attempts}x) telah tercapai.`,
        });
        return;
      }

      const rawQIds = eqRows.map((q) => q.id);
      const qOrder = exam.randomize_questions ? shuffleArray(rawQIds) : rawQIds;
      const optionOrders: Record<string, string[]> = {};
      if (exam.randomize_options) {
        for (const q of eqRows) {
          const opts = JSON.parse(q.options_json || '[]') as Array<{ key: string }>;
          if (opts.length > 0) {
            optionOrders[String(q.id)] = shuffleArray(opts.map((o) => o.key));
          }
        }
      }

      const ins = db
        .prepare(
          `INSERT INTO exam_attempts (exam_id, student_id, attempt_number, is_remedial, status, question_order_json, option_orders_json)
           VALUES (?, ?, ?, ?, 'IN_PROGRESS', ?, ?)`
        )
        .run(
          examId,
          studentId,
          prevCountRow.cnt + 1,
          prevCountRow.cnt > 0 ? 1 : 0,
          JSON.stringify(qOrder),
          JSON.stringify(optionOrders)
        );
      attempt = db
        .prepare('SELECT * FROM exam_attempts WHERE id = ?')
        .get(Number(ins.lastInsertRowid));
    }

    const qOrder: number[] = JSON.parse(attempt.question_order_json || '[]');
    const optionOrders: Record<string, string[]> = JSON.parse(
      attempt.option_orders_json || '{}'
    );
    const qMap = new Map(eqRows.map((q) => [q.id, q]));

    // Saved answers
    const savedRows = db
      .prepare('SELECT * FROM student_answers WHERE attempt_id = ?')
      .all(attempt.id) as any[];
    const savedMap = new Map(
      savedRows.map((s) => [
        s.question_id,
        {
          answer: JSON.parse(s.answer_json || '""'),
          isFlaggedReview: Boolean(s.is_flagged_review),
        },
      ])
    );

    const orderedQuestions = qOrder
      .map((qid) => qMap.get(qid))
      .filter(Boolean)
      .map((q, idx) => {
        const rawOpts = JSON.parse(q.options_json || '[]') as Array<{
          key: string;
          text: string;
          imageUrl?: string;
        }>;
        const ordKeys = optionOrders[String(q.id)];
        const opts = ordKeys
          ? ordKeys
              .map((k) => rawOpts.find((o) => o.key === k))
              .filter(Boolean)
          : rawOpts;

        const matchingPairs = JSON.parse(q.matching_pairs_json || '[]') as Array<{
          id: string;
          leftText: string;
          rightText: string;
        }>;
        const shuffledRightChoices = shuffleArray(
          matchingPairs.map((p) => p.rightText)
        );

        return {
          id: q.id,
          number: idx + 1,
          questionType: q.question_type,
          stimulusTitle: q.stimulus_title || '',
          stimulusText: q.stimulus_text || '',
          stimulusMedia: exam.low_bandwidth_mode
            ? []
            : JSON.parse(q.stimulus_media_json || '[]'),
          stem: q.stem,
          mathLatex: q.math_latex || '',
          options: opts,
          matchingLeft: matchingPairs.map((p) => ({ id: p.id, leftText: p.leftText })),
          matchingRightChoices: shuffledRightChoices,
          weight: q.weight_override ?? q.weight,
          savedAnswer: savedMap.get(q.id)?.answer ?? null,
          isFlaggedReview: savedMap.get(q.id)?.isFlaggedReview ?? false,
        };
      });

    // Calculate remaining seconds from started_at
    const startedMs = new Date(attempt.started_at + 'Z').getTime();
    const elapsedSec = Number.isFinite(startedMs)
      ? Math.max(0, Math.floor((Date.now() - startedMs) / 1000))
      : 0;
    const remainingSeconds = Math.max(
      0,
      exam.duration_minutes * 60 - elapsedSec
    );

    res.json({
      attempt: {
        id: attempt.id,
        examId: attempt.exam_id,
        attemptNumber: attempt.attempt_number,
        status: attempt.status,
        startedAt: attempt.started_at,
        violationCount: attempt.violation_count,
        isLocked: Boolean(attempt.is_locked),
        remainingSeconds,
      },
      exam: {
        id: exam.id,
        title: exam.title,
        subjectName: exam.subject_name,
        durationMinutes: exam.duration_minutes,
        instructions: exam.instructions,
        allowBackNavigation: Boolean(exam.allow_back_navigation),
        antiCheatEnabled: Boolean(exam.anti_cheat_enabled),
        requireFullscreen: Boolean(exam.require_fullscreen),
        maxViolations: exam.max_violations,
        lockOnMaxViolations: Boolean(exam.lock_on_max_violations),
        lowBandwidthMode: Boolean(exam.low_bandwidth_mode),
        showScoreImmediately: Boolean(exam.show_score_immediately),
      },
      questions: orderedQuestions,
    });
  }
);

// STUDENT: Autosave answers (supports single or batch offline-sync queue)
examRouter.post(
  '/attempts/:attemptId/autosave',
  requireAuth,
  requireRole('SISWA'),
  (req: AuthRequest, res) => {
    const attemptId = Number(req.params.attemptId);
    const db = getDb();
    const attempt = db
      .prepare('SELECT * FROM exam_attempts WHERE id = ? AND student_id = ?')
      .get(attemptId, req.authUser!.id) as any;

    if (!attempt) {
      res.status(404).json({ error: 'Sesi ujian tidak ditemukan.' });
      return;
    }
    if (attempt.status === 'SUBMITTED' || attempt.status === 'GRADED') {
      res.status(400).json({ error: 'Ujian sudah dikumpulkan.' });
      return;
    }
    if (attempt.is_locked) {
      res.status(423).json({
        error: 'Sesi ujian dikunci sementara oleh pengawas karena pelanggaran berulang.',
        isLocked: true,
      });
      return;
    }

    const items = Array.isArray(req.body?.answers)
      ? req.body.answers
      : req.body?.questionId
        ? [
            {
              questionId: req.body.questionId,
              answer: req.body.answer,
              isFlaggedReview: req.body.isFlaggedReview,
            },
          ]
        : [];

    const upsert = db.prepare(
      `INSERT INTO student_answers (attempt_id, question_id, answer_json, is_flagged_review, updated_at)
       VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
       ON CONFLICT(attempt_id, question_id) DO UPDATE SET
         answer_json = excluded.answer_json,
         is_flagged_review = excluded.is_flagged_review,
         updated_at = CURRENT_TIMESTAMP`
    );

    const tx = db.transaction(() => {
      for (const it of items) {
        if (!it.questionId) continue;
        upsert.run(
          attemptId,
          Number(it.questionId),
          JSON.stringify(it.answer ?? ''),
          it.isFlaggedReview ? 1 : 0
        );
      }
      db.prepare(
        'UPDATE exam_attempts SET last_heartbeat_at = CURRENT_TIMESTAMP WHERE id = ?'
      ).run(attemptId);
    });
    tx();

    res.json({ ok: true, savedCount: items.length, syncedAt: new Date().toISOString() });
  }
);

// STUDENT: Log Anti-Cheat Violation
examRouter.post(
  '/attempts/:attemptId/violation',
  requireAuth,
  requireRole('SISWA'),
  (req: AuthRequest, res) => {
    const attemptId = Number(req.params.attemptId);
    const eventType = sanitizePlainText(req.body?.eventType || 'TAB_SWITCH');
    const description = sanitizePlainText(
      req.body?.description || 'Siswa terdeteksi meninggalkan halaman ujian.'
    );
    const db = getDb();

    const attempt = db
      .prepare(
        `SELECT a.*, e.max_violations, e.lock_on_max_violations, e.anti_cheat_enabled
         FROM exam_attempts a
         JOIN exams e ON e.id = a.exam_id
         WHERE a.id = ? AND a.student_id = ?`
      )
      .get(attemptId, req.authUser!.id) as any;

    if (!attempt || attempt.status === 'SUBMITTED' || attempt.status === 'GRADED') {
      res.json({ ok: true, ignored: true });
      return;
    }

    const nextCount = attempt.violation_count + 1;
    const isFlagged = nextCount >= Math.max(2, attempt.max_violations - 1) ? 1 : 0;
    const shouldLock =
      attempt.lock_on_max_violations && nextCount >= attempt.max_violations ? 1 : 0;

    const tx = db.transaction(() => {
      db.prepare(
        `INSERT INTO violation_logs (attempt_id, student_id, exam_id, event_type, description)
         VALUES (?, ?, ?, ?, ?)`
      ).run(attemptId, req.authUser!.id, attempt.exam_id, eventType, description);

      db.prepare(
        `UPDATE exam_attempts
         SET violation_count = ?, is_flagged = ?, is_locked = ?, status = ?
         WHERE id = ?`
      ).run(
        nextCount,
        isFlagged,
        shouldLock,
        shouldLock ? 'LOCKED' : attempt.status,
        attemptId
      );
    });
    tx();

    res.json({
      violationCount: nextCount,
      maxViolations: attempt.max_violations,
      isFlagged: Boolean(isFlagged),
      isLocked: Boolean(shouldLock),
    });
  }
);

// STUDENT: Check attempt status (used when locked to see if teacher unlocked it)
examRouter.get(
  '/attempts/:attemptId/status',
  requireAuth,
  requireRole('SISWA'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const row = db
      .prepare(
        'SELECT id, status, violation_count, is_locked, is_flagged FROM exam_attempts WHERE id = ? AND student_id = ?'
      )
      .get(Number(req.params.attemptId), req.authUser!.id);
    res.json({ attempt: row });
  }
);

// STUDENT: Submit Exam -> Automatic Grading for Objective AKM Items
examRouter.post(
  '/attempts/:attemptId/submit',
  requireAuth,
  requireRole('SISWA'),
  (req: AuthRequest, res) => {
    const attemptId = Number(req.params.attemptId);
    const db = getDb();
    const attempt = db
      .prepare('SELECT * FROM exam_attempts WHERE id = ? AND student_id = ?')
      .get(attemptId, req.authUser!.id) as any;

    if (!attempt) {
      res.status(404).json({ error: 'Sesi ujian tidak ditemukan.' });
      return;
    }

    const exam = db
      .prepare('SELECT * FROM exams WHERE id = ?')
      .get(attempt.exam_id) as any;

    // Persist any final answers included in submit body
    if (Array.isArray(req.body?.answers)) {
      const upsert = db.prepare(
        `INSERT INTO student_answers (attempt_id, question_id, answer_json, is_flagged_review, updated_at)
         VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
         ON CONFLICT(attempt_id, question_id) DO UPDATE SET
           answer_json = excluded.answer_json,
           is_flagged_review = excluded.is_flagged_review,
           updated_at = CURRENT_TIMESTAMP`
      );
      for (const it of req.body.answers) {
        if (it.questionId) {
          upsert.run(
            attemptId,
            Number(it.questionId),
            JSON.stringify(it.answer ?? ''),
            it.isFlaggedReview ? 1 : 0
          );
        }
      }
    }

    const eqRows = db
      .prepare(
        `SELECT q.*, eq.weight_override
         FROM exam_questions eq
         JOIN questions q ON q.id = eq.question_id
         WHERE eq.exam_id = ?`
      )
      .all(exam.id) as any[];

    const ansRows = db
      .prepare('SELECT * FROM student_answers WHERE attempt_id = ?')
      .all(attemptId) as any[];
    const ansMap = new Map(ansRows.map((a) => [a.question_id, a]));

    const summaryInputs: Array<{
      earnedObjective: number;
      earnedManual: number | null;
      maxPoints: number;
      isEssay: boolean;
      isGraded: boolean;
    }> = [];

    const updateAnsScore = db.prepare(
      `INSERT INTO student_answers (attempt_id, question_id, answer_json, auto_score, is_graded)
       VALUES (?, ?, '""', ?, ?)
       ON CONFLICT(attempt_id, question_id) DO UPDATE SET
         auto_score = excluded.auto_score,
         is_graded = CASE WHEN student_answers.manual_score IS NOT NULL THEN 1 ELSE excluded.is_graded END`
    );

    const tx = db.transaction(() => {
      for (const q of eqRows) {
        const weight = q.weight_override ?? q.weight;
        const saved = ansMap.get(q.id);
        const parsedAns = saved ? JSON.parse(saved.answer_json || '""') : null;
        const isEssay = q.question_type === 'ESAI';

        if (isEssay) {
          const hasManual = saved?.manual_score !== null && saved?.manual_score !== undefined;
          updateAnsScore.run(attemptId, q.id, 0, hasManual ? 1 : 0);
          summaryInputs.push({
            earnedObjective: 0,
            earnedManual: hasManual ? saved.manual_score : null,
            maxPoints: weight,
            isEssay: true,
            isGraded: hasManual,
          });
        } else {
          const graded = gradeObjectiveQuestion(
            {
              questionType: q.question_type,
              correctAnswer: JSON.parse(q.correct_answer_json || '""'),
              matchingPairs: JSON.parse(q.matching_pairs_json || '[]'),
              shortAnswerConfig: JSON.parse(q.short_answer_config_json || '{}'),
              weight,
              partialScoring: Boolean(q.partial_scoring),
              pgkMode: q.pgk_mode,
            },
            parsedAns
          );
          updateAnsScore.run(attemptId, q.id, graded.score, 1);
          summaryInputs.push({
            earnedObjective: graded.score,
            earnedManual: null,
            maxPoints: weight,
            isEssay: false,
            isGraded: true,
          });
        }
      }

      const summary = calculateExamSummary(summaryInputs, {
        maxScore: exam.max_score,
        passingScore: exam.passing_score,
        roundingMode: exam.rounding_mode,
      });

      const finalStatus = summary.hasPendingEssay ? 'SUBMITTED' : 'GRADED';
      db.prepare(
        `UPDATE exam_attempts
         SET status = ?, submitted_at = CURRENT_TIMESTAMP, objective_score = ?, essay_score = ?, final_score = ?, passed = ?, is_locked = 0
         WHERE id = ?`
      ).run(
        finalStatus,
        summary.objectivePoints,
        summary.essayPoints,
        summary.normalizedScore,
        summary.passed ? 1 : 0,
        attemptId
      );

      return { summary, finalStatus };
    });

    const { summary, finalStatus } = tx();
    logAudit(req.authUser!.id, 'SUBMIT_EXAM', 'exam_attempt', attemptId, `Skor: ${summary.normalizedScore}`, req.ip);

    res.json({
      status: finalStatus,
      showScoreImmediately: Boolean(exam.show_score_immediately),
      summary: exam.show_score_immediately
        ? summary
        : {
            hasPendingEssay: summary.hasPendingEssay,
            hiddenUntilPublished: true,
          },
    });
  }
);

// TEACHER/PROCTOR: Live Monitor & Anti-Cheat Violations
examRouter.get(
  '/:id/monitor',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const examId = Number(req.params.id);
    const db = getDb();
    const exam = db
      .prepare('SELECT * FROM exams WHERE id = ? AND school_id = ?')
      .get(examId, req.authUser!.schoolId) as any;
    if (!exam) {
      res.status(404).json({ error: 'Ujian tidak ditemukan.' });
      return;
    }

    const attempts = db
      .prepare(
        `SELECT a.*, u.full_name as student_name, u.nip_nisn, c.name as class_name,
                (SELECT COUNT(*) FROM student_answers sa WHERE sa.attempt_id = a.id AND sa.answer_json != '""' AND sa.answer_json != '[]') as answered_count
         FROM exam_attempts a
         JOIN users u ON u.id = a.student_id
         LEFT JOIN classes c ON c.id = u.class_id
         WHERE a.exam_id = ?
         ORDER BY a.is_locked DESC, a.violation_count DESC, a.started_at DESC`
      )
      .all(examId);

    const violations = db
      .prepare(
        `SELECT v.*, u.full_name as student_name, u.nip_nisn, c.name as class_name
         FROM violation_logs v
         JOIN users u ON u.id = v.student_id
         LEFT JOIN classes c ON c.id = u.class_id
         WHERE v.exam_id = ?
         ORDER BY v.occurred_at DESC
         LIMIT 100`
      )
      .all(examId);

    // Target students who haven't started yet
    const targetClassIds: number[] = JSON.parse(exam.target_class_ids_json || '[]');
    let notStarted: any[] = [];
    if (targetClassIds.length > 0) {
      const placeholders = targetClassIds.map(() => '?').join(',');
      notStarted = db
        .prepare(
          `SELECT u.id, u.full_name, u.nip_nisn, c.name as class_name
           FROM users u
           LEFT JOIN classes c ON c.id = u.class_id
           WHERE u.role = 'SISWA' AND u.school_id = ? AND u.class_id IN (${placeholders})
             AND u.id NOT IN (SELECT student_id FROM exam_attempts WHERE exam_id = ?)`
        )
        .all(req.authUser!.schoolId, ...targetClassIds, examId);
    }

    res.json({ exam, attempts, violations, notStarted });
  }
);

// PROCTOR: Unlock a locked student attempt
examRouter.post(
  '/attempts/:attemptId/unlock',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const attemptId = Number(req.params.attemptId);
    const db = getDb();
    db.prepare(
      `UPDATE exam_attempts SET is_locked = 0, status = 'IN_PROGRESS' WHERE id = ?`
    ).run(attemptId);
    logAudit(req.authUser!.id, 'UNLOCK_ATTEMPT', 'exam_attempt', attemptId, 'Pengawas membuka kunci ujian siswa', req.ip);
    res.json({ ok: true });
  }
);
