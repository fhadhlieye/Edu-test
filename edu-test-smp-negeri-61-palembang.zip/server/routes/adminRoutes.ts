import { Router } from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import * as XLSX from 'xlsx';
import {
  createBackupSnapshot,
  DB_PATH,
  getDb,
  listBackups,
  logAudit,
  restoreBackupFromBuffer,
} from '../db.ts';
import {
  hashPassword,
  requireAuth,
  requireRole,
  sanitizePlainText,
  type AuthRequest,
} from '../auth.ts';
import { seedDatabaseIfEmpty } from '../seed.ts';

export const adminRouter = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 },
});

// Shared read endpoints (School metadata, classes, subjects) for Guru & Admin
adminRouter.get('/reference-data', requireAuth, (req: AuthRequest, res) => {
  const db = getDb();
  const school = db
    .prepare('SELECT * FROM schools WHERE id = ?')
    .get(req.authUser!.schoolId);
  const classes = db
    .prepare(
      `SELECT c.*, u.full_name as homeroom_teacher_name,
              (SELECT COUNT(*) FROM users WHERE class_id = c.id AND role = 'SISWA') as student_count
       FROM classes c
       LEFT JOIN users u ON u.id = c.homeroom_teacher_id
       WHERE c.school_id = ?
       ORDER BY c.grade_level, c.name`
    )
    .all(req.authUser!.schoolId);
  const subjects = db
    .prepare('SELECT * FROM subjects WHERE school_id = ? ORDER BY name')
    .all(req.authUser!.schoolId);
  res.json({ school, classes, subjects });
});

// School settings update (Admin Sekolah / Super Admin)
adminRouter.put(
  '/school',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const {
      name,
      npsn,
      address,
      city,
      headmaster,
      nipHeadmaster,
      academicYear,
      activeSemester,
      headerText,
      logoUrl,
    } = req.body || {};

    if (!name || !npsn) {
      res.status(400).json({ error: 'Nama sekolah dan NPSN wajib diisi.' });
      return;
    }

    db.prepare(
      `UPDATE schools
       SET name = ?, npsn = ?, address = ?, city = ?, headmaster = ?, nip_headmaster = ?,
           academic_year = ?, active_semester = ?, header_text = ?, logo_url = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).run(
      sanitizePlainText(name),
      sanitizePlainText(npsn),
      sanitizePlainText(address || ''),
      sanitizePlainText(city || 'Palembang'),
      sanitizePlainText(headmaster || ''),
      sanitizePlainText(nipHeadmaster || ''),
      sanitizePlainText(academicYear || '2025/2026'),
      sanitizePlainText(activeSemester || 'Ganjil'),
      sanitizePlainText(headerText || ''),
      typeof logoUrl === 'string' ? logoUrl.slice(0, 500000) : '',
      req.authUser!.schoolId
    );
    logAudit(req.authUser!.id, 'UPDATE_SCHOOL', 'school', req.authUser!.schoolId, 'Memperbarui profil sekolah', req.ip);
    res.json({ ok: true });
  }
);

// Classes CRUD
adminRouter.post(
  '/classes',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const name = sanitizePlainText(req.body?.name);
    const gradeLevel = sanitizePlainText(req.body?.gradeLevel || 'VII');
    const homeroomTeacherId = req.body?.homeroomTeacherId ? Number(req.body.homeroomTeacherId) : null;
    if (!name) {
      res.status(400).json({ error: 'Nama rombongan belajar wajib diisi.' });
      return;
    }
    const db = getDb();
    const info = db
      .prepare('INSERT INTO classes (school_id, name, grade_level, homeroom_teacher_id) VALUES (?, ?, ?, ?)')
      .run(req.authUser!.schoolId, name, gradeLevel, homeroomTeacherId);
    logAudit(req.authUser!.id, 'CREATE_CLASS', 'class', Number(info.lastInsertRowid), name, req.ip);
    res.json({ id: Number(info.lastInsertRowid) });
  }
);

adminRouter.delete(
  '/classes/:id',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const db = getDb();
    db.prepare('DELETE FROM classes WHERE id = ? AND school_id = ?').run(
      Number(req.params.id),
      req.authUser!.schoolId
    );
    logAudit(req.authUser!.id, 'DELETE_CLASS', 'class', req.params.id, 'Menghapus rombel', req.ip);
    res.json({ ok: true });
  }
);

// Subjects CRUD
adminRouter.post(
  '/subjects',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const code = sanitizePlainText(req.body?.code).toUpperCase();
    const name = sanitizePlainText(req.body?.name);
    const kkm = Number(req.body?.kkm) || 75;
    if (!code || !name) {
      res.status(400).json({ error: 'Kode dan nama mata pelajaran wajib diisi.' });
      return;
    }
    const db = getDb();
    const info = db
      .prepare('INSERT INTO subjects (school_id, code, name, kkm) VALUES (?, ?, ?, ?)')
      .run(req.authUser!.schoolId, code, name, kkm);
    logAudit(req.authUser!.id, 'CREATE_SUBJECT', 'subject', Number(info.lastInsertRowid), `${code} - ${name}`, req.ip);
    res.json({ id: Number(info.lastInsertRowid) });
  }
);

adminRouter.delete(
  '/subjects/:id',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const db = getDb();
    db.prepare('DELETE FROM subjects WHERE id = ? AND school_id = ?').run(
      Number(req.params.id),
      req.authUser!.schoolId
    );
    res.json({ ok: true });
  }
);

// Users management (Guru, Siswa, Admin)
adminRouter.get(
  '/users',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const roleFilter = sanitizePlainText(req.query.role || '');
    const search = sanitizePlainText(req.query.q || '');
    const db = getDb();
    let sql = `
      SELECT u.id, u.school_id, u.username, u.email, u.full_name, u.role, u.nip_nisn,
             u.class_id, u.phone, u.is_active, u.created_at, c.name as class_name
      FROM users u
      LEFT JOIN classes c ON c.id = u.class_id
      WHERE u.school_id = ?
    `;
    const params: any[] = [req.authUser!.schoolId];
    if (roleFilter) {
      sql += ' AND u.role = ?';
      params.push(roleFilter);
    }
    if (search) {
      sql += ' AND (u.full_name LIKE ? OR u.username LIKE ? OR u.nip_nisn LIKE ?)';
      const like = `%${search}%`;
      params.push(like, like, like);
    }
    sql += ' ORDER BY u.role, u.full_name';
    const users = db.prepare(sql).all(...params);
    res.json({ users });
  }
);

adminRouter.post(
  '/users',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const username = sanitizePlainText(req.body?.username).toLowerCase();
    const email = sanitizePlainText(req.body?.email);
    const fullName = sanitizePlainText(req.body?.fullName);
    const role = sanitizePlainText(req.body?.role);
    const nipNisn = sanitizePlainText(req.body?.nipNisn || '');
    const classId = req.body?.classId ? Number(req.body.classId) : null;
    const phone = sanitizePlainText(req.body?.phone || '');
    const rawPassword = typeof req.body?.password === 'string' && req.body.password.length >= 6
      ? req.body.password
      : role === 'SISWA'
        ? 'siswa123'
        : 'guru123';

    if (!username || !fullName || !['SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU', 'SISWA'].includes(role)) {
      res.status(400).json({ error: 'Username, nama lengkap, dan peran pengguna wajib diisi.' });
      return;
    }

    const db = getDb();
    const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (exists) {
      res.status(409).json({ error: 'Username sudah terdaftar.' });
      return;
    }

    const info = db
      .prepare(
        `INSERT INTO users (school_id, username, email, password_hash, full_name, role, nip_nisn, class_id, phone)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        req.authUser!.schoolId,
        username,
        email || `${username}@smpn61palembang.sch.id`,
        hashPassword(rawPassword),
        fullName,
        role,
        nipNisn,
        classId,
        phone
      );
    logAudit(req.authUser!.id, 'CREATE_USER', 'user', Number(info.lastInsertRowid), `${fullName} (${role})`, req.ip);
    res.json({ id: Number(info.lastInsertRowid) });
  }
);

adminRouter.post(
  '/users/:id/reset-password',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const newPassword = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';
    if (newPassword.length < 6) {
      res.status(400).json({ error: 'Kata sandi baru minimal 6 karakter.' });
      return;
    }
    const db = getDb();
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ? AND school_id = ?').run(
      hashPassword(newPassword),
      Number(req.params.id),
      req.authUser!.schoolId
    );
    logAudit(req.authUser!.id, 'ADMIN_RESET_PASSWORD', 'user', req.params.id, 'Reset kata sandi pengguna', req.ip);
    res.json({ ok: true });
  }
);

adminRouter.patch(
  '/users/:id/toggle-active',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const target = db
      .prepare('SELECT id, is_active FROM users WHERE id = ? AND school_id = ?')
      .get(Number(req.params.id), req.authUser!.schoolId) as { id: number; is_active: number } | undefined;
    if (!target) {
      res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
      return;
    }
    const nextState = target.is_active ? 0 : 1;
    db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(nextState, target.id);
    res.json({ isActive: Boolean(nextState) });
  }
);

adminRouter.delete(
  '/users/:id',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const id = Number(req.params.id);
    if (id === req.authUser!.id) {
      res.status(400).json({ error: 'Tidak dapat menghapus akun sendiri.' });
      return;
    }
    const db = getDb();
    db.prepare('DELETE FROM users WHERE id = ? AND school_id = ?').run(id, req.authUser!.schoolId);
    logAudit(req.authUser!.id, 'DELETE_USER', 'user', id, 'Menghapus pengguna', req.ip);
    res.json({ ok: true });
  }
);

// Bulk Import Guru or Siswa via Excel (.xlsx / .csv)
adminRouter.post(
  '/users/import-excel',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  upload.single('file'),
  (req: AuthRequest, res) => {
    if (!req.file) {
      res.status(400).json({ error: 'Silakan pilih file Excel (.xlsx/.csv) terlebih dahulu.' });
      return;
    }
    const targetRole = req.body?.role === 'GURU' ? 'GURU' : 'SISWA';
    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(firstSheet);

    const db = getDb();
    const classRows = db
      .prepare('SELECT id, name FROM classes WHERE school_id = ?')
      .all(req.authUser!.schoolId) as Array<{ id: number; name: string }>;
    const classByName = new Map(classRows.map((c) => [c.name.trim().toUpperCase(), c.id]));

    const insertStmt = db.prepare(
      `INSERT OR IGNORE INTO users (school_id, username, email, password_hash, full_name, role, nip_nisn, class_id, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    let importedCount = 0;
    let skippedCount = 0;
    const tx = db.transaction(() => {
      for (const row of rows) {
        const fullName = sanitizePlainText(
          row.nama || row.Nama || row.full_name || row['Nama Lengkap'] || ''
        );
        const nipNisn = sanitizePlainText(
          String(row.nisn || row.NISN || row.nip || row.NIP || row.nip_nisn || '')
        );
        const rawUsername = sanitizePlainText(
          String(row.username || row.Username || nipNisn || fullName.toLowerCase().replace(/\s+/g, '.'))
        ).toLowerCase();
        if (!fullName || !rawUsername) {
          skippedCount++;
          continue;
        }
        const email = sanitizePlainText(
          row.email || row.Email || `${rawUsername}@smpn61palembang.sch.id`
        );
        const className = sanitizePlainText(String(row.kelas || row.Kelas || row.rombel || '')).toUpperCase();
        const classId = classByName.get(className) ?? null;
        const defaultPass = String(row.password || (targetRole === 'SISWA' ? 'siswa123' : 'guru123'));

        const info = insertStmt.run(
          req.authUser!.schoolId,
          rawUsername,
          email,
          hashPassword(defaultPass),
          fullName,
          targetRole,
          nipNisn,
          classId,
          sanitizePlainText(String(row.telepon || row.phone || ''))
        );
        if (info.changes > 0) importedCount++;
        else skippedCount++;
      }
    });
    tx();

    logAudit(
      req.authUser!.id,
      'IMPORT_USERS_EXCEL',
      'user',
      targetRole,
      `Impor ${importedCount} akun ${targetRole}, dilewati ${skippedCount}`,
      req.ip
    );
    res.json({ importedCount, skippedCount, totalRows: rows.length });
  }
);

// Announcements management
adminRouter.post(
  '/announcements',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const title = sanitizePlainText(req.body?.title);
    const content = sanitizePlainText(req.body?.content);
    const targetRole = sanitizePlainText(req.body?.targetRole || 'ALL');
    const examId = req.body?.examId ? Number(req.body.examId) : null;
    if (!title || !content) {
      res.status(400).json({ error: 'Judul dan isi pengumuman wajib diisi.' });
      return;
    }
    const db = getDb();
    const info = db
      .prepare(
        `INSERT INTO announcements (school_id, title, content, target_role, exam_id, created_by)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(req.authUser!.schoolId, title, content, targetRole, examId, req.authUser!.id);

    // Notify target users
    const users = db
      .prepare(
        `SELECT id FROM users WHERE school_id = ? AND (? = 'ALL' OR role = ?)`
      )
      .all(req.authUser!.schoolId, targetRole, targetRole) as Array<{ id: number }>;
    const insNotif = db.prepare(
      'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)'
    );
    for (const u of users) {
      insNotif.run(u.id, title, content.slice(0, 140));
    }

    res.json({ id: Number(info.lastInsertRowid) });
  }
);

// Audit Logs
adminRouter.get(
  '/audit-logs',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (_req, res) => {
    const db = getDb();
    const logs = db
      .prepare(
        `SELECT a.*, u.full_name, u.username, u.role
         FROM audit_logs a
         LEFT JOIN users u ON u.id = a.user_id
         ORDER BY a.created_at DESC
         LIMIT 150`
      )
      .all();
    res.json({ logs });
  }
);

// Backup & Restore Database
adminRouter.get(
  '/backups',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (_req, res) => {
    res.json({ backups: listBackups() });
  }
);

adminRouter.post(
  '/backups',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req: AuthRequest, res) => {
    const snap = createBackupSnapshot('manual');
    logAudit(req.authUser!.id, 'CREATE_BACKUP', 'database', snap.filename, 'Membuat cadangan database', req.ip);
    res.json({ backup: snap });
  }
);

adminRouter.get(
  '/backups/download/:filename',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  (req, res) => {
    const safeName = path.basename(String(req.params.filename || ''));
    const fullPath = path.resolve(path.dirname(DB_PATH), 'backups', safeName);
    if (!fs.existsSync(fullPath)) {
      res.status(404).json({ error: 'File backup tidak ditemukan.' });
      return;
    }
    res.download(fullPath, safeName);
  }
);

adminRouter.post(
  '/backups/restore',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH'),
  upload.single('file'),
  (req: AuthRequest, res) => {
    if (!req.file) {
      res.status(400).json({ error: 'Silakan unggah file backup (.db).' });
      return;
    }
    try {
      restoreBackupFromBuffer(req.file.buffer);
      seedDatabaseIfEmpty();
      logAudit(req.authUser!.id, 'RESTORE_BACKUP', 'database', req.file.originalname, 'Restore database berhasil', req.ip);
      res.json({ ok: true, message: 'Database berhasil dipulihkan dari file backup.' });
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Gagal memulihkan database.' });
    }
  }
);
