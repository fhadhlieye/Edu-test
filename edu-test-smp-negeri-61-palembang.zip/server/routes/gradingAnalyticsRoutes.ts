import { Router } from 'express';
import * as XLSX from 'xlsx';
import { getDb, logAudit } from '../db.ts';
import {
  rateLimit,
  requireAuth,
  requireRole,
  type AuthRequest,
} from '../auth.ts';
import { gradeEssayWithRubricAI } from '../ai.ts';
import { calculateExamSummary } from '../../src/utils/grading.ts';
import {
  computeClassSummary,
  computeItemAnalysis,
} from '../../src/utils/itemAnalysis.ts';

export const gradingAnalyticsRouter = Router();

function recalculateAttemptScore(attemptId: number) {
  const db = getDb();
  const attempt = db
    .prepare('SELECT * FROM exam_attempts WHERE id = ?')
    .get(attemptId) as any;
  if (!attempt) return null;
  const exam = db.prepare('SELECT * FROM exams WHERE id = ?').get(attempt.exam_id) as any;

  const items = db
    .prepare(
      `SELECT q.id, q.question_type, COALESCE(eq.weight_override, q.weight) as max_points,
              sa.auto_score, sa.manual_score, sa.is_graded
       FROM exam_questions eq
       JOIN questions q ON q.id = eq.question_id
       LEFT JOIN student_answers sa ON sa.question_id = q.id AND sa.attempt_id = ?
       WHERE eq.exam_id = ?`
    )
    .all(attemptId, attempt.exam_id) as any[];

  const summary = calculateExamSummary(
    items.map((it) => ({
      earnedObjective: Number(it.auto_score || 0),
      earnedManual: it.manual_score !== null && it.manual_score !== undefined ? Number(it.manual_score) : null,
      maxPoints: Number(it.max_points || 1),
      isEssay: it.question_type === 'ESAI',
      isGraded: Boolean(it.is_graded),
    })),
    {
      maxScore: exam.max_score,
      passingScore: exam.passing_score,
      roundingMode: exam.rounding_mode,
    }
  );

  const nextStatus = summary.hasPendingEssay ? 'SUBMITTED' : 'GRADED';
  db.prepare(
    `UPDATE exam_attempts
     SET objective_score = ?, essay_score = ?, final_score = ?, passed = ?, status = ?
     WHERE id = ?`
  ).run(
    summary.objectivePoints,
    summary.essayPoints,
    summary.normalizedScore,
    summary.passed ? 1 : 0,
    nextStatus,
    attemptId
  );

  return summary;
}

// Teacher/Admin Dashboard Overview KPIs & Charts
gradingAnalyticsRouter.get(
  '/dashboard',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const schoolId = req.authUser!.schoolId;

    const counts = {
      totalExams: (
        db.prepare('SELECT COUNT(*) as c FROM exams WHERE school_id = ?').get(schoolId) as any
      ).c,
      activeExams: (
        db.prepare("SELECT COUNT(*) as c FROM exams WHERE school_id = ? AND status = 'ACTIVE'").get(schoolId) as any
      ).c,
      closedExams: (
        db.prepare("SELECT COUNT(*) as c FROM exams WHERE school_id = ? AND status = 'CLOSED'").get(schoolId) as any
      ).c,
      totalQuestions: (
        db.prepare('SELECT COUNT(*) as c FROM questions WHERE school_id = ?').get(schoolId) as any
      ).c,
      totalStudents: (
        db.prepare("SELECT COUNT(*) as c FROM users WHERE school_id = ? AND role = 'SISWA'").get(schoolId) as any
      ).c,
      totalTeachers: (
        db.prepare("SELECT COUNT(*) as c FROM users WHERE school_id = ? AND role = 'GURU'").get(schoolId) as any
      ).c,
      totalClasses: (
        db.prepare('SELECT COUNT(*) as c FROM classes WHERE school_id = ?').get(schoolId) as any
      ).c,
      totalViolations: (
        db.prepare(
          `SELECT COUNT(*) as c FROM violation_logs v
           JOIN exams e ON e.id = v.exam_id WHERE e.school_id = ?`
        ).get(schoolId) as any
      ).c,
    };

    const attempts = db
      .prepare(
        `SELECT a.student_id, u.full_name as student_name, COALESCE(c.name, 'Umum') as class_name,
                a.final_score, a.passed, e.title as exam_title, e.scheduled_date
         FROM exam_attempts a
         JOIN exams e ON e.id = a.exam_id
         JOIN users u ON u.id = a.student_id
         LEFT JOIN classes c ON c.id = u.class_id
         WHERE e.school_id = ? AND a.status IN ('SUBMITTED', 'GRADED')`
      )
      .all(schoolId) as any[];

    const summary = computeClassSummary(
      attempts.map((a) => ({
        studentId: a.student_id,
        studentName: a.student_name,
        className: a.class_name,
        finalScore: a.final_score,
        passed: Boolean(a.passed),
      }))
    );

    const examTrend = db
      .prepare(
        `SELECT e.id, e.title, e.scheduled_date,
                ROUND(AVG(a.final_score), 1) as avg_score,
                COUNT(a.id) as participants
         FROM exams e
         LEFT JOIN exam_attempts a ON a.exam_id = e.id AND a.status IN ('SUBMITTED', 'GRADED')
         WHERE e.school_id = ?
         GROUP BY e.id
         ORDER BY e.id ASC`
      )
      .all(schoolId);

    const pendingEssayCount = (
      db
        .prepare(
          `SELECT COUNT(*) as c
           FROM student_answers sa
           JOIN questions q ON q.id = sa.question_id
           JOIN exam_attempts ea ON ea.id = sa.attempt_id
           JOIN exams e ON e.id = ea.exam_id
           WHERE e.school_id = ? AND q.question_type = 'ESAI' AND sa.is_graded = 0 AND ea.status IN ('SUBMITTED', 'GRADED')`
        )
        .get(schoolId) as any
    ).c;

    // Distinct students who have not completed at least 1 active exam
    const notCompletedActive = (
      db
        .prepare(
          `SELECT COUNT(*) as c FROM users u
           WHERE u.school_id = ? AND u.role = 'SISWA'
             AND u.id NOT IN (
               SELECT ea.student_id FROM exam_attempts ea
               JOIN exams ex ON ex.id = ea.exam_id
               WHERE ex.status = 'ACTIVE' AND ea.status IN ('SUBMITTED','GRADED')
             )`
        )
        .get(schoolId) as any
    ).c;

    res.json({
      counts: {
        ...counts,
        pendingEssayCount,
        notCompletedActive,
      },
      summary,
      examTrend,
    });
  }
);

// Exam Grading & Results List
gradingAnalyticsRouter.get(
  '/exams/:examId/submissions',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const examId = Number(req.params.examId);
    const db = getDb();

    const exam = db
      .prepare(
        `SELECT e.*, s.name as subject_name
         FROM exams e JOIN subjects s ON s.id = e.subject_id
         WHERE e.id = ? AND e.school_id = ?`
      )
      .get(examId, req.authUser!.schoolId) as any;
    if (!exam) {
      res.status(404).json({ error: 'Ujian tidak ditemukan.' });
      return;
    }

    const attempts = db
      .prepare(
        `SELECT a.*, u.full_name as student_name, u.nip_nisn, u.username, COALESCE(c.name, '-') as class_name
         FROM exam_attempts a
         JOIN users u ON u.id = a.student_id
         LEFT JOIN classes c ON c.id = u.class_id
         WHERE a.exam_id = ?
         ORDER BY a.final_score DESC, u.full_name ASC`
      )
      .all(examId) as any[];

    const questions = db
      .prepare(
        `SELECT q.*, eq.order_index, COALESCE(eq.weight_override, q.weight) as max_weight
         FROM exam_questions eq
         JOIN questions q ON q.id = eq.question_id
         WHERE eq.exam_id = ?
         ORDER BY eq.order_index ASC`
      )
      .all(examId) as any[];

    const answers = db
      .prepare(
        `SELECT sa.*
         FROM student_answers sa
         JOIN exam_attempts ea ON ea.id = sa.attempt_id
         WHERE ea.exam_id = ?`
      )
      .all(examId) as any[];

    const answersByAttempt = new Map<number, any[]>();
    for (const a of answers) {
      const list = answersByAttempt.get(a.attempt_id) || [];
      list.push({
        ...a,
        answer: JSON.parse(a.answer_json || '""'),
        aiRubricBreakdown: JSON.parse(a.ai_rubric_breakdown_json || '[]'),
      });
      answersByAttempt.set(a.attempt_id, list);
    }

    res.json({
      exam,
      questions: questions.map((q) => ({
        id: q.id,
        orderIndex: q.order_index,
        questionType: q.question_type,
        stem: q.stem,
        weight: q.max_weight,
        options: JSON.parse(q.options_json || '[]'),
        correctAnswer: JSON.parse(q.correct_answer_json || '""'),
        matchingPairs: JSON.parse(q.matching_pairs_json || '[]'),
        rubric: JSON.parse(q.rubric_json || '[]'),
      })),
      submissions: attempts.map((at) => ({
        ...at,
        answers: answersByAttempt.get(at.id) || [],
      })),
    });
  }
);

// AI Assistant Recommendation for Essay Answer
gradingAnalyticsRouter.post(
  '/answers/:answerId/ai-recommend',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  rateLimit(30, 60_000),
  async (req: AuthRequest, res) => {
    const answerId = Number(req.params.answerId);
    const db = getDb();

    const row = db
      .prepare(
        `SELECT sa.*, q.stem, q.correct_answer_json, q.rubric_json, q.weight,
                eq.weight_override
         FROM student_answers sa
         JOIN exam_attempts ea ON ea.id = sa.attempt_id
         JOIN questions q ON q.id = sa.question_id
         LEFT JOIN exam_questions eq ON eq.exam_id = ea.exam_id AND eq.question_id = q.id
         WHERE sa.id = ?`
      )
      .get(answerId) as any;

    if (!row) {
      res.status(404).json({ error: 'Jawaban siswa tidak ditemukan.' });
      return;
    }

    const studentAnswer = String(JSON.parse(row.answer_json || '""'));
    const rubric = JSON.parse(row.rubric_json || '[]');
    const modelAnswer = String(JSON.parse(row.correct_answer_json || '""'));
    const maxWeight = Number(row.weight_override ?? row.weight) || 5;

    const result = await gradeEssayWithRubricAI({
      questionStem: row.stem,
      modelAnswer,
      rubric,
      studentAnswer,
      maxWeight,
    });

    db.prepare(
      `UPDATE student_answers
       SET ai_recommended_score = ?, ai_feedback = ?, ai_rubric_breakdown_json = ?
       WHERE id = ?`
    ).run(
      result.recommendedScore,
      result.feedback,
      JSON.stringify(result.breakdown),
      answerId
    );

    res.json(result);
  }
);

// Teacher approves or manually sets essay score
gradingAnalyticsRouter.post(
  '/answers/:answerId/grade',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const answerId = Number(req.params.answerId);
    const manualScore = Number(req.body?.manualScore);
    const feedback = typeof req.body?.feedback === 'string' ? req.body.feedback : undefined;
    if (!Number.isFinite(manualScore) || manualScore < 0) {
      res.status(400).json({ error: 'Skor harus berupa angka >= 0.' });
      return;
    }

    const db = getDb();
    const row = db
      .prepare('SELECT attempt_id FROM student_answers WHERE id = ?')
      .get(answerId) as { attempt_id: number } | undefined;
    if (!row) {
      res.status(404).json({ error: 'Jawaban tidak ditemukan.' });
      return;
    }

    db.prepare(
      `UPDATE student_answers
       SET manual_score = ?, ai_feedback = COALESCE(?, ai_feedback), is_graded = 1, graded_by = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).run(manualScore, feedback ?? null, req.authUser!.id, answerId);

    const summary = recalculateAttemptScore(row.attempt_id);
    logAudit(req.authUser!.id, 'GRADE_ESSAY', 'student_answer', answerId, `Nilai esai -> ${manualScore}`, req.ip);
    res.json({ ok: true, summary });
  }
);

// Publish or withhold exam scores to students
gradingAnalyticsRouter.patch(
  '/exams/:examId/publish-scores',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const show = req.body?.showScoreImmediately ? 1 : 0;
    const db = getDb();
    db.prepare('UPDATE exams SET show_score_immediately = ? WHERE id = ? AND school_id = ?').run(
      show,
      Number(req.params.examId),
      req.authUser!.schoolId
    );
    res.json({ ok: true, showScoreImmediately: Boolean(show) });
  }
);

// Grant remedial retake by increasing attempt allowance or resetting for student
gradingAnalyticsRouter.post(
  '/exams/:examId/remedial-grant',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const examId = Number(req.params.examId);
    const db = getDb();
    db.prepare(
      `UPDATE exams SET max_attempts = MAX(max_attempts, 2), allow_remedial = 1, status = 'ACTIVE' WHERE id = ? AND school_id = ?`
    ).run(examId, req.authUser!.schoolId);
    logAudit(req.authUser!.id, 'ENABLE_REMEDIAL', 'exam', examId, 'Membuka kesempatan ujian remedial', req.ip);
    res.json({ ok: true });
  }
);

// Detailed Exam Item Analysis (Tingkat Kesukaran P, Daya Pembeda D, Efektivitas Pengecoh)
gradingAnalyticsRouter.get(
  '/exams/:examId/analysis',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const examId = Number(req.params.examId);
    const db = getDb();

    const exam = db
      .prepare(
        `SELECT e.*, s.name as subject_name, u.full_name as creator_name
         FROM exams e
         JOIN subjects s ON s.id = e.subject_id
         JOIN users u ON u.id = e.created_by
         WHERE e.id = ? AND e.school_id = ?`
      )
      .get(examId, req.authUser!.schoolId) as any;

    if (!exam) {
      res.status(404).json({ error: 'Ujian tidak ditemukan.' });
      return;
    }

    const attempts = db
      .prepare(
        `SELECT a.id, a.student_id, a.final_score, a.passed, u.full_name as student_name, u.nip_nisn,
                COALESCE(c.name, 'Umum') as class_name
         FROM exam_attempts a
         JOIN users u ON u.id = a.student_id
         LEFT JOIN classes c ON c.id = u.class_id
         WHERE a.exam_id = ? AND a.status IN ('SUBMITTED', 'GRADED')`
      )
      .all(examId) as any[];

    const summary = computeClassSummary(
      attempts.map((a) => ({
        studentId: a.student_id,
        studentName: a.student_name,
        className: a.class_name,
        finalScore: a.final_score,
        passed: Boolean(a.passed),
      }))
    );

    const responseRows = db
      .prepare(
        `SELECT ea.student_id, ea.final_score as total_student_score,
                q.id as question_id, eq.order_index as question_number,
                q.question_type, q.stem, q.options_json, q.correct_answer_json,
                COALESCE(eq.weight_override, q.weight) as max_weight,
                sa.answer_json, sa.auto_score, sa.manual_score
         FROM exam_attempts ea
         JOIN exam_questions eq ON eq.exam_id = ea.exam_id
         JOIN questions q ON q.id = eq.question_id
         LEFT JOIN student_answers sa ON sa.attempt_id = ea.id AND sa.question_id = q.id
         WHERE ea.exam_id = ? AND ea.status IN ('SUBMITTED', 'GRADED')`
      )
      .all(examId) as any[];

    const items = computeItemAnalysis(
      responseRows.map((r) => {
        const opts = JSON.parse(r.options_json || '[]') as Array<{ key: string }>;
        const ans = r.answer_json ? JSON.parse(r.answer_json) : '';
        const correct = JSON.parse(r.correct_answer_json || '""');
        const earned =
          r.question_type === 'ESAI'
            ? Number(r.manual_score || 0)
            : Number(r.auto_score || 0);
        return {
          studentId: r.student_id,
          totalStudentScore: r.total_student_score,
          questionId: r.question_id,
          questionNumber: r.question_number,
          questionType: r.question_type,
          stem: r.stem,
          earnedScore: earned,
          maxWeight: Number(r.max_weight || 1),
          selectedOption: typeof ans === 'string' ? ans : undefined,
          correctOption: typeof correct === 'string' ? correct : undefined,
          options: opts.map((o) => o.key),
        };
      })
    );

    res.json({ exam, summary, itemAnalysis: items, participants: attempts });
  }
);

// Export Exam Report to Excel or CSV
gradingAnalyticsRouter.get(
  '/exams/:examId/export',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const examId = Number(req.params.examId);
    const format = req.query.format === 'csv' ? 'csv' : 'xlsx';
    const db = getDb();

    const exam = db
      .prepare(
        `SELECT e.title, s.name as subject_name
         FROM exams e JOIN subjects s ON s.id = e.subject_id
         WHERE e.id = ? AND e.school_id = ?`
      )
      .get(examId, req.authUser!.schoolId) as any;
    if (!exam) {
      res.status(404).json({ error: 'Ujian tidak ditemukan.' });
      return;
    }

    const rows = db
      .prepare(
        `SELECT u.nip_nisn as NISN, u.full_name as Nama_Siswa, COALESCE(c.name, '-') as Kelas,
                a.attempt_number as Percobaan, a.objective_score as Skor_Objektif,
                a.essay_score as Skor_Esai, a.final_score as Nilai_Akhir,
                CASE WHEN a.passed = 1 THEN 'Tuntas' ELSE 'Remedial' END as Keterangan,
                a.violation_count as Pelanggaran, a.submitted_at as Waktu_Selesai
         FROM exam_attempts a
         JOIN users u ON u.id = a.student_id
         LEFT JOIN classes c ON c.id = u.class_id
         WHERE a.exam_id = ?
         ORDER BY c.name, u.full_name`
      )
      .all(examId) as any[];

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'Rekap Nilai');

    if (format === 'csv') {
      const csv = XLSX.utils.sheet_to_csv(ws);
      res.setHeader('Content-Disposition', `attachment; filename="rekap-ujian-${examId}.csv"`);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.send(csv);
      return;
    }

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Disposition', `attachment; filename="rekap-ujian-${examId}.xlsx"`);
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.send(buf);
  }
);

// STUDENT: Exam History & Digital Exam Card Data
gradingAnalyticsRouter.get(
  '/student/history',
  requireAuth,
  requireRole('SISWA'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const rows = db
      .prepare(
        `SELECT a.*, e.title as exam_title, e.scheduled_date, e.passing_score,
                e.show_score_immediately, s.name as subject_name
         FROM exam_attempts a
         JOIN exams e ON e.id = a.exam_id
         JOIN subjects s ON s.id = e.subject_id
         WHERE a.student_id = ?
         ORDER BY a.started_at DESC`
      )
      .all(req.authUser!.id) as any[];

    res.json({
      history: rows.map((r) => ({
        id: r.id,
        examId: r.exam_id,
        examTitle: r.exam_title,
        subjectName: r.subject_name,
        scheduledDate: r.scheduled_date,
        attemptNumber: r.attempt_number,
        isRemedial: Boolean(r.is_remedial),
        status: r.status,
        startedAt: r.started_at,
        submittedAt: r.submitted_at,
        violationCount: r.violation_count,
        finalScore: r.show_score_immediately || r.status === 'GRADED' ? r.final_score : null,
        passed: r.show_score_immediately || r.status === 'GRADED' ? Boolean(r.passed) : null,
        passingScore: r.passing_score,
        scoreHidden: !r.show_score_immediately && r.status !== 'GRADED',
      })),
    });
  }
);
