import { Router } from 'express';
import { getDb, logAudit } from '../db.ts';
import {
  clearSessionCookie,
  hashPassword,
  parseCookieHeader,
  rateLimit,
  requireAuth,
  sanitizePlainText,
  setSessionCookie,
  signSessionToken,
  verifyPassword,
  verifySessionToken,
  type AuthRequest,
} from '../auth.ts';

export const authRouter = Router();

authRouter.get('/demo-accounts', (_req, res) => {
  res.json({
    note: 'Akun contoh pengujian (bukan akun produksi permanen).',
    accounts: [
      { role: 'SUPER_ADMIN', label: 'Super Admin', username: 'superadmin', hint: 'admin123' },
      { role: 'ADMIN_SEKOLAH', label: 'Admin Sekolah', username: 'admin61', hint: 'admin123' },
      { role: 'GURU', label: 'Guru (Matematika)', username: 'guru.ratna', hint: 'guru123' },
      { role: 'GURU', label: 'Guru (B. Indonesia)', username: 'guru.budi', hint: 'guru123' },
      { role: 'SISWA', label: 'Siswa (IX-A)', username: 'siswa.ahmad', hint: 'siswa123' },
    ],
  });
});

authRouter.post('/login', rateLimit(30, 60_000), (req, res) => {
  const identifier = sanitizePlainText(req.body?.identifier || req.body?.username || '');
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  if (!identifier || !password) {
    res.status(400).json({ error: 'Username/NISN/Email dan kata sandi wajib diisi.' });
    return;
  }

  const db = getDb();
  const user = db
    .prepare(
      `SELECT u.*, c.name as class_name
       FROM users u
       LEFT JOIN classes c ON c.id = u.class_id
       WHERE u.username = ? OR u.email = ? OR u.nip_nisn = ?`
    )
    .get(identifier, identifier, identifier) as any;

  if (!user || !verifyPassword(password, user.password_hash)) {
    res.status(401).json({ error: 'Kredensial tidak valid. Periksa username/NISN dan kata sandi.' });
    return;
  }
  if (!user.is_active) {
    res.status(403).json({ error: 'Akun ini sedang dinonaktifkan oleh administrator.' });
    return;
  }

  const token = signSessionToken(user.id, user.role);
  setSessionCookie(res, token);
  logAudit(user.id, 'LOGIN', 'user', user.id, `Login sebagai ${user.role}`, req.ip);

  res.json({
    user: {
      id: user.id,
      schoolId: user.school_id,
      username: user.username,
      email: user.email,
      fullName: user.full_name,
      role: user.role,
      nipNisn: user.nip_nisn,
      classId: user.class_id,
      className: user.class_name || undefined,
      isActive: Boolean(user.is_active),
    },
  });
});

authRouter.post('/logout', requireAuth, (req: AuthRequest, res) => {
  logAudit(req.authUser!.id, 'LOGOUT', 'user', req.authUser!.id, 'Keluar dari sistem', req.ip);
  clearSessionCookie(res);
  res.json({ ok: true });
});

authRouter.get('/session', (req, res) => {
  const cookies = parseCookieHeader(req.headers.cookie);
  const token = cookies['edutest_session'];
  const verified = token ? verifySessionToken(token) : null;
  if (!verified) {
    res.json({ authenticated: false, user: null, school: null, unreadNotifications: 0 });
    return;
  }
  const db = getDb();
  const row = db
    .prepare(
      `SELECT u.id, u.school_id, u.username, u.email, u.full_name, u.role, u.nip_nisn, u.class_id, u.is_active,
              c.name as class_name
       FROM users u LEFT JOIN classes c ON c.id = u.class_id WHERE u.id = ?`
    )
    .get(verified.userId) as any;
  if (!row || !row.is_active) {
    res.json({ authenticated: false, user: null, school: null, unreadNotifications: 0 });
    return;
  }
  const school = db.prepare('SELECT * FROM schools WHERE id = ?').get(row.school_id) as any;
  const unreadNotifs = db
    .prepare('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(row.id) as { cnt: number };
  res.json({
    authenticated: true,
    user: {
      id: row.id,
      schoolId: row.school_id,
      username: row.username,
      email: row.email,
      fullName: row.full_name,
      role: row.role,
      nipNisn: row.nip_nisn,
      classId: row.class_id,
      className: row.class_name || undefined,
    },
    school: school
      ? {
          id: school.id,
          name: school.name,
          npsn: school.npsn,
          address: school.address,
          city: school.city,
          headmaster: school.headmaster,
          nipHeadmaster: school.nip_headmaster,
          academicYear: school.academic_year,
          activeSemester: school.active_semester,
          headerText: school.header_text,
          logoUrl: school.logo_url,
        }
      : null,
    unreadNotifications: unreadNotifs.cnt,
  });
});

authRouter.get('/me', requireAuth, (req: AuthRequest, res) => {
  const db = getDb();
  const school = db.prepare('SELECT * FROM schools WHERE id = ?').get(req.authUser!.schoolId) as any;
  const unreadNotifs = db
    .prepare('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(req.authUser!.id) as { cnt: number };

  res.json({
    user: req.authUser,
    school: school
      ? {
          id: school.id,
          name: school.name,
          npsn: school.npsn,
          address: school.address,
          city: school.city,
          headmaster: school.headmaster,
          nipHeadmaster: school.nip_headmaster,
          academicYear: school.academic_year,
          activeSemester: school.active_semester,
          headerText: school.header_text,
          logoUrl: school.logo_url,
        }
      : null,
    unreadNotifications: unreadNotifs.cnt,
  });
});

authRouter.post('/change-password', requireAuth, (req: AuthRequest, res) => {
  const oldPassword = typeof req.body?.oldPassword === 'string' ? req.body.oldPassword : '';
  const newPassword = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';
  if (newPassword.length < 6) {
    res.status(400).json({ error: 'Kata sandi baru minimal 6 karakter.' });
    return;
  }

  const db = getDb();
  const row = db
    .prepare('SELECT password_hash FROM users WHERE id = ?')
    .get(req.authUser!.id) as { password_hash: string } | undefined;

  if (!row || !verifyPassword(oldPassword, row.password_hash)) {
    res.status(400).json({ error: 'Kata sandi lama tidak sesuai.' });
    return;
  }

  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(
    hashPassword(newPassword),
    req.authUser!.id
  );
  logAudit(req.authUser!.id, 'CHANGE_PASSWORD', 'user', req.authUser!.id, 'Mengubah kata sandi', req.ip);
  res.json({ ok: true, message: 'Kata sandi berhasil diperbarui.' });
});

authRouter.get('/notifications', requireAuth, (req: AuthRequest, res) => {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 30')
    .all(req.authUser!.id);
  res.json({ notifications: rows });
});

authRouter.post('/notifications/read-all', requireAuth, (req: AuthRequest, res) => {
  const db = getDb();
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.authUser!.id);
  res.json({ ok: true });
});

authRouter.get('/announcements', requireAuth, (req: AuthRequest, res) => {
  const db = getDb();
  const role = req.authUser!.role;
  const rows = db
    .prepare(
      `SELECT a.*, u.full_name as author_name
       FROM announcements a
       JOIN users u ON u.id = a.created_by
       WHERE a.school_id = ? AND (a.target_role = 'ALL' OR a.target_role = ? OR ? IN ('SUPER_ADMIN','ADMIN_SEKOLAH'))
       ORDER BY a.created_at DESC`
    )
    .all(req.authUser!.schoolId, role, role);
  res.json({ announcements: rows });
});
