import { Router } from 'express';
import multer from 'multer';
import fs from 'node:fs';
import path from 'node:path';
import * as XLSX from 'xlsx';
import { getDb, logAudit, UPLOAD_ARCHIVE_DIR } from '../db.ts';
import {
  rateLimit,
  requireAuth,
  requireRole,
  sanitizePlainText,
  type AuthRequest,
} from '../auth.ts';
import { extractQuestionsFromDocument } from '../ai.ts';
import { parseQuestionsHeuristic } from '../../src/utils/questionParser.ts';

export const questionRouter = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
});

function serializeQuestionRow(row: any) {
  return {
    id: row.id,
    schoolId: row.school_id,
    subjectId: row.subject_id,
    subjectName: row.subject_name,
    createdBy: row.created_by,
    creatorName: row.creator_name,
    sourceDocumentId: row.source_document_id,
    gradeLevel: row.grade_level,
    topic: row.topic,
    difficulty: row.difficulty,
    questionType: row.question_type,
    stimulusTitle: row.stimulus_title || '',
    stimulusText: row.stimulus_text || '',
    stimulusMedia: JSON.parse(row.stimulus_media_json || '[]'),
    stem: row.stem,
    mathLatex: row.math_latex || '',
    options: JSON.parse(row.options_json || '[]'),
    correctAnswer: JSON.parse(row.correct_answer_json || '""'),
    matchingPairs: JSON.parse(row.matching_pairs_json || '[]'),
    shortAnswerConfig: JSON.parse(
      row.short_answer_config_json ||
        '{"acceptedAnswers":[],"caseSensitive":false,"ignoreWhitespace":false,"numericTolerance":0}'
    ),
    rubric: JSON.parse(row.rubric_json || '[]'),
    weight: row.weight,
    partialScoring: Boolean(row.partial_scoring),
    pgkMode: row.pgk_mode || 'ALL_OR_NOTHING',
    warnings: JSON.parse(row.warnings_json || '[]'),
    year: row.year,
    createdAt: row.created_at,
  };
}

// SMART QUESTION IMPORT: Upload DOC/DOCX/PDF/Image/TXT -> Archive original -> Extract & Classify
questionRouter.post(
  '/smart-import',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  rateLimit(20, 60_000),
  upload.single('file'),
  async (req: AuthRequest, res) => {
    try {
      const rawTextInput = typeof req.body?.rawText === 'string' ? req.body.rawText : '';
      const defaultTopic = sanitizePlainText(req.body?.topic || 'Umum');

      if (!req.file && !rawTextInput.trim()) {
        res.status(400).json({ error: 'Unggah file (.doc, .docx, .pdf, gambar) atau tempel teks dokumen soal.' });
        return;
      }

      let buffer: Buffer;
      let filename: string;
      let mimeType: string;

      if (req.file) {
        buffer = req.file.buffer;
        filename = req.file.originalname;
        mimeType = req.file.mimetype;
      } else {
        buffer = Buffer.from(rawTextInput, 'utf8');
        filename = `naskah-soal-${Date.now()}.txt`;
        mimeType = 'text/plain';
      }

      // Archive original file safely on disk
      const archiveName = `${Date.now()}-${filename.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
      const storedPath = path.join(UPLOAD_ARCHIVE_DIR, archiveName);
      fs.writeFileSync(storedPath, buffer);

      const extraction = await extractQuestionsFromDocument({
        buffer,
        filename,
        mimeType,
        defaultTopic,
      });

      const db = getDb();
      const docInfo = db
        .prepare(
          `INSERT INTO uploaded_documents (uploaded_by, original_filename, mime_type, file_size, stored_path, extracted_text, extraction_method, total_detected)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          req.authUser!.id,
          filename,
          mimeType,
          buffer.length,
          archiveName,
          extraction.extractedText,
          extraction.extractionMethod,
          extraction.questions.length
        );

      const sourceDocumentId = Number(docInfo.lastInsertRowid);
      logAudit(
        req.authUser!.id,
        'SMART_IMPORT',
        'document',
        sourceDocumentId,
        `${filename} -> ${extraction.questions.length} soal (${extraction.extractionMethod})`,
        req.ip
      );

      res.json({
        sourceDocumentId,
        originalFilename: filename,
        extractionMethod: extraction.extractionMethod,
        totalDetected: extraction.questions.length,
        embeddedImages: extraction.embeddedImages,
        questions: extraction.questions,
      });
    } catch (err: any) {
      console.error('Smart Import error:', err);
      res.status(500).json({ error: err.message || 'Gagal mengekstrak dokumen soal.' });
    }
  }
);

// List archived uploaded documents
questionRouter.get(
  '/archives',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const docs = db
      .prepare(
        `SELECT d.id, d.original_filename, d.mime_type, d.file_size, d.extraction_method, d.total_detected, d.created_at,
                u.full_name as uploader_name
         FROM uploaded_documents d
         JOIN users u ON u.id = d.uploaded_by
         ORDER BY d.created_at DESC
         LIMIT 50`
      )
      .all();
    res.json({ archives: docs });
  }
);

questionRouter.get(
  '/archives/:id/download',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req, res) => {
    const db = getDb();
    const doc = db
      .prepare('SELECT original_filename, stored_path FROM uploaded_documents WHERE id = ?')
      .get(Number(req.params.id)) as { original_filename: string; stored_path: string } | undefined;
    if (!doc) {
      res.status(404).json({ error: 'Arsip dokumen tidak ditemukan.' });
      return;
    }
    const fullPath = path.join(UPLOAD_ARCHIVE_DIR, path.basename(doc.stored_path));
    if (!fs.existsSync(fullPath)) {
      res.status(404).json({ error: 'File arsip tidak ada di penyimpanan.' });
      return;
    }
    res.download(fullPath, doc.original_filename);
  }
);

// Bulk Save Extracted Drafts to Bank Soal
questionRouter.post(
  '/bulk-save',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const subjectId = Number(req.body?.subjectId);
    const gradeLevel = sanitizePlainText(req.body?.gradeLevel || 'IX');
    const sourceDocumentId = req.body?.sourceDocumentId ? Number(req.body.sourceDocumentId) : null;
    const items = Array.isArray(req.body?.questions) ? req.body.questions : [];

    if (!subjectId || items.length === 0) {
      res.status(400).json({ error: 'Mata pelajaran dan minimal 1 soal wajib dipilih.' });
      return;
    }

    const db = getDb();
    const insertStmt = db.prepare(
      `INSERT INTO questions (
        school_id, subject_id, created_by, source_document_id, grade_level, topic, difficulty, question_type,
        stimulus_title, stimulus_text, stimulus_media_json, stem, math_latex,
        options_json, correct_answer_json, matching_pairs_json, short_answer_config_json,
        rubric_json, weight, partial_scoring, pgk_mode, warnings_json, year
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const savedIds: number[] = [];
    const tx = db.transaction(() => {
      for (const q of items) {
        if (!q.stem || !String(q.stem).trim()) continue;
        const info = insertStmt.run(
          req.authUser!.schoolId,
          subjectId,
          req.authUser!.id,
          sourceDocumentId,
          sanitizePlainText(q.gradeLevel || gradeLevel),
          sanitizePlainText(q.topic || 'Umum'),
          sanitizePlainText(q.difficulty || 'SEDANG'),
          q.questionType || 'PG',
          sanitizePlainText(q.stimulusTitle || ''),
          String(q.stimulusText || ''),
          JSON.stringify(q.stimulusMedia || []),
          String(q.stem || '').trim(),
          String(q.mathLatex || ''),
          JSON.stringify(q.options || []),
          JSON.stringify(q.correctAnswer ?? ''),
          JSON.stringify(q.matchingPairs || []),
          JSON.stringify(q.shortAnswerConfig || {}),
          JSON.stringify(q.rubric || []),
          Number(q.weight) || 2,
          q.partialScoring ? 1 : 0,
          q.pgkMode || 'ALL_OR_NOTHING',
          JSON.stringify(q.warnings || []),
          Number(q.year) || new Date().getFullYear()
        );
        savedIds.push(Number(info.lastInsertRowid));
      }
    });
    tx();

    logAudit(req.authUser!.id, 'BULK_SAVE_QUESTIONS', 'question', savedIds.length, `Menyimpan ${savedIds.length} soal ke Bank Soal`, req.ip);
    res.json({ savedIds, count: savedIds.length });
  }
);

// List & Filter Bank Soal
questionRouter.get(
  '/',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    let sql = `
      SELECT q.*, s.name as subject_name, u.full_name as creator_name
      FROM questions q
      JOIN subjects s ON s.id = q.subject_id
      JOIN users u ON u.id = q.created_by
      WHERE q.school_id = ?
    `;
    const params: any[] = [req.authUser!.schoolId];

    if (req.query.subjectId) {
      sql += ' AND q.subject_id = ?';
      params.push(Number(req.query.subjectId));
    }
    if (req.query.gradeLevel) {
      sql += ' AND q.grade_level = ?';
      params.push(sanitizePlainText(req.query.gradeLevel));
    }
    if (req.query.difficulty) {
      sql += ' AND q.difficulty = ?';
      params.push(sanitizePlainText(req.query.difficulty));
    }
    if (req.query.questionType) {
      sql += ' AND q.question_type = ?';
      params.push(sanitizePlainText(req.query.questionType));
    }
    if (req.query.q) {
      sql += ' AND (q.stem LIKE ? OR q.topic LIKE ? OR q.stimulus_text LIKE ?)';
      const like = `%${sanitizePlainText(req.query.q)}%`;
      params.push(like, like, like);
    }

    sql += ' ORDER BY q.id DESC';
    const rows = db.prepare(sql).all(...params);
    res.json({ questions: rows.map(serializeQuestionRow) });
  }
);

// Create single question
questionRouter.post(
  '/',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const q = req.body || {};
    if (!q.subjectId || !q.stem) {
      res.status(400).json({ error: 'Mata pelajaran dan teks pertanyaan wajib diisi.' });
      return;
    }
    const db = getDb();
    const info = db
      .prepare(
        `INSERT INTO questions (
          school_id, subject_id, created_by, grade_level, topic, difficulty, question_type,
          stimulus_title, stimulus_text, stimulus_media_json, stem, math_latex,
          options_json, correct_answer_json, matching_pairs_json, short_answer_config_json,
          rubric_json, weight, partial_scoring, pgk_mode, year
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        req.authUser!.schoolId,
        Number(q.subjectId),
        req.authUser!.id,
        sanitizePlainText(q.gradeLevel || 'IX'),
        sanitizePlainText(q.topic || 'Umum'),
        sanitizePlainText(q.difficulty || 'SEDANG'),
        q.questionType || 'PG',
        sanitizePlainText(q.stimulusTitle || ''),
        String(q.stimulusText || ''),
        JSON.stringify(q.stimulusMedia || []),
        String(q.stem).trim(),
        String(q.mathLatex || ''),
        JSON.stringify(q.options || []),
        JSON.stringify(q.correctAnswer ?? ''),
        JSON.stringify(q.matchingPairs || []),
        JSON.stringify(q.shortAnswerConfig || {}),
        JSON.stringify(q.rubric || []),
        Number(q.weight) || 2,
        q.partialScoring ? 1 : 0,
        q.pgkMode || 'ALL_OR_NOTHING',
        Number(q.year) || new Date().getFullYear()
      );
    res.json({ id: Number(info.lastInsertRowid) });
  }
);

// Update question
questionRouter.put(
  '/:id',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const q = req.body || {};
    const db = getDb();
    db.prepare(
      `UPDATE questions
       SET subject_id = ?, grade_level = ?, topic = ?, difficulty = ?, question_type = ?,
           stimulus_title = ?, stimulus_text = ?, stimulus_media_json = ?, stem = ?, math_latex = ?,
           options_json = ?, correct_answer_json = ?, matching_pairs_json = ?, short_answer_config_json = ?,
           rubric_json = ?, weight = ?, partial_scoring = ?, pgk_mode = ?, warnings_json = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ? AND school_id = ?`
    ).run(
      Number(q.subjectId),
      sanitizePlainText(q.gradeLevel || 'IX'),
      sanitizePlainText(q.topic || 'Umum'),
      sanitizePlainText(q.difficulty || 'SEDANG'),
      q.questionType || 'PG',
      sanitizePlainText(q.stimulusTitle || ''),
      String(q.stimulusText || ''),
      JSON.stringify(q.stimulusMedia || []),
      String(q.stem || '').trim(),
      String(q.mathLatex || ''),
      JSON.stringify(q.options || []),
      JSON.stringify(q.correctAnswer ?? ''),
      JSON.stringify(q.matchingPairs || []),
      JSON.stringify(q.shortAnswerConfig || {}),
      JSON.stringify(q.rubric || []),
      Number(q.weight) || 2,
      q.partialScoring ? 1 : 0,
      q.pgkMode || 'ALL_OR_NOTHING',
      JSON.stringify(q.warnings || []),
      Number(req.params.id),
      req.authUser!.schoolId
    );
    res.json({ ok: true });
  }
);

// Duplicate question
questionRouter.post(
  '/:id/duplicate',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const row = db
      .prepare('SELECT * FROM questions WHERE id = ? AND school_id = ?')
      .get(Number(req.params.id), req.authUser!.schoolId) as any;
    if (!row) {
      res.status(404).json({ error: 'Soal tidak ditemukan.' });
      return;
    }
    const info = db
      .prepare(
        `INSERT INTO questions (
          school_id, subject_id, created_by, grade_level, topic, difficulty, question_type,
          stimulus_title, stimulus_text, stimulus_media_json, stem, math_latex,
          options_json, correct_answer_json, matching_pairs_json, short_answer_config_json,
          rubric_json, weight, partial_scoring, pgk_mode, year
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        row.school_id,
        row.subject_id,
        req.authUser!.id,
        row.grade_level,
        row.topic,
        row.difficulty,
        row.question_type,
        row.stimulus_title,
        row.stimulus_text,
        row.stimulus_media_json,
        `${row.stem} (Salinan)`,
        row.math_latex,
        row.options_json,
        row.correct_answer_json,
        row.matching_pairs_json,
        row.short_answer_config_json,
        row.rubric_json,
        row.weight,
        row.partial_scoring,
        row.pgk_mode,
        row.year
      );
    res.json({ id: Number(info.lastInsertRowid) });
  }
);

// Delete question
questionRouter.delete(
  '/:id',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    db.prepare('DELETE FROM questions WHERE id = ? AND school_id = ?').run(
      Number(req.params.id),
      req.authUser!.schoolId
    );
    res.json({ ok: true });
  }
);

// Export Bank Soal to Excel/JSON
questionRouter.get(
  '/export',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req: AuthRequest, res) => {
    const db = getDb();
    const rows = db
      .prepare(
        `SELECT q.*, s.name as subject_name
         FROM questions q
         JOIN subjects s ON s.id = q.subject_id
         WHERE q.school_id = ?
         ORDER BY q.id`
      )
      .all(req.authUser!.schoolId) as any[];

    const format = req.query.format === 'json' ? 'json' : 'xlsx';
    if (format === 'json') {
      res.setHeader('Content-Disposition', 'attachment; filename="bank-soal-smpn61.json"');
      res.json(rows.map(serializeQuestionRow));
      return;
    }

    const sheetData = rows.map((r, i) => ({
      No: i + 1,
      Mapel: r.subject_name,
      Kelas: r.grade_level,
      Topik: r.topic,
      Tipe: r.question_type,
      Kesulitan: r.difficulty,
      Bobot: r.weight,
      Stimulus: r.stimulus_text,
      Pertanyaan: r.stem,
      Opsi: r.options_json,
      Kunci: r.correct_answer_json,
    }));
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sheetData);
    XLSX.utils.book_append_sheet(wb, ws, 'Bank Soal AKM');
    const outBuf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Disposition', 'attachment; filename="bank-soal-smpn61.xlsx"');
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.send(outBuf);
  }
);

// Quick heuristic preview helper endpoint (for client testing without uploading file)
questionRouter.post(
  '/parse-preview',
  requireAuth,
  requireRole('SUPER_ADMIN', 'ADMIN_SEKOLAH', 'GURU'),
  (req, res) => {
    const text = typeof req.body?.text === 'string' ? req.body.text : '';
    const topic = sanitizePlainText(req.body?.topic || 'Umum');
    res.json({ questions: parseQuestionsHeuristic(text, topic) });
  }
);
