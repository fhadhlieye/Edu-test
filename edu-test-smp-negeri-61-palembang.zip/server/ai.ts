import { GoogleGenAI, Type } from '@google/genai';
import mammoth from 'mammoth';
import {
  parseQuestionsHeuristic,
  type ParsedQuestionDraft,
} from '../src/utils/questionParser.ts';
import type { RubricCriterion } from '../src/types/exam.ts';

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const QUESTION_EXTRACTION_SCHEMA = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      orderNumber: { type: Type.INTEGER },
      questionType: {
        type: Type.STRING,
        description:
          'One of: PG, PG_KOMPLEKS, MENJODOHKAN, ISIAN_SINGKAT, ESAI',
      },
      stimulusTitle: { type: Type.STRING },
      stimulusText: { type: Type.STRING },
      stem: { type: Type.STRING },
      mathLatex: { type: Type.STRING },
      topic: { type: Type.STRING },
      difficulty: {
        type: Type.STRING,
        description: 'One of: MUDAH, SEDANG, SUKAR',
      },
      options: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            key: { type: Type.STRING },
            text: { type: Type.STRING },
          },
        },
      },
      correctKeys: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
      matchingPairs: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            leftText: { type: Type.STRING },
            rightText: { type: Type.STRING },
          },
        },
      },
      acceptedShortAnswers: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
      warnings: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
    },
    required: ['orderNumber', 'questionType', 'stem'],
  },
};

export interface SmartExtractionResult {
  extractedText: string;
  extractionMethod: 'GEMINI_AI' | 'HEURISTIC_LOCAL';
  embeddedImages: string[];
  questions: ParsedQuestionDraft[];
}

export async function extractQuestionsFromDocument(params: {
  buffer: Buffer;
  filename: string;
  mimeType: string;
  defaultTopic?: string;
}): Promise<SmartExtractionResult> {
  const { buffer, filename, mimeType, defaultTopic = 'Umum' } = params;
  const ext = filename.toLowerCase().split('.').pop() || '';
  let extractedText = '';
  const embeddedImages: string[] = [];

  // Step 1: Local text & embedded media extraction for DOCX / TXT / DOC
  if (ext === 'docx' || mimeType.includes('wordprocessingml')) {
    const rawRes = await mammoth.extractRawText({ buffer });
    extractedText = rawRes.value || '';

    try {
      await mammoth.convertToHtml(
        { buffer },
        {
          convertImage: mammoth.images.imgElement(async (image) => {
            const b64 = await image.read('base64');
            if (embeddedImages.length < 10) {
              embeddedImages.push(`data:${image.contentType};base64,${b64}`);
            }
            return { src: '' };
          }),
        }
      );
    } catch {
      // Non-fatal image extraction failure
    }
  } else if (ext === 'txt' || ext === 'md' || mimeType.startsWith('text/')) {
    extractedText = buffer.toString('utf8');
  } else if (ext === 'doc') {
    // Legacy .doc binary: extract printable UTF-8/Latin1 text sequences
    const raw = buffer.toString('latin1');
    const chunks = raw.match(/[\x20-\x7E\u00A0-\u00FF\n\r]{4,}/g) || [];
    extractedText = chunks.join('\n');
  }

  // Step 2: Use Gemini AI if API key is configured (supports multimodal OCR for PDF/Images & structure recovery for DOCX/DOC)
  const ai = getGeminiClient();
  const isPdfOrImage =
    ext === 'pdf' ||
    mimeType === 'application/pdf' ||
    mimeType.startsWith('image/');

  if (ai) {
    try {
      const promptText = `Anda adalah asisten ekstraksi soal ujian AKM SMP Negeri 61 Palembang.
Tugas Anda: baca seluruh dokumen soal ini dan ekstrak setiap soal secara AKURAT tanpa mengubah atau mengarang isi pertanyaan guru.
Aturan ketat:
1. Pertahankan urutan soal dan hubungan antara stimulus bacaan/wacana/tabel dengan nomor soalnya.
2. Klasifikasikan jenis soal ke salah satu dari: PG (Pilihan Ganda 1 jawaban), PG_KOMPLEKS (lebih dari 1 jawaban benar), MENJODOHKAN, ISIAN_SINGKAT, ESAI.
3. Ekstrak pilihan jawaban (A, B, C, D, E) jika ada.
4. SANGAT PENTING: Perhatikan baris kunci jawaban seperti "Kunci: B", "Kunci: A, B", "Kunci: 1965", atau "Jawaban: ..." tepat di bawah setiap soal atau di bagian akhir dokumen. Masukkan huruf kunci PG/PG_KOMPLEKS ke correctKeys (misal ["B"] atau ["A","B"]) dan jawaban isian singkat ke acceptedShortAnswers (misal ["1965"]). Hanya kosongkan jika benar-benar tidak ada kunci di dokumen.
5. Jika ada rumus matematika, tulis bentuk LaTeX di mathLatex.
6. Jika ada bagian yang ambigu atau terpotong, catat di warnings tanpa menghentikan ekstraksi soal lain.`;

      const contents = isPdfOrImage
        ? {
            parts: [
              {
                inlineData: {
                  mimeType:
                    ext === 'pdf' ? 'application/pdf' : mimeType || 'image/png',
                  data: buffer.toString('base64'),
                },
              },
              { text: promptText },
            ],
          }
        : `${promptText}\n\nISI DOKUMEN (${filename}):\n${extractedText.slice(0, 60000)}`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents,
        config: {
          responseMimeType: 'application/json',
          responseSchema: QUESTION_EXTRACTION_SCHEMA,
        },
      });

      const rawJson = (response.text ?? '[]').trim();
      const parsed = JSON.parse(rawJson) as Array<Record<string, any>>;
      if (Array.isArray(parsed) && parsed.length > 0) {
        const heuristicFallback = extractedText
          ? parseQuestionsHeuristic(extractedText, defaultTopic)
          : [];
        const heuristicByOrder = new Map(
          heuristicFallback.map((h) => [h.orderNumber, h])
        );

        const questions: ParsedQuestionDraft[] = parsed.map((item, idx) => {
          const orderNum = Number(item.orderNumber) || idx + 1;
          const hMatch = heuristicByOrder.get(orderNum);
          const qType = (
            ['PG', 'PG_KOMPLEKS', 'MENJODOHKAN', 'ISIAN_SINGKAT', 'ESAI'].includes(
              item.questionType
            )
              ? item.questionType
              : 'PG'
          ) as ParsedQuestionDraft['questionType'];

          const options = Array.isArray(item.options)
            ? item.options.map((o: any) => ({
                key: String(o.key || 'A').toUpperCase(),
                text: String(o.text || ''),
              }))
            : [];

          let keys = Array.isArray(item.correctKeys)
            ? item.correctKeys.map((k: any) => String(k).trim()).filter(Boolean)
            : [];
          if (keys.length === 0 && hMatch?.correctAnswer) {
            keys = Array.isArray(hMatch.correctAnswer)
              ? hMatch.correctAnswer
              : [String(hMatch.correctAnswer)].filter(Boolean);
          }

          const matchingPairs = Array.isArray(item.matchingPairs)
            ? item.matchingPairs.map((p: any, pIdx: number) => ({
                id: `pair-${pIdx + 1}`,
                leftText: String(p.leftText || ''),
                rightText: String(p.rightText || ''),
              }))
            : [];

          let acceptedShort = Array.isArray(item.acceptedShortAnswers)
            ? item.acceptedShortAnswers.map((s: any) => String(s).trim()).filter(Boolean)
            : [];
          if (acceptedShort.length === 0 && hMatch?.shortAnswerConfig?.acceptedAnswers?.length) {
            acceptedShort = hMatch.shortAnswerConfig.acceptedAnswers;
          }

          let correctAnswer: string | string[] = '';
          if (qType === 'PG_KOMPLEKS') correctAnswer = keys;
          else if (qType === 'PG') correctAnswer = keys[0] || '';
          else if (qType === 'ISIAN_SINGKAT')
            correctAnswer = acceptedShort[0] || keys[0] || '';
          else if (qType === 'ESAI') correctAnswer = keys.join(' ');

          const warnings = Array.isArray(item.warnings)
            ? item.warnings
                .map((w: any) => String(w))
                .filter((w) => !((keys.length > 0 || acceptedShort.length > 0) && w.toLowerCase().includes('kunci')))
            : [];
          if (!keys.length && qType !== 'MENJODOHKAN' && !acceptedShort.length) {
            if (!warnings.some((w) => w.toLowerCase().includes('kunci'))) {
              warnings.push('Kunci jawaban belum terdeteksi di dokumen; silakan lengkapi manual.');
            }
          }

          return {
            tempId: `ai-${idx + 1}-${orderNum}`,
            orderNumber: orderNum,
            questionType: qType,
            stimulusTitle: item.stimulusTitle || undefined,
            stimulusText: item.stimulusText || undefined,
            stem: String(item.stem || '').trim(),
            mathLatex: item.mathLatex || undefined,
            options,
            correctAnswer,
            matchingPairs,
            shortAnswerConfig: {
              acceptedAnswers:
                acceptedShort.length > 0 ? acceptedShort : keys,
              caseSensitive: false,
              ignoreWhitespace: false,
              numericTolerance: 0,
            },
            rubric:
              qType === 'ESAI'
                ? [
                    {
                      id: 'r1',
                      aspect: 'Ketepatan Konsep',
                      maxPoints: 3,
                      description: 'Kesesuaian isi jawaban dengan konsep materi.',
                    },
                    {
                      id: 'r2',
                      aspect: 'Kelengkapan Penjelasan',
                      maxPoints: 2,
                      description: 'Kelengkapan argumen dan contoh.',
                    },
                  ]
                : [],
            difficulty: (['MUDAH', 'SEDANG', 'SUKAR'].includes(item.difficulty)
              ? item.difficulty
              : 'SEDANG') as ParsedQuestionDraft['difficulty'],
            topic: item.topic || defaultTopic,
            weight:
              qType === 'ESAI'
                ? 5
                : qType === 'PG_KOMPLEKS' || qType === 'MENJODOHKAN'
                  ? 3
                  : 2,
            partialScoring: qType === 'PG_KOMPLEKS' || qType === 'MENJODOHKAN',
            pgkMode: qType === 'PG_KOMPLEKS' ? 'PARTIAL' : 'ALL_OR_NOTHING',
            warnings,
          };
        });

        return {
          extractedText:
            extractedText ||
            questions.map((q) => `${q.orderNumber}. ${q.stem}`).join('\n\n'),
          extractionMethod: 'GEMINI_AI',
          embeddedImages,
          questions,
        };
      }
    } catch (err) {
      console.error('Gemini extraction fallback triggered:', err);
    }
  }

  // Step 3: Local heuristic parser fallback (works even without API key or offline)
  if (!extractedText && ext === 'pdf') {
    // Extract readable PDF text streams when no OCR key is active
    const rawLatin = buffer.toString('latin1');
    const textMatches = rawLatin.match(/\(([^()]{3,})\)/g) || [];
    extractedText = textMatches
      .map((s) => s.slice(1, -1))
      .filter((s) => /[A-Za-z0-9]/.test(s))
      .join(' ');
  }

  const questions = parseQuestionsHeuristic(extractedText, defaultTopic);
  return {
    extractedText,
    extractionMethod: 'HEURISTIC_LOCAL',
    embeddedImages,
    questions,
  };
}

export async function gradeEssayWithRubricAI(params: {
  questionStem: string;
  modelAnswer?: string;
  rubric: RubricCriterion[];
  studentAnswer: string;
  maxWeight: number;
}): Promise<{
  recommendedScore: number;
  feedback: string;
  breakdown: Array<{ aspect: string; score: number; maxPoints: number; comment: string }>;
  source: 'GEMINI_AI' | 'RUBRIC_HEURISTIC';
}> {
  const { questionStem, modelAnswer, rubric, studentAnswer, maxWeight } = params;
  const trimmed = (studentAnswer || '').trim();
  if (!trimmed) {
    return {
      recommendedScore: 0,
      feedback: 'Siswa tidak mengisi jawaban uraian.',
      breakdown: rubric.map((r) => ({
        aspect: r.aspect,
        score: 0,
        maxPoints: r.maxPoints,
        comment: 'Tidak ada jawaban.',
      })),
      source: 'RUBRIC_HEURISTIC',
    };
  }

  const ai = getGeminiClient();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Anda adalah asisten korektor esai guru SMP Negeri 61 Palembang. Nilai jawaban siswa secara objektif berdasarkan rubrik guru.
Pertanyaan: ${questionStem}
Kunci/Acuan Guru: ${modelAnswer || '-'}
Bobot Maksimal Soal: ${maxWeight}
Rubrik Penilaian:
${rubric.map((r, i) => `${i + 1}. ${r.aspect} (Maks ${r.maxPoints} poin): ${r.description}`).join('\n')}

Jawaban Siswa:
"${trimmed}"

Berikan penilaian per aspek rubrik, total skor rekomendasi (skala 0..${maxWeight}), dan umpan balik konstruktif dalam Bahasa Indonesia.`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              recommendedScore: { type: Type.NUMBER },
              feedback: { type: Type.STRING },
              breakdown: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    aspect: { type: Type.STRING },
                    score: { type: Type.NUMBER },
                    maxPoints: { type: Type.NUMBER },
                    comment: { type: Type.STRING },
                  },
                },
              },
            },
            required: ['recommendedScore', 'feedback', 'breakdown'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      if (typeof parsed.recommendedScore === 'number') {
        return {
          recommendedScore: Math.min(
            maxWeight,
            Math.max(0, Number(parsed.recommendedScore.toFixed(2)))
          ),
          feedback: String(parsed.feedback || ''),
          breakdown: Array.isArray(parsed.breakdown) ? parsed.breakdown : [],
          source: 'GEMINI_AI',
        };
      }
    } catch (err) {
      console.error('Gemini essay grading fallback:', err);
    }
  }

  // Deterministic keyword-coverage fallback when offline/no API key
  const refWords = new Set(
    `${questionStem} ${modelAnswer || ''} ${rubric.map((r) => r.description).join(' ')}`
      .toLowerCase()
      .split(/\W+/)
      .filter((w) => w.length > 3)
  );
  const ansWords = trimmed
    .toLowerCase()
    .split(/\W+/)
    .filter((w) => w.length > 3);
  const overlap = ansWords.filter((w) => refWords.has(w)).length;
  const lengthFactor = Math.min(1, trimmed.split(/\s+/).length / 25);
  const coverageFactor = refWords.size > 0 ? Math.min(1, overlap / 4) : 0.6;
  const ratio = Math.min(1, 0.35 * lengthFactor + 0.65 * coverageFactor);

  const totalRubricMax = rubric.reduce((acc, r) => acc + r.maxPoints, 0) || maxWeight;
  const breakdown = rubric.map((r) => {
    const s = Number((r.maxPoints * ratio).toFixed(1));
    return {
      aspect: r.aspect,
      score: s,
      maxPoints: r.maxPoints,
      comment:
        ratio >= 0.75
          ? 'Poin konsep tercakup dengan baik (rekomendasi awal).'
          : 'Jawaban perlu diperiksa kesesuaian detailnya oleh guru.',
    };
  });

  const recommendedScore = Number(
    Math.min(
      maxWeight,
      (breakdown.reduce((a, b) => a + b.score, 0) / totalRubricMax) * maxWeight
    ).toFixed(2)
  );

  return {
    recommendedScore,
    feedback:
      'Rekomendasi skor awal dihitung dari kelengkapan rubrik. Mohon guru meninjau sebelum menyetujui nilai final.',
    breakdown,
    source: 'RUBRIC_HEURISTIC',
  };
}
